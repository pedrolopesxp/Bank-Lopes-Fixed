USE if0_39959568_new;

-- Tabela de Administradores
CREATE TABLE IF NOT EXISTS tb_admin (
    id_admin INT AUTO_INCREMENT PRIMARY KEY,
    nm_admin VARCHAR(100) NOT NULL,
    ds_email VARCHAR(100) NOT NULL UNIQUE,
    ds_senha_hash VARCHAR(255) NOT NULL,
    ds_nivel_acesso ENUM('SuperAdmin', 'Financeiro', 'Suporte') DEFAULT 'Suporte',
    dt_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de Usuários
CREATE TABLE IF NOT EXISTS tb_usuario (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nm_usuario VARCHAR(100) NOT NULL,
    ds_email VARCHAR(100) NOT NULL UNIQUE,
    ds_cpf VARCHAR(14) NOT NULL UNIQUE,
    ds_senha_hash VARCHAR(255) NOT NULL,
    dt_nascimento DATE NOT NULL,
    ds_telefone VARCHAR(20),
    ds_endereco TEXT,
    ds_cidade VARCHAR(100) NOT NULL,
    ds_estado VARCHAR(100) NOT NULL,
    ds_pais_origem VARCHAR(100) DEFAULT 'Brasil',
    dt_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    dt_ultimo_acesso TIMESTAMP NULL,
    ds_status ENUM('Ativo', 'Inativo', 'Bloqueado') DEFAULT 'Ativo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de Contas
-- ATUALIZAÇÃO: Adicionado 'vl_saldo_poupanca' para suportar a lógica do poupanca.php
CREATE TABLE IF NOT EXISTS tb_conta (
    id_conta INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    tp_tipo_conta ENUM('Corrente', 'Poupança') NOT NULL DEFAULT 'Corrente',
    nr_conta VARCHAR(20) NOT NULL UNIQUE,
    vl_saldo_bitcoin DECIMAL(18,8) DEFAULT 0,
    vl_saldo_real DECIMAL(10,2) DEFAULT 0,
    vl_saldo_poupanca DECIMAL(10,2) DEFAULT 0, -- CAMPO ADICIONADO
    dt_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de Endereços Bitcoin
CREATE TABLE IF NOT EXISTS tb_endereco_bitcoin (
    id_endereco INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    ds_endereco VARCHAR(255) NOT NULL UNIQUE,
    ds_qr_code TEXT,
    ds_rotulo VARCHAR(50),
    tp_tipo ENUM('Recebimento', 'Troco', 'Depósito', 'Transferência') NOT NULL,
    dt_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    dt_ultima_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabela de Transações Gerais
CREATE TABLE IF NOT EXISTS tb_transacao (
    id_transacao INT AUTO_INCREMENT PRIMARY KEY,
    tp_tipo ENUM('Depósito', 'Saque', 'Transferência', 'Compra', 'Venda', 'PIX Recebido', 'PIX Enviado', 'TED Recebido', 'TED Enviado', 'Estorno PIX') NOT NULL,
    tp_metodo_pagamento ENUM('PIX', 'Cartão de Crédito', 'Cartão de Débito', 'TED', 'Poupança', 'Bitcoin', 'QR Code', 'Transferência Bitcoin') NOT NULL,
    id_remetente INT,
    id_destinatario INT,
    ds_endereco_bitcoin_origem VARCHAR(100),
    ds_endereco_bitcoin_destino VARCHAR(100),
    vl_quantidade_bitcoin DECIMAL(18,8),
    vl_quantidade_real DECIMAL(10,2),
    vl_taxa DECIMAL(18,8),
    ds_status ENUM('Pendente', 'Concluída', 'Falha', 'Aprovada', 'Recusada', 'Processando', 'Cancelada') DEFAULT 'Pendente',
    dt_transacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    dt_confirmacao TIMESTAMP NULL,
    ds_descricao TEXT NULL,
    id_transacao_original INT NULL,
    FOREIGN KEY (id_remetente) REFERENCES tb_usuario(id_usuario) ON DELETE SET NULL,
    FOREIGN KEY (id_destinatario) REFERENCES tb_usuario(id_usuario) ON DELETE SET NULL,
    FOREIGN KEY (id_transacao_original) REFERENCES tb_transacao(id_transacao) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de Transações Bitcoin (detalhes específicos de blockchain)
CREATE TABLE IF NOT EXISTS tb_transacao_bitcoin (
    id_transacao_bitcoin INT AUTO_INCREMENT PRIMARY KEY,
    id_transacao INT NOT NULL,
    ds_hash_transacao VARCHAR(64) NOT NULL UNIQUE,
    nr_confirmacoes INT DEFAULT 0,
    vl_taxa_mineracao DECIMAL(18,8),
    dt_confirmacao TIMESTAMP NULL,
    FOREIGN KEY (id_transacao) REFERENCES tb_transacao(id_transacao) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de Logs de Atividades
CREATE TABLE IF NOT EXISTS tb_log_atividade (
    id_log INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT,
    tp_tipo_atividade VARCHAR(50) NOT NULL,
    ds_descricao TEXT,
    ds_endereco_ip VARCHAR(45),
    dt_atividade TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de Configurações do Sistema
CREATE TABLE IF NOT EXISTS tb_configuracao_sistema (
    id_configuracao INT AUTO_INCREMENT PRIMARY KEY,
    ch_chave VARCHAR(50) NOT NULL UNIQUE,
    vl_valor TEXT,
    ds_descricao TEXT,
    dt_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de Taxas
CREATE TABLE IF NOT EXISTS tb_taxa (
    id_taxa INT AUTO_INCREMENT PRIMARY KEY,
    tp_tipo_operacao VARCHAR(50) NOT NULL,
    vl_percentual DECIMAL(5,2) NOT NULL,
    vl_valor_fixo DECIMAL(10,2) DEFAULT 0.00,
    vl_valor_minimo DECIMAL(10,2),
    vl_valor_maximo DECIMAL(10,2),
    dt_inicio DATE NOT NULL,
    dt_fim DATE NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de Limites de Transações
CREATE TABLE IF NOT EXISTS tb_limite_transacao (
    id_limite INT AUTO_INCREMENT PRIMARY KEY,
    tp_tipo_limite VARCHAR(50) NOT NULL,
    vl_valor_limite DECIMAL(18,8) NOT NULL,
    tp_periodo ENUM('Diário', 'Semanal', 'Mensal', 'Anual', 'Única') NOT NULL,
    hr_inicio TIME NULL,
    hr_fim TIME NULL,
    dt_inicio DATE NOT NULL,
    dt_fim DATE NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de histórico de preços de criptomoedas
CREATE TABLE IF NOT EXISTS tb_historico_preco (
    id_historico INT AUTO_INCREMENT PRIMARY KEY,
    tp_moeda VARCHAR(10) NOT NULL,
    vl_preco DECIMAL(18,8) NOT NULL,
    dt_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de extrato da conta (movimentações do saldo)
-- ATUALIZADA: Agora registra separadamente o movimento de Real e Bitcoin.
CREATE TABLE IF NOT EXISTS tb_extrato_conta (
    id_extrato INT AUTO_INCREMENT PRIMARY KEY,
    id_conta INT NOT NULL,
    tp_tipo_operacao ENUM('Crédito', 'Débito', 'PIX Recebido', 'PIX Enviado', 'TED Recebido', 'TED Enviado', 'Compra', 'Venda', 'Taxa', 'Transferência Bitcoin', 'Depósito Bitcoin', 'Saque Bitcoin') NOT NULL, 
    ds_descricao TEXT,
    
    -- Campos para movimentação em Bitcoin
    vl_valor_bitcoin DECIMAL(18,8) NULL,          -- Valor movimentado em Bitcoin. NULL se a operação for apenas em Real.
    vl_saldo_anterior_bitcoin DECIMAL(18,8) NULL, -- Saldo anterior em BTC após a operação. NULL se a operação for apenas em Real.
    vl_saldo_atual_bitcoin DECIMAL(18,8) NULL,    -- Saldo atual em BTC após a operação. NULL se a operação for apenas em Real.
    
    -- Campos para movimentação em Real (BRL)
    vl_valor_real DECIMAL(10,2) NULL,             -- Valor movimentado em Real. NULL se a operação for apenas em Bitcoin.
    vl_saldo_anterior_real DECIMAL(10,2) NULL,    -- Saldo anterior em BRL após a operação. NULL se a operação for apenas em Bitcoin.
    vl_saldo_atual_real DECIMAL(10,2) NULL,       -- Saldo atual em BRL após a operação. NULL se a operação for apenas em Bitcoin.
    
    dt_operacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_conta) REFERENCES tb_conta(id_conta) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de ordens de trade (para compra/venda de cripto)
CREATE TABLE IF NOT EXISTS tb_ordem_trade (
    id_ordem INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    tp_tipo ENUM('Compra', 'Venda') NOT NULL,
    tp_moeda_base VARCHAR(10) NOT NULL,
    tp_moeda_cotacao VARCHAR(10) NOT NULL,
    vl_quantidade DECIMAL(18,8) NOT NULL,
    vl_preco_limite DECIMAL(18,8) NULL,
    vl_preco_executado DECIMAL(18,8) NULL,
    vl_quantidade_executada DECIMAL(18,8) DEFAULT 0,
    ds_status ENUM('Aberta', 'Executada', 'Cancelada', 'Parcialmente Executada') DEFAULT 'Aberta',
    dt_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    dt_execucao TIMESTAMP NULL,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de informações de PIX (chaves Pix cadastradas pelo usuário para RECEBER pagamentos)
CREATE TABLE IF NOT EXISTS tb_informacao_pix (
    id_informacao INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    ch_chave_pix VARCHAR(255) NOT NULL UNIQUE,
    tp_tipo_chave ENUM('CPF', 'CNPJ', 'E-mail', 'Telefone', 'Aleatória') NOT NULL,
    ds_rotulo VARCHAR(100) NULL,
    dt_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    bo_principal TINYINT(1) NOT NULL DEFAULT 0,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de informações de cartão (para pagamentos feitos pelo usuário com cartão)
CREATE TABLE IF NOT EXISTS tb_informacao_cartao (
    id_informacao INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    tp_tipo ENUM('Crédito', 'Débito', 'Virtual') NOT NULL,
    nr_cartao_tokenizado VARCHAR(255) NOT NULL,
    nm_titular VARCHAR(100) NOT NULL,
    dt_validade DATE NOT NULL,
    ds_bandeira VARCHAR(50) NOT NULL,
    ds_status ENUM('Ativo', 'Inativo') DEFAULT 'Ativo' NOT NULL,
    dt_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de informações bancárias (TED e Poupança - para SAQUES ou DEPÓSITOS via TED/DOC)
-- CAMPO 'tp_tipo_conta' já estava no ENUM com 'Poupança'. Mantido.
CREATE TABLE IF NOT EXISTS tb_informacao_bancaria (
    id_informacao INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    tp_tipo_conta ENUM('Corrente', 'Poupança') NOT NULL,
    nm_banco VARCHAR(100) NOT NULL,
    nr_agencia VARCHAR(10) NOT NULL,
    nr_conta VARCHAR(20) NOT NULL,
    nm_titular VARCHAR(100) NOT NULL,
    ds_cpf_cnpj VARCHAR(14) NOT NULL,
    dt_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de limites PIX por usuário (limites personalizados de envio/recebimento)
CREATE TABLE IF NOT EXISTS tb_limite_pix_usuario (
    id_limite INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    vl_limite_diario DECIMAL(10,2) NOT NULL,
    vl_limite_noturno DECIMAL(10,2) NOT NULL,
    dt_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela de notificações
CREATE TABLE IF NOT EXISTS tb_notificacao (
    id_notificacao INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    tp_tipo ENUM('Alerta', 'Info', 'Sucesso', 'Erro', 'PIX Enviado', 'PIX Recebido', 'Transação Bitcoin', 'Bitcoin Recebido', 'TED Enviado', 'TED Recebido', 'Cartão Aprovado', 'Cartão Recusado', 'Trade Executado', 'Trade Cancelado', 'Mensagem do Admin') NOT NULL,
    ds_mensagem TEXT NOT NULL,
    bl_lida TINYINT(1) DEFAULT 0,
    dt_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela para controle de sessões de usuário (para login e persistência)
CREATE TABLE IF NOT EXISTS tb_sessao (
    id_sessao INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    ds_token VARCHAR(255) NOT NULL UNIQUE,
    dt_expiracao DATETIME NOT NULL,
    dt_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela para tokens de recuperação de senha pelo email
CREATE TABLE IF NOT EXISTS tb_recuperacao_senha_email (
    id_recuperacao INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    ds_token VARCHAR(255) NOT NULL UNIQUE,
    dt_expiracao DATETIME NOT NULL,
    bl_usado TINYINT(1) DEFAULT 0,
    dt_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela para gerenciar Cobranças PIX geradas pelo sistema
CREATE TABLE IF NOT EXISTS tb_pix_cobranca_gerada (
    id_cobranca_pix INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    ds_transaction_id_provider VARCHAR(255) NOT NULL UNIQUE,
    vl_valor_cobrado DECIMAL(10, 2) NOT NULL,
    ds_status ENUM('Pendente', 'Concluída', 'Cancelada', 'Expirada', 'Em Processamento') NOT NULL DEFAULT 'Pendente',
    ds_qr_code_data TEXT,
    ds_copy_paste_code TEXT,
    dt_criacao DATETIME DEFAULT CURRENT_TIMESTAMP,
    dt_expiracao DATETIME NOT NULL,
    dt_confirmacao DATETIME NULL,
    ds_info_pagador TEXT NULL,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela para gerenciar PIX Automático (Agendamento)
CREATE TABLE IF NOT EXISTS tb_pix_agendado (
    id_agendamento INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    ch_chave_pix_destino VARCHAR(255) NOT NULL,
    tp_tipo_chave_destino ENUM('CPF', 'CNPJ', 'E-mail', 'Telefone', 'Aleatória') NOT NULL,
    vl_valor DECIMAL(10,2) NOT NULL,
    ds_descricao_agendamento TEXT,
    dt_primeira_execucao DATETIME NOT NULL,
    tp_frequencia ENUM('Diário', 'Semanal', 'Mensal', 'Anual', 'Única') NOT NULL,
    dt_proxima_execucao DATETIME NOT NULL,
    dt_fim_agendamento DATETIME NULL,
    ds_status_agendamento ENUM('Ativo', 'Pausado', 'Concluído', 'Cancelado', 'Falha') DEFAULT 'Ativo' NOT NULL,
    dt_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    dt_ultima_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Tabela para tokens de recuperação de senha (antiga, mantida por referência)
-- CREATE TABLE IF NOT EXISTS tb_recuperacao_senha (
--     id_recuperacao INT AUTO_INCREMENT PRIMARY KEY,
--     id_usuario INT NOT NULL,
--     ds_token VARCHAR(255) NOT NULL UNIQUE,
--     dt_expiracao DATETIME NOT NULL,
--     bl_usado TINYINT(1) DEFAULT 0,
--     dt_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
--     FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario) ON DELETE CASCADE
-- ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Exemplo de adição de dados de teste (opcional, para administradores)
-- Lembre-se de substituir 'sua_senha_hash_aqui' por uma senha real hasheada (e.g., password_hash() no PHP)
-- INSERT INTO tb_admin (nm_admin, ds_email, ds_senha_hash, ds_nivel_acesso) VALUES
-- ('Admin Principal', 'admin@banklopes.com', '$2y$10$iM.D8yWzN9P7T3pA7z0R4.uQ.sZ9B5c2mX4.Q9P5K5Q.j7P2uQ.sQ.lQ.gQ.kQ.hQ.fQ.eQ.dQ.cQ.bQ.aQ.s', 'SuperAdmin');
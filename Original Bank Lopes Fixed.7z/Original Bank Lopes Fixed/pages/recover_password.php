<?php
// www/pages/recover_password.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Verifica se a URL tem um token de redefinição
$token = $_GET['token'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Processa o formulário de recuperação
    if (isset($_POST['email']) && isset($_POST['cpf'])) {
        $email = trim($_POST['email'] ?? '');
        $cpf = trim($_POST['cpf'] ?? '');

        if (empty($email) || empty($cpf)) {
            set_message("Por favor, preencha todos os campos.", "error");
        } elseif (!is_valid_email($email)) {
            set_message("Formato de e-mail inválido.", "error");
        } else {
            try {
                // Modificado para buscar por e-mail e CPF
                $stmt = $pdo->prepare("SELECT id_usuario FROM tb_usuario WHERE ds_email = ? AND ds_cpf = ?");
                $stmt->execute([$email, $cpf]);
                $user = $stmt->fetch();

                if ($user) {
                    $user_id = $user['id_usuario'];
                    $token = generate_token(64);
                    $expiration_time = date('Y-m-d H:i:s', strtotime('+1 hour'));

                    // Inserir o token de recuperação na tabela correta
                    $insert_token_stmt = $pdo->prepare("INSERT INTO tb_recuperacao_senha_email (id_usuario, ds_token, dt_expiracao) VALUES (?, ?, ?)");
                    $insert_token_stmt->execute([$user_id, $token, $expiration_time]);

                    set_message("Um link de recuperação de senha foi enviado para o seu e-mail.", "success");
                    // Opcional: Para desenvolvimento, exibir o link
                    // set_message("DEMO: Link de recuperação: <a href='recover_password.php?token=" . htmlspecialchars($token) . "'>Clique aqui para redefinir</a>", "info");
                } else {
                    set_message("Nenhuma conta encontrada com o e-mail e CPF fornecidos.", "error");
                }
            } catch (PDOException $e) {
                error_log("Erro na recuperação de senha: " . $e->getMessage());
                set_message("Ocorreu um erro no servidor. Por favor, tente novamente mais tarde.", "error");
            }
        }
    }
    // Processa o formulário de redefinição de senha
    elseif (isset($_POST['senha'])) {
        $token = $_POST['token'];
        $senha = $_POST['senha'] ?? '';
        $confirma = $_POST['confirma'] ?? '';

        if ($senha !== $confirma) {
            set_message("As senhas não coincidem.", "error");
        } elseif (strlen($senha) < 6) {
            set_message("A senha deve ter no mínimo 6 caracteres.", "error");
        } else {
            // Verifica o token na tabela correta
            $stmt = $pdo->prepare("SELECT id_usuario, dt_expiracao, bl_usado FROM tb_recuperacao_senha_email WHERE ds_token = ? LIMIT 1");
            $stmt->execute([$token]);
            $data = $stmt->fetch();

            if ($data && strtotime($data['dt_expiracao']) > time() && $data['bl_usado'] == 0) {
                $user_id = $data['id_usuario'];
                $hash = password_hash($senha, PASSWORD_DEFAULT);

                $pdo->prepare("UPDATE tb_usuario SET ds_senha_hash = ? WHERE id_usuario = ?")->execute([$hash, $user_id]);
                $pdo->prepare("UPDATE tb_recuperacao_senha_email SET bl_usado = 1 WHERE ds_token = ?")->execute([$token]);

                set_message("Senha alterada com sucesso! Agora faça login.", "success");
                header("Location: login.php");
                exit;
            } else {
                set_message("Token inválido ou expirado.", "error");
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Senha - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="../index.php">Início</a></li>
                    <li><a href="login.php" class="button primary">Login</a></li>
                    <li><a href="register.php" class="button secondary">Abrir Conta</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container">
            <?php display_messages(); ?>
            <?php if ($token): ?>
                <h2>Redefinir Senha</h2>
                <form action="recover_password.php" method="POST" class="contact-form">
                    <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
                    <input type="password" name="senha" placeholder="Nova Senha" required>
                    <input type="password" name="confirma" placeholder="Confirme a Senha" required>
                    <button type="submit" class="button primary">Salvar Nova Senha</button>
                    <p><a href="login.php">Voltar para o Login</a></p>
                </form>
            <?php else: ?>
                <h2>Recuperar Senha</h2>
                <form action="recover_password.php" method="POST">
                    <p>Digite seu e-mail e CPF para recuperar sua senha.</p>
                    <input type="email" name="email" placeholder="Seu E-mail" required autocomplete="email">
                    <input type="text" name="cpf" placeholder="Seu CPF" required autocomplete="cpf">
                    <button type="submit" class="button primary">Enviar Link de Recuperação</button>
                    <p><a href="login.php">Voltar para o Login</a></p>
                </form>
            <?php endif; ?>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>
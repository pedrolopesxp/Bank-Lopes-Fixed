<?php
// www/pages/transaction_history.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    set_message("Você precisa estar logado para ver o histórico de transações.", "error");
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$userName = htmlspecialchars($_SESSION['user_name'] ?? 'Usuário');

$transactions = [];
try {
    // Busca todas as transações onde o usuário é remetente ou destinatário
    $stmt = $pdo->prepare("
        SELECT
            id_transacao,
            tp_tipo,
            tp_metodo_pagamento,
            vl_quantidade_real,
            vl_quantidade_bitcoin,
            vl_taxa,
            ds_status,
            dt_transacao,
            ds_descricao
        FROM
            tb_transacao
        WHERE
            id_remetente = ? OR id_destinatario = ?
        ORDER BY
            dt_transacao DESC
    ");
    $stmt->execute([$user_id, $user_id]);
    $transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Erro ao buscar histórico de transações: " . $e->getMessage());
    set_message("Erro ao carregar o histórico de transações. Por favor, tente novamente.", "error");
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Histórico de Transações - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .transaction-list {
            list-style: none;
            padding: 0;
        }
        .transaction-item {
            background-color: var(--secondary-color);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        .transaction-item p {
            margin: 0;
            font-size: 0.95em;
        }
        .transaction-item strong {
            color: var(--primary-dark-color);
        }
        .transaction-item .type {
            font-weight: bold;
            font-size: 1.1em;
            color: var(--primary-color);
        }
        .transaction-item .amount.real {
            color: #28a745; /* Verde para valores em Reais */
            font-weight: bold;
        }
        .transaction-item .amount.bitcoin {
            color: #ffc107; /* Amarelo para Bitcoin */
            font-weight: bold;
        }
        .transaction-item .status {
            font-weight: bold;
        }
        .transaction-item .status.Pendente { color: #ffc107; } /* Amarelo */
        .transaction-item .status.Concluída { color: #28a745; } /* Verde */
        .transaction-item .status.Falha { color: #dc3545; }    /* Vermelho */
        .transaction-item .status.Estornada { color: #6c757d; } /* Cinza para estornado */


        @media (min-width: 768px) {
            .transaction-item {
                flex-direction: row;
                justify-content: space-between;
                align-items: center;
            }
            .transaction-item p {
                flex: 1;
                text-align: left;
            }
            .transaction-item p:last-child {
                text-align: right;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li>Olá, <?= $userName ?></li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container" style="max-width: 90%; text-align: left;">
            <h2>Histórico de Transações</h2>
            <?php display_messages(); ?>

            <?php if (empty($transactions)): ?>
                <p>Nenhuma transação encontrada.</p>
            <?php else: ?>
                <ul class="transaction-list">
                    <?php foreach ($transactions as $transaction): ?>
                        <li class="transaction-item">
                            <p class="type"><?= htmlspecialchars($transaction['tp_tipo']) ?> (<?= htmlspecialchars($transaction['tp_metodo_pagamento']) ?>)</p>
                            <p>Valor Real: <span class="amount real">R$ <?= htmlspecialchars(number_format($transaction['vl_quantidade_real'], 2, ',', '.')) ?></span></p>
                            <p>Valor BTC: <span class="amount bitcoin"><?= htmlspecialchars(number_format($transaction['vl_quantidade_bitcoin'], 8, ',', '.')) ?> BTC</span></p>
                            <p>Taxa: R$ <?= htmlspecialchars(number_format($transaction['vl_taxa'], 2, ',', '.')) ?></p>
                            <p>Status: <span class="status <?= htmlspecialchars($transaction['ds_status']) ?>"><?= htmlspecialchars($transaction['ds_status']) ?></span></p>
                            <p>Data: <strong><?= htmlspecialchars(date('d/m/Y H:i', strtotime($transaction['dt_transacao']))) ?></strong></p>
                            <?php if (!empty($transaction['ds_descricao'])): ?>
                                <p>Descrição: <small><?= htmlspecialchars($transaction['ds_descricao']) ?></small></p>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>

            <p style="margin-top: 30px;"><a href="dashboard.php">Voltar para o Dashboard</a></p>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>

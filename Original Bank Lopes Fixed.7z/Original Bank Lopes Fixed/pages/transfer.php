<?php
// www/pages/transfer.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    set_message("Você precisa estar logado para fazer transferências.", "error");
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$userName = htmlspecialchars($_SESSION['user_name'] ?? 'Usuário');

$current_real_balance = 0;
$current_bitcoin_balance = 0;

try {
    // Buscar saldos da conta do usuário logado
    $stmt_balance = $pdo->prepare("SELECT vl_saldo_bitcoin, vl_saldo_real FROM tb_conta WHERE id_usuario = ?");
    $stmt_balance->execute([$user_id]);
    $account_data = $stmt_balance->fetch(PDO::FETCH_ASSOC);
    if ($account_data) {
        $current_bitcoin_balance = $account_data['vl_saldo_bitcoin'];
        $current_real_balance = $account_data['vl_saldo_real'];
    }
} catch (PDOException $e) {
    error_log("Erro ao buscar saldos para transferência: " . $e->getMessage());
    set_message("Erro ao carregar seus saldos. Por favor, tente novamente.", "error");
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $target_identifier = trim(isset($_POST['target_identifier']) ? $_POST['target_identifier'] : '');
    $type_identifier = trim(isset($_POST['type_identifier']) ? $_POST['type_identifier'] : '');
    $amount = floatval(str_replace(',', '.', trim(isset($_POST['amount']) ? $_POST['amount'] : '0')));
    $currency = trim(isset($_POST['currency']) ? $_POST['currency'] : '');
    $description = trim(isset($_POST['description']) ? $_POST['description'] : '');

    if ($amount <= 0) {
        set_message("A quantidade deve ser maior que zero.", "error");
    } elseif (empty($target_identifier) || empty($currency) || empty($type_identifier)) {
        set_message("Por favor, preencha todos os campos obrigatórios (Tipo de Identificador, Identificador de Destino, Quantidade, Moeda da Transferência).", "error");
    } else {
        try {
            $pdo->beginTransaction();

            $dest_user_id = null;
            $dest_user_name = '';
            $is_internal_transfer = false;

            // Lógica para encontrar o destinatário ou tratar como externo
            switch ($type_identifier) {
                case 'email':
                case 'cpf':
                case 'account_number':
                    // Tentativa de encontrar usuário interno do Bank Lopes
                    $sql_find_dest = "";
                    $params = [$target_identifier];
                    if ($type_identifier === 'cpf') {
                        $target_identifier_clean = preg_replace('/[^0-9]/', '', $target_identifier);
                        $sql_find_dest = "SELECT u.id_usuario, u.nm_usuario, c.id_conta FROM tb_usuario u JOIN tb_conta c ON u.id_usuario = c.id_usuario WHERE u.ds_cpf = ?";
                        $params = [$target_identifier_clean];
                    } elseif ($type_identifier === 'email') {
                        $sql_find_dest = "SELECT u.id_usuario, u.nm_usuario, c.id_conta FROM tb_usuario u JOIN tb_conta c ON u.id_usuario = c.id_usuario WHERE u.ds_email = ?";
                    } elseif ($type_identifier === 'account_number') {
                        $sql_find_dest = "SELECT u.id_usuario, u.nm_usuario, c.id_conta FROM tb_usuario u JOIN tb_conta c ON u.id_usuario = c.id_usuario WHERE c.nr_conta = ?";
                    }

                    $stmt_find_dest = $pdo->prepare($sql_find_dest);
                    $stmt_find_dest->execute($params);
                    $dest_data = $stmt_find_dest->fetch(PDO::FETCH_ASSOC);

                    if ($dest_data) {
                        if ($dest_data['id_usuario'] === $user_id) {
                            set_message("Você não pode transferir para si mesmo.", "error");
                            $pdo->rollBack();
                            goto end_of_post_logic; // Salta para o final para re-buscar saldos
                        }
                        $dest_user_id = $dest_data['id_usuario'];
                        $dest_user_name = htmlspecialchars($dest_data['nm_usuario']);
                        $is_internal_transfer = true;
                    } else {
                        // Se não encontrou usuário interno, e o tipo não é externo, é um erro.
                        set_message("Destinatário interno não encontrado com o identificador fornecido. Verifique o tipo e o valor.", "error");
                        $pdo->rollBack();
                        goto end_of_post_logic; // Salta para o final para re-buscar saldos
                    }
                    break;

                case 'external_pix_key':
                case 'external_bitcoin_address':
                    // Transferência externa
                    $is_internal_transfer = false;
                    $dest_user_id = null; // Não há id_usuario para destinatário externo
                    $dest_user_name = "Destinatário Externo"; // Nome genérico para log
                    break;

                default:
                    set_message("Tipo de identificador inválido.", "error");
                    $pdo->rollBack();
                    goto end_of_post_logic; // Salta para o final para re-buscar saldos
            }

            $transfer_successful = false;
            $transaction_type_sender = '';
            $transaction_type_receiver = ''; // Só para transações internas
            $payment_method = '';
            $status_for_log = 'Concluída'; // Status padrão para transações internas
            $description_prefix = "";

            if ($currency === 'BRL') {
                $transaction_type_sender = ($is_internal_transfer ? 'PIX Enviado' : 'PIX Externo Enviado');
                $payment_method = 'PIX';
                if ($amount > $current_real_balance) {
                    set_message("Saldo em Reais insuficiente para a transferência.", "error");
                } else {
                    // Atualiza saldo do remetente
                    $new_sender_balance = $current_real_balance - $amount;
                    $stmt_update_sender = $pdo->prepare("UPDATE tb_conta SET vl_saldo_real = ? WHERE id_usuario = ?");
                    $stmt_update_sender->execute([$new_sender_balance, $user_id]);

                    if ($is_internal_transfer) {
                        // Atualiza saldo do destinatário (apenas para transferências internas)
                        $stmt_update_dest = $pdo->prepare("UPDATE tb_conta SET vl_saldo_real = vl_saldo_real + ? WHERE id_usuario = ?");
                        $stmt_update_dest->execute([$amount, $dest_user_id]);
                        $transaction_type_receiver = 'PIX Recebido';
                        set_message("Transferência PIX de R$ " . number_format($amount, 2, ',', '.') . " para " . $dest_user_name . " realizada com sucesso!", "success");
                    } else {
                        // Para transferências externas, o status pode ser diferente
                        $status_for_log = 'Processando'; // Pode ser 'Pendente' ou 'Processando' para externa
                        set_message("Envio PIX externo de R$ " . number_format($amount, 2, ',', '.') . " para '" . htmlspecialchars($target_identifier) . "' iniciado e está " . $status_for_log . ".", "info");
                    }
                    $transfer_successful = true;
                }
            } elseif ($currency === 'BTC') {
                $transaction_type_sender = ($is_internal_transfer ? 'Transferência Bitcoin' : 'Bitcoin Externo Enviado');
                $payment_method = 'Transferência Bitcoin';
                if ($amount > $current_bitcoin_balance) {
                    set_message("Saldo em Bitcoin insuficiente para a transferência.", "error");
                } else {
                    // Atualiza saldo do remetente
                    $new_sender_balance = $current_bitcoin_balance - $amount;
                    $stmt_update_sender = $pdo->prepare("UPDATE tb_conta SET vl_saldo_bitcoin = ? WHERE id_usuario = ?");
                    $stmt_update_sender->execute([$new_sender_balance, $user_id]);

                    if ($is_internal_transfer) {
                        // Atualiza saldo do destinatário (apenas para transferências internas)
                        $stmt_update_dest = $pdo->prepare("UPDATE tb_conta SET vl_saldo_bitcoin = vl_saldo_bitcoin + ? WHERE id_usuario = ?");
                        $stmt_update_dest->execute([$amount, $dest_user_id]);
                        $transaction_type_receiver = 'Bitcoin Recebido';
                        set_message("Transferência de " . number_format($amount, 8, ',', '.') . " BTC para " . $dest_user_name . " realizada com sucesso!", "success");
                    } else {
                        // Para transferências externas, o status pode ser diferente
                        $status_for_log = 'Pendente'; // Pode ser 'Pendente' ou 'Processando' para externa
                        set_message("Envio Bitcoin externo de " . number_format($amount, 8, ',', '.') . " BTC para '" . htmlspecialchars($target_identifier) . "' iniciado e está " . $status_for_log . ".", "info");
                    }
                    $transfer_successful = true;
                }
            }

            if ($transfer_successful) {
                // Logar a transação para o remetente
                $tx_description_sender = "Transferência para " . ($is_internal_transfer ? $dest_user_name : htmlspecialchars($target_identifier)) . ". Descrição: " . htmlspecialchars($description);
                $stmt_log_sender = $pdo->prepare("
                    INSERT INTO tb_transacao (tp_tipo, tp_metodo_pagamento, id_remetente, id_destinatario, vl_quantidade_real, vl_quantidade_bitcoin, ds_status, dt_transacao, ds_descricao)
                    VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?)
                ");
                $stmt_log_sender->execute([
                    $transaction_type_sender,
                    $payment_method,
                    $user_id,
                    $dest_user_id, // Será NULL para transferências externas
                    ($currency === 'BRL' ? $amount : 0),
                    ($currency === 'BTC' ? $amount : 0),
                    $status_for_log, // Usar o status determinado acima
                    $tx_description_sender
                ]);

                if ($is_internal_transfer) {
                    // Logar a transação para o destinatário (apenas para transferências internas)
                    $tx_description_receiver = "Recebimento de " . $userName . ". Descrição: " . htmlspecialchars($description);
                    $stmt_log_receiver = $pdo->prepare("
                        INSERT INTO tb_transacao (tp_tipo, tp_metodo_pagamento, id_remetente, id_destinatario, vl_quantidade_real, vl_quantidade_bitcoin, ds_status, dt_transacao, ds_descricao)
                        VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?)
                    ");
                    $stmt_log_receiver->execute([
                        $transaction_type_receiver,
                        $payment_method,
                        $user_id, // Remetente da perspectiva do recebedor
                        $dest_user_id,
                        ($currency === 'BRL' ? $amount : 0),
                        ($currency === 'BTC' ? $amount : 0),
                        'Concluída',
                        $tx_description_receiver
                    ]);
                }

                $pdo->commit();
                redirect('dashboard.php'); // Redireciona para o dashboard após sucesso
            } else {
                $pdo->rollBack(); // Rollback se houve erro de saldo
            }
        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log("Erro na operação de transferência: " . $e->getMessage());
            set_message("Ocorreu um erro na sua solicitação de transferência: " . $e->getMessage(), "error");
        }
    }
    // Label para saltar para aqui após erros de POST
    end_of_post_logic:;
    // Re-busca os saldos para que a página exiba os valores corretos após o erro ou redirecionamento falho
    try {
        $stmt_balance = $pdo->prepare("SELECT vl_saldo_bitcoin, vl_saldo_real FROM tb_conta WHERE id_usuario = ?");
        $stmt_balance->execute([$user_id]);
        $account_data = $stmt_balance->fetch(PDO::FETCH_ASSOC);
        if ($account_data) {
            $current_bitcoin_balance = $account_data['vl_saldo_bitcoin'];
            $current_real_balance = $account_data['vl_saldo_real'];
        }
    } catch (PDOException $e) {
        error_log("Erro ao re-buscar saldos após POST (transfer): " . $e->getMessage());
    }
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fazer Transferência - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .transfer-form-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 20px;
            margin-bottom: 20px;
        }
        .transfer-form-grid label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: var(--text-color);
        }
        .transfer-form-grid input[type="text"],
        .transfer-form-grid input[type="number"],
        .transfer-form-grid select,
        .transfer-form-grid textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 1em;
            box-sizing: border-box;
        }
        .current-balances {
            background-color: var(--light-gray);
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 25px;
            text-align: center;
            font-size: 1.1em;
            color: var(--text-color);
        }
        .current-balances strong {
            color: var(--primary-dark-color);
        }
        small {
            font-size: 0.8em;
            color: #666;
            margin-top: -10px;
            display: block;
        }
        /* Removido .simulation-warning pois o usuário pediu para tirar */

        @media (min-width: 600px) {
            .transfer-form-grid {
                grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            }
            .transfer-form-grid .full-width {
                grid-column: 1 / -1; /* Ocupa a largura total */
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li>Olá, <?= $userName ?></li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container">
            <h2>Fazer Transferência</h2>
            <?php display_messages(); ?>

            <div class="current-balances">
                Seu Saldo em Reais: <strong>R$ <?= htmlspecialchars(number_format($current_real_balance, 2, ',', '.')) ?></strong><br>
                Seu Saldo em Bitcoin: <strong><?= htmlspecialchars(number_format($current_bitcoin_balance, 8, ',', '.')) ?> BTC</strong>
            </div>

            <form action="transfer.php" method="POST">
                <div class="transfer-form-grid">
                    <div>
                        <label for="currency">Moeda da Transferência:</label>
                        <select id="currency" name="currency" required>
                            <option value="">Selecione a Moeda</option>
                            <option value="BRL">Reais (PIX)</option>
                            <option value="BTC">Bitcoin</option>
                        </select>
                        <small>Selecione a moeda para a transferência.</small>
                    </div>
                     <div>
                        <label for="type_identifier">Tipo de Identificador:</label>
                        <select id="type_identifier" name="type_identifier" required>
                            <option value="">Selecione o Tipo</option>
                            <!-- Opções preenchidas via JavaScript -->
                        </select>
                        <small id="type_identifier_help_text">Selecione a moeda primeiro.</small>
                    </div>
                    <div class="full-width">
                        <label for="target_identifier">Identificador do Destinatário:</label>
                        <input type="text" id="target_identifier" name="target_identifier" placeholder="Aguardando seleção do tipo de identificador..." required>
                        <small id="target_identifier_help_text">Insira o identificador do destinatário.</small>
                    </div>
                    <div>
                        <label for="amount">Quantidade:</label>
                        <input type="number" step="0.01" id="amount" name="amount" placeholder="Valor a transferir" required min="0.01">
                    </div>
                    <div class="full-width">
                        <label for="description">Descrição (Opcional):</label>
                        <textarea id="description" name="description" rows="3" placeholder="Ex: Pagamento aluguel, Presente, etc."></textarea>
                    </div>
                </div>
                <button type="submit" class="button primary">Confirmar Transferência</button>
            </form>

            <p style="margin-top: 30px;"><a href="dashboard.php">Voltar para o Dashboard</a></p>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const currencySelect = document.getElementById('currency');
            const typeIdentifierSelect = document.getElementById('type_identifier');
            const targetIdentifierInput = document.getElementById('target_identifier');
            const typeIdentifierHelpText = document.getElementById('type_identifier_help_text');
            const targetIdentifierHelpText = document.getElementById('target_identifier_help_text');

            const identifierOptions = {
                'BRL': [
                    { value: '', text: 'Selecione o Tipo' },
                    { value: 'email', text: 'E-mail (Interno)' },
                    { value: 'cpf', text: 'CPF (Interno - Apenas números)' },
                    { value: 'account_number', text: 'Número da Conta (Interno)' },
                    { value: 'external_pix_key', text: 'Chave PIX Externa' }
                ],
                'BTC': [
                    { value: '', text: 'Selecione o Tipo' },
                    { value: 'bitcoin_address', text: 'Endereço Bitcoin (Interno)' },
                    { value: 'external_bitcoin_address', text: 'Endereço Bitcoin (Externo)' }
                ]
            };

            const placeholderTexts = {
                '': 'Aguardando seleção do tipo de identificador...',
                'email': 'Digite o e-mail do destinatário interno...',
                'cpf': 'Digite o CPF do destinatário interno (apenas números)...',
                'account_number': 'Digite o número da conta do destinatário interno...',
                'external_pix_key': 'Digite a chave PIX externa (CPF, CNPJ, E-mail, Telefone, Aleatória)...',
                'bitcoin_address': 'Digite o endereço Bitcoin do destinatário interno...',
                'external_bitcoin_address': 'Digite o endereço Bitcoin externo...'
            };

            const helpTexts = {
                '': 'Selecione a moeda primeiro.',
                'email': 'Para transferências entre usuários Bank Lopes via e-mail.',
                'cpf': 'Para transferências entre usuários Bank Lopes via CPF.',
                'account_number': 'Para transferências entre usuários Bank Lopes via número da conta.',
                'external_pix_key': 'Insira a chave PIX (CPF, CNPJ, E-mail, Telefone, Aleatória) para envio externo.',
                'bitcoin_address': 'Para transferir Bitcoin para outro usuário Bank Lopes.',
                'external_bitcoin_address': 'Insira o endereço Bitcoin para envio externo.'
            };


            function updateIdentifierOptions() {
                const selectedCurrency = currencySelect.value;
                typeIdentifierSelect.innerHTML = ''; // Limpa as opções atuais
                targetIdentifierInput.value = ''; // Limpa o identificador
                targetIdentifierInput.placeholder = placeholderTexts['']; // Reseta placeholder
                targetIdentifierHelpText.textContent = helpTexts['']; // Reseta texto de ajuda

                if (selectedCurrency && identifierOptions[selectedCurrency]) {
                    identifierOptions[selectedCurrency].forEach(optionData => {
                        const option = document.createElement('option');
                        option.value = optionData.value;
                        option.textContent = optionData.text;
                        typeIdentifierSelect.appendChild(option);
                    });
                    typeIdentifierSelect.disabled = false;
                    typeIdentifierHelpText.textContent = 'Agora selecione o tipo de identificador.';
                } else {
                    typeIdentifierSelect.disabled = true;
                    typeIdentifierHelpText.textContent = 'Selecione a moeda primeiro.';
                }
            }

            function updateTargetIdentifierInfo() {
                const selectedType = typeIdentifierSelect.value;
                targetIdentifierInput.placeholder = placeholderTexts[selectedType] || placeholderTexts[''];
                targetIdentifierHelpText.textContent = helpTexts[selectedType] || helpTexts[''];
            }

            // Event Listeners
            currencySelect.addEventListener('change', updateIdentifierOptions);
            typeIdentifierSelect.addEventListener('change', updateTargetIdentifierInfo);

            // Inicializa as opções no carregamento da página
            updateIdentifierOptions();
        });
    </script>
</body>
</html>

<?php
// www/pages/admin_add_user.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Verifica se o administrador está logado.
if (!isset($_SESSION['admin_id'])) {
    set_message("Você precisa estar logado como administrador para acessar esta área.", "error");
    redirect('admin_login.php');
}

$admin_name = htmlspecialchars($_SESSION['admin_name'] ?? 'Administrador');
$admin_level = htmlspecialchars($_SESSION['admin_level'] ?? 'Nível Desconhecido');

// Lógica para processar o formulário de adição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nm_usuario = trim(isset($_POST['nm_usuario']) ? $_POST['nm_usuario'] : '');
    $ds_email = trim(isset($_POST['ds_email']) ? $_POST['ds_email'] : '');
    $ds_cpf = trim(isset($_POST['ds_cpf']) ? $_POST['ds_cpf'] : '');
    $ds_senha = trim(isset($_POST['ds_senha']) ? $_POST['ds_senha'] : '');
    $confirm_senha = trim(isset($_POST['confirm_senha']) ? $_POST['confirm_senha'] : '');
    $dt_nascimento = trim(isset($_POST['dt_nascimento']) ? $_POST['dt_nascimento'] : '');
    $ds_telefone = trim(isset($_POST['ds_telefone']) ? $_POST['ds_telefone'] : '');
    $ds_endereco = trim(isset($_POST['ds_endereco']) ? $_POST['ds_endereco'] : '');
    $ds_cidade = trim(isset($_POST['ds_cidade']) ? $_POST['ds_cidade'] : '');
    $ds_estado = trim(isset($_POST['ds_estado']) ? $_POST['ds_estado'] : '');
    $ds_pais_origem = trim(isset($_POST['ds_pais_origem']) ? $_POST['ds_pais_origem'] : 'Brasil');
    $ds_status = trim(isset($_POST['ds_status']) ? $_POST['ds_status'] : 'Ativo'); // Status padrão para novos usuários

    // Validações
    $errors = [];
    if (empty($nm_usuario)) $errors[] = "O nome do usuário é obrigatório.";
    if (empty($ds_email) || !is_valid_email($ds_email)) $errors[] = "O e-mail é inválido ou obrigatório.";
    if (empty($ds_cpf) || !is_valid_cpf($ds_cpf)) $errors[] = "O CPF é inválido ou obrigatório.";
    if (empty($ds_senha) || strlen($ds_senha) < 8) $errors[] = "A senha deve ter no mínimo 8 caracteres.";
    if ($ds_senha !== $confirm_senha) $errors[] = "As senhas não coincidem.";
    if (empty($dt_nascimento)) $errors[] = "A data de nascimento é obrigatória.";
    if (empty($ds_status)) $errors[] = "O status do usuário é obrigatório.";
    if (!in_array($ds_status, ['Ativo', 'Inativo', 'Bloqueado'])) $errors[] = "Status inválido.";

    // Verifica se o e-mail já existe
    if (empty($errors)) {
        $stmt_email_check = $pdo->prepare("SELECT COUNT(*) FROM tb_usuario WHERE ds_email = ?");
        $stmt_email_check->execute([$ds_email]);
        if ($stmt_email_check->fetchColumn() > 0) {
            $errors[] = "Este e-mail já está cadastrado.";
        }
    }
    
    // Verifica se o CPF já existe
    if (empty($errors)) {
        $stmt_cpf_check = $pdo->prepare("SELECT COUNT(*) FROM tb_usuario WHERE ds_cpf = ?");
        $stmt_cpf_check->execute([$ds_cpf]);
        if ($stmt_cpf_check->fetchColumn() > 0) {
            $errors[] = "Este CPF já está cadastrado.";
        }
    }

    if (!empty($errors)) {
        foreach ($errors as $error) {
            set_message($error, "error");
        }
    } else {
        $password_hash = password_hash($ds_senha, PASSWORD_DEFAULT);
        $dt_cadastro = date('Y-m-d H:i:s');

        try {
            $pdo->beginTransaction();

            // Insere os dados do usuário
            $user_stmt = $pdo->prepare("
                INSERT INTO tb_usuario (nm_usuario, ds_email, ds_cpf, ds_senha_hash, dt_nascimento, ds_telefone, ds_endereco, ds_cidade, ds_estado, ds_pais_origem, ds_status, dt_cadastro)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            if ($user_stmt->execute([
                $nm_usuario,
                $ds_email,
                $ds_cpf,
                $password_hash,
                $dt_nascimento,
                $ds_telefone,
                $ds_endereco,
                $ds_cidade,
                $ds_estado,
                $ds_pais_origem,
                $ds_status,
                $dt_cadastro
            ])) {
                $new_user_id = $pdo->lastInsertId();

                // Cria a conta padrão para o novo usuário
                $account_stmt = $pdo->prepare("
                    INSERT INTO tb_conta (id_usuario, vl_saldo_real, vl_saldo_bitcoin)
                    VALUES (?, ?, ?)
                ");
                if ($account_stmt->execute([$new_user_id, 0.00, 0.00000000])) {
                    $pdo->commit();
                    set_message("Novo usuário adicionado com sucesso!", "success");
                    redirect('admin_manage_users.php');
                } else {
                    $pdo->rollBack();
                    set_message("Erro ao criar conta para o novo usuário. Tente novamente.", "error");
                }
            } else {
                $pdo->rollBack();
                set_message("Não foi possível adicionar o novo usuário. Ocorreu um erro no banco de dados.", "error");
            }
        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log("Erro ao adicionar novo usuário: " . $e->getMessage());
            set_message("Ocorreu um erro ao adicionar o usuário. Verifique os logs.", "error");
        }
    }
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adicionar Novo Usuário - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .form-container form {
            max-width: 600px;
            margin: 20px auto;
            padding: 30px;
            background-color: var(--secondary-color);
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .form-container form .form-group {
            margin-bottom: 15px;
        }

        .form-container form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: var(--primary-dark-color);
        }

        .form-container form input[type="text"],
        .form-container form input[type="email"],
        .form-container form input[type="password"],
        .form-container form input[type="date"],
        .form-container form input[type="tel"],
        .form-container form select {
            width: calc(100% - 20px); /* Ajusta para padding */
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 5px;
            font-size: 1em;
        }

        .form-container form .form-row {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
        }
        .form-container form .form-row > div {
            flex: 1;
        }

        .form-container form .button-group {
            margin-top: 25px;
            text-align: center;
        }

        .form-container form .button-group .button {
            margin: 0 10px;
        }
        
        .form-container form .description {
            font-size: 0.85em;
            color: #666;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Admin Bank Lopes</div>
            <nav>
                <ul>
                    <li>Olá, <?= $admin_name ?>! (<?= $admin_level ?>)</li>
                    <li><a href="admin_dashboard.php">Dashboard</a></li>
                    <li><a href="admin_manage_users.php" class="active">Gerenciar Usuários</a></li>
                    <li><a href="admin_manage_fees.php">Gerenciar Taxas</a></li>
                    <li><a href="admin_view_transactions.php">Transações</a></li>
                    <li><a href="admin_logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="container">
            <h2>Adicionar Novo Usuário</h2>
            <?php display_messages(); ?>

            <div class="form-container">
                <form action="admin_add_user.php" method="POST">
                    <div class="form-group">
                        <label for="nm_usuario">Nome Completo:</label>
                        <input type="text" id="nm_usuario" name="nm_usuario" value="<?= htmlspecialchars(isset($_POST['nm_usuario']) ? $_POST['nm_usuario'] : '') ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="ds_email">E-mail:</label>
                        <input type="email" id="ds_email" name="ds_email" value="<?= htmlspecialchars(isset($_POST['ds_email']) ? $_POST['ds_email'] : '') ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="ds_cpf">CPF:</label>
                        <input type="text" id="ds_cpf" name="ds_cpf" placeholder="Ex: 123.456.789-00" required value="<?= htmlspecialchars(isset($_POST['ds_cpf']) ? $_POST['ds_cpf'] : '') ?>">
                        <p class="description">Use apenas números ou o formato XXX.XXX.XXX-XX.</p>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="ds_senha">Senha:</label>
                            <input type="password" id="ds_senha" name="ds_senha" required>
                            <p class="description">Mínimo de 8 caracteres.</p>
                        </div>
                        <div class="form-group">
                            <label for="confirm_senha">Confirmar Senha:</label>
                            <input type="password" id="confirm_senha" name="confirm_senha" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="dt_nascimento">Data de Nascimento:</label>
                            <input type="date" id="dt_nascimento" name="dt_nascimento" value="<?= htmlspecialchars(isset($_POST['dt_nascimento']) ? $_POST['dt_nascimento'] : '') ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="ds_telefone">Telefone:</label>
                            <input type="tel" id="ds_telefone" name="ds_telefone" value="<?= htmlspecialchars(isset($_POST['ds_telefone']) ? $_POST['ds_telefone'] : '') ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="ds_endereco">Endereço:</label>
                        <input type="text" id="ds_endereco" name="ds_endereco" value="<?= htmlspecialchars(isset($_POST['ds_endereco']) ? $_POST['ds_endereco'] : '') ?>">
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="ds_cidade">Cidade:</label>
                            <input type="text" id="ds_cidade" name="ds_cidade" value="<?= htmlspecialchars(isset($_POST['ds_cidade']) ? $_POST['ds_cidade'] : '') ?>">
                        </div>
                        <div class="form-group">
                            <label for="ds_estado">Estado:</label>
                            <input type="text" id="ds_estado" name="ds_estado" value="<?= htmlspecialchars(isset($_POST['ds_estado']) ? $_POST['ds_estado'] : '') ?>" maxlength="2">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="ds_pais_origem">País de Origem:</label>
                        <input type="text" id="ds_pais_origem" name="ds_pais_origem" value="<?= htmlspecialchars(isset($_POST['ds_pais_origem']) ? $_POST['ds_pais_origem'] : 'Brasil') ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="ds_status">Status Inicial:</label>
                        <select id="ds_status" name="ds_status" required>
                            <option value="Ativo" selected>Ativo</option>
                            <option value="Inativo">Inativo</option>
                            <option value="Bloqueado">Bloqueado</option>
                        </select>
                    </div>

                    <div class="button-group">
                        <button type="submit" class="button primary">Adicionar Usuário</button>
                        <a href="admin_manage_users.php" class="button secondary">Cancelar</a>
                    </div>
                </form>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>
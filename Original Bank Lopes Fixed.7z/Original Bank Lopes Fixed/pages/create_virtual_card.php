<?php
// www/pages/create_virtual_card.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Exibição de erros para depuração (MUITO IMPORTANTE: REMOVER EM PRODUÇÃO!)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Verifica se o usuário está logado.
if (!isset($_SESSION['user_id'])) {
    set_message("Você precisa estar logado para criar um cartão virtual.", "error");
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$userName = htmlspecialchars($_SESSION['user_name'] ?? 'Usuário');

// Lógica para gerar os dados do cartão virtual
$card_type = 'Virtual';
$card_brand = 'Bank Lopes Virtual';

// Gerar número de cartão simulado (16 dígitos) e tokenizar
$generated_card_number_full = '';
for ($i = 0; $i < 16; ++$i) {
    $generated_card_number_full .= mt_rand(0, 9);
}
$tokenized_card_number = '**** **** **** ' . substr($generated_card_number_full, -4);

// Gerar data de validade (ex: 3 anos a partir de agora)
$expiry_date = date('Y-m-d', strtotime('+3 years'));

// Gerar CVV (3 dígitos para cartões virtuais comuns)
$generated_cvv = str_pad(mt_rand(0, 999), 3, '0', STR_PAD_LEFT);

// Tentar adicionar o cartão ao banco de dados
try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("
        INSERT INTO tb_informacao_cartao (
            id_usuario,
            tp_tipo,
            nr_cartao_tokenizado,
            nm_titular,
            dt_validade,
            ds_bandeira,
            dt_cadastro
        ) VALUES (?, ?, ?, ?, ?, ?, NOW())
    ");

    $stmt->execute([
        $user_id,
        $card_type,
        $tokenized_card_number,
        $userName,
        $expiry_date,
        $card_brand
    ]);

    set_message("Cartão virtual '" . htmlspecialchars($card_brand) . "' com final " . substr($tokenized_card_number, -4) . " criado com sucesso!", "success");
    $pdo->commit();
    redirect('my_cards.php'); // Redireciona de volta para a lista de cartões
} catch (PDOException $e) {
    $pdo->rollBack();
    error_log("Erro ao criar cartão virtual (PDO): " . $e->getMessage());
    set_message("Ocorreu um erro ao criar o cartão virtual: " . $e->getMessage(), "error");
    redirect('my_cards.php');
}

// O restante do HTML desta página será mínimo, pois ela deve apenas processar e redirecionar.
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Processando Criação de Cartão Virtual - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            background-color: var(--background-color);
            color: var(--text-color);
            font-family: 'Inter', sans-serif;
        }
        .loading-message {
            background-color: var(--secondary-color);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
            text-align: center;
            font-size: 1.2em;
            color: var(--primary-dark-color);
        }
    </style>
</head>
<body>
    <div class="loading-message">
        <p>Processando a criação do seu cartão virtual...</p>
        <p>Você será redirecionado(a) em breve.</p>
    </div>
</body>
</html>

<?php
// www/pages/admin_view_transactions.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Verifica se o administrador está logado. Se não, redireciona para a página de login do admin.
if (!isset($_SESSION['admin_id'])) {
    set_message("Você precisa estar logado como administrador para acessar esta área.", "error");
    redirect('admin_login.php');
}

$admin_name = htmlspecialchars($_SESSION['admin_name'] ?? 'Administrador');
$admin_level = htmlspecialchars($_SESSION['admin_level'] ?? 'Nível Desconhecido');

$transactions = [];
try {
    // Busca todas as transações, incluindo informações básicas de remetente/destinatário (se houver)
    $stmt = $pdo->query("
        SELECT
            t.id_transacao,
            t.tp_tipo,
            t.tp_metodo_pagamento,
            u_rem.nm_usuario AS remetente_nome,
            u_dest.nm_usuario AS destinatario_nome,
            t.vl_quantidade_real,
            t.vl_quantidade_bitcoin,
            t.vl_taxa,
            t.ds_status,
            t.dt_transacao
        FROM
            tb_transacao t
        LEFT JOIN
            tb_usuario u_rem ON t.id_remetente = u_rem.id_usuario
        LEFT JOIN
            tb_usuario u_dest ON t.id_destinatario = u_dest.id_usuario
        ORDER BY
            t.dt_transacao DESC
    ");
    $transactions = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Erro ao buscar transações para visualização: " . $e->getMessage());
    set_message("Ocorreu um erro ao carregar a lista de transações.", "error");
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Todas as Transações - Admin - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        /* Estilos específicos para esta página */
        .admin-table-container {
            background-color: var(--secondary-color);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
            margin-top: 40px;
            overflow-x: auto; /* Para tabelas grandes em telas pequenas */
        }
        .admin-table-container h2 {
            text-align: left;
            margin-bottom: 30px;
            color: var(--primary-dark-color);
            font-size: 2em;
        }
        .admin-table {
            width: 100%;
            min-width: 800px; /* Garante que a tabela não fique muito estreita */
            border-collapse: collapse;
        }
        .admin-table th, .admin-table td {
            border: 1px solid var(--border-color);
            padding: 12px;
            text-align: left;
            font-size: 0.95em;
        }
        .admin-table th {
            background-color: var(--light-gray);
            font-weight: bold;
            color: var(--text-color);
        }
        .admin-table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .admin-table tbody tr:hover {
            background-color: #eef;
        }
        @media (max-width: 768px) {
            .admin-table-container {
                padding: 15px;
            }
            .admin-table {
                min-width: unset; /* Remove min-width em telas pequenas */
            }
            .admin-table th, .admin-table td {
                padding: 8px;
                font-size: 0.8em;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="admin_dashboard.php">Dashboard Admin</a></li>
                    <li>Olá, Admin <?= $admin_name ?> (Nível: <?= $admin_level ?>)</li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container admin-table-container">
            <h2>Todas as Transações</h2>
            <?php display_messages(); ?>

            <?php if (!empty($transactions)): ?>
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID Trans.</th>
                            <th>Tipo</th>
                            <th>Método</th>
                            <th>Remetente</th>
                            <th>Destinatário</th>
                            <th>Valor (R$)</th>
                            <th>Valor (BTC)</th>
                            <th>Taxa</th>
                            <th>Status</th>
                            <th>Data</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($transactions as $transaction): ?>
                            <tr>
                                <td><?= htmlspecialchars($transaction['id_transacao']) ?></td>
                                <td><?= htmlspecialchars($transaction['tp_tipo']) ?></td>
                                <td><?= htmlspecialchars($transaction['tp_metodo_pagamento']) ?></td>
                                <td><?= htmlspecialchars($transaction['remetente_nome'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($transaction['destinatario_nome'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars(number_format($transaction['vl_quantidade_real'], 2, ',', '.')) ?></td>
                                <td><?= htmlspecialchars(number_format($transaction['vl_quantidade_bitcoin'], 8, ',', '.')) ?></td>
                                <td><?= htmlspecialchars(number_format($transaction['vl_taxa'], 8, ',', '.')) ?></td>
                                <td><?= htmlspecialchars($transaction['ds_status']) ?></td>
                                <td><?= htmlspecialchars(date('d/m/Y H:i', strtotime($transaction['dt_transacao']))) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Nenhuma transação encontrada no sistema.</p>
            <?php endif; ?>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>

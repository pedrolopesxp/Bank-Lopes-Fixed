<?php
// www/pages/deposit_withdraw.php

session_start();
// ATIVAR EXIBIÇÃO DE ERROS PARA DEBUGGING (REMOVER EM PRODUÇÃO!)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php'; // Garante que functions.php seja carregado

// Verifica se o usuário está logado.
if (!isset($_SESSION['user_id'])) {
    set_message("Você precisa estar logado para depositar ou sacar.", "error");
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$userName = htmlspecialchars($_SESSION['user_name'] ?? 'Usuário');

$current_real_balance = 0;
$current_bitcoin_balance = 0;
$user_pix_keys = []; // Inicializa array para chaves PIX do usuário

try {
    $stmt_balance = $pdo->prepare("SELECT vl_saldo_bitcoin, vl_saldo_real FROM tb_conta WHERE id_usuario = ?");
    $stmt_balance->execute([$user_id]);
    $account_data = $stmt_balance->fetch(PDO::FETCH_ASSOC);
    if ($account_data) {
        $current_bitcoin_balance = $account_data['vl_saldo_bitcoin'];
        $current_real_balance = $account_data['vl_saldo_real'];
    }

    // Buscar chaves PIX do usuário
    $stmt_pix = $pdo->prepare("SELECT ch_chave_pix, tp_tipo_chave FROM tb_informacao_pix WHERE id_usuario = ? AND bo_principal = 1 LIMIT 1");
    $stmt_pix->execute([$user_id]);
    $user_pix_keys = $stmt_pix->fetch(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Erro ao carregar dados: " . $e->getMessage());
    set_message("Erro ao carregar dados. Tente novamente.", "error");
}

// --- Lógica de Processamento de Formulário ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_STRING);
    $method = filter_input(INPUT_POST, 'method', FILTER_SANITIZE_STRING);
    $amount = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);

    if (!$amount || $amount <= 0) {
        set_message("O valor deve ser positivo e numérico.", "error");
        redirect('deposit_withdraw.php');
    }

    // Ações de Saque (Retirada)
    if ($action === 'withdraw') {
        if ($method === 'pix') {
            // Lógica de saque PIX (Corrente -> Destino Externo)
            // Validações e processamento aqui
            set_message("Saque PIX de R$ " . number_format($amount, 2, ',', '.') . " processado com sucesso (SIMULADO).", "success");
        } elseif ($method === 'ted') {
            // Lógica de saque TED (Corrente -> Destino Externo)
            $recipient_bank = filter_input(INPUT_POST, 'recipient_bank', FILTER_SANITIZE_STRING);
            $recipient_agency = filter_input(INPUT_POST, 'recipient_agency', FILTER_SANITIZE_STRING);
            $recipient_account = filter_input(INPUT_POST, 'recipient_account', FILTER_SANITIZE_STRING);
            $recipient_cpf_cnpj = filter_input(INPUT_POST, 'recipient_cpf_cnpj', FILTER_SANITIZE_STRING);
            
            // Validações de saldo e dados bancários aqui...
            // Por enquanto, apenas simulação:
            set_message("Saque TED de R$ " . number_format($amount, 2, ',', '.') . " para " . $recipient_bank . " processado com sucesso (SIMULADO).", "success");
        } elseif ($method === 'bitcoin') {
            // Lógica de saque Bitcoin
            $bitcoin_address = filter_input(INPUT_POST, 'bitcoin_address', FILTER_SANITIZE_STRING);
            
            // Validações de saldo BTC e endereço aqui...
            // Por enquanto, apenas simulação:
            set_message("Saque de " . number_format($amount, 8, ',', '.') . " BTC para " . substr($bitcoin_address, 0, 10) . "... processado com sucesso (SIMULADO).", "success");
        } else {
            set_message("Método de saque inválido.", "error");
        }
    } 
    // Ações de Depósito (Entrada)
    elseif ($action === 'deposit') {
        if ($method === 'pix') {
            // Lógica de depósito PIX (Origem Externa -> Corrente)
            // Basta exibir a chave PIX do usuário
            set_message("Instruções para Depósito PIX exibidas. Após o pagamento, o valor será creditado.", "info");
        } elseif ($method === 'ted') {
            // Lógica de depósito TED (Origem Externa -> Corrente)
            // Basta exibir os dados bancários do banco para o depósito
            set_message("Instruções para Depósito TED exibidas. Use os dados da conta do Bank Lopes.", "info");
        } elseif ($method === 'bitcoin') {
            // Lógica de depósito Bitcoin
            // Basta exibir o endereço Bitcoin do banco/usuário
            set_message("Instruções para Depósito Bitcoin exibidas. Envie para o endereço fornecido.", "info");
        } else {
            set_message("Método de depósito inválido.", "error");
        }
    } else {
        set_message("Ação inválida.", "error");
    }
    
    redirect('deposit_withdraw.php');
}


// --- Variáveis simuladas para o frontend ---
// Estes dados seriam dinâmicos em um sistema real
$bankAccountInfo = [
    'nm_banco' => 'Bank Lopes',
    'nr_agencia' => '0001',
    'nr_conta' => '123456-7',
    'ds_cpf_cnpj' => '00.000.000/0001-00',
    'nm_titular' => 'Bank Lopes S.A.'
];
$bankBitcoinAddress = 'bc1ql27v87g5s0j28p7x0d8f3k2q1j9y8m4h0g'; // Endereço simulado
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Depósito e Saque - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        .dw-container {
            max-width: 800px;
            margin: 40px auto;
            padding: 30px;
            background-color: var(--secondary-color);
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }
        .tab-buttons {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
            gap: 10px;
        }
        .tab-buttons button {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            background-color: var(--input-bg-color);
            color: var(--text-color);
            transition: background-color 0.3s, color 0.3s;
        }
        .tab-buttons button.active {
            background-color: var(--primary-color);
            color: white;
            font-weight: bold;
        }
        .form-section {
            display: none;
            border: 1px solid var(--border-color);
            padding: 20px;
            border-radius: 10px;
        }
        .form-section.active {
            display: block;
        }
        .method-selection {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 20px;
        }
        .method-selection label {
            background-color: var(--input-bg-color);
            padding: 15px;
            border-radius: 10px;
            cursor: pointer;
            border: 2px solid transparent;
            transition: border-color 0.3s, background-color 0.3s;
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: bold;
        }
        .method-selection input[type="radio"]:checked + label {
            border-color: var(--primary-color);
            background-color: var(--hover-color);
        }
        .method-selection input[type="radio"] {
            display: none;
        }
        .method-details {
            border-top: 1px dashed var(--border-color);
            padding-top: 20px;
            margin-top: 20px;
        }
        .bank-details {
            background-color: var(--input-bg-color);
            padding: 15px;
            border-radius: 8px;
            margin-top: 10px;
        }
        .bank-details p {
            margin: 5px 0;
        }
        .copy-button {
            margin-left: 10px;
            background: none;
            border: none;
            color: var(--highlight-color);
            cursor: pointer;
            font-size: 1em;
            padding: 0;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>Bank Lopes</h1>
            <nav>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="deposit_withdraw.php" class="active">Depósito/Saque</a></li>
                    <li><a href="transfer.php">Transferir</a></li>
                    <li><a href="transaction_history.php">Histórico</a></li>
                    <li>Olá, <?= $userName ?>!</li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <div class="dw-container">
            <?php display_messages(); ?>
            <h1><i class="fa-solid fa-money-bill-transfer"></i> Depósito e Saque</h1>
            <hr>

            <p style="font-size: 1.1em; margin-bottom: 20px;">
                Saldo em Reais: <strong>R$ <?= htmlspecialchars(number_format($current_real_balance, 2, ',', '.')) ?></strong> | 
                Saldo em Bitcoin: <strong><?= htmlspecialchars(number_format($current_bitcoin_balance, 8, ',', '.')) ?> BTC</strong>
            </p>

            <div class="tab-buttons">
                <button onclick="openTab('deposit', this)" id="deposit-tab" class="active">Depositar (Entrada)</button>
                <button onclick="openTab('withdraw', this)" id="withdraw-tab">Sacar (Retirada)</button>
            </div>

            <div id="deposit-form" class="form-section active">
                <h2>Qual tipo de depósito você deseja fazer?</h2>
                <form action="deposit_withdraw.php" method="POST">
                    <input type="hidden" name="action" value="deposit">
                    
                    <div class="method-selection">
                        <input type="radio" id="deposit_pix" name="method" value="pix" required onchange="updateMethodDetails('deposit', 'pix')" checked>
                        <label for="deposit_pix"><i class="fa-solid fa-qrcode"></i> PIX</label>

                        <input type="radio" id="deposit_ted" name="method" value="ted" required onchange="updateMethodDetails('deposit', 'ted')">
                        <label for="deposit_ted"><i class="fa-solid fa-building-columns"></i> TED</label>

                        <input type="radio" id="deposit_bitcoin" name="method" value="bitcoin" required onchange="updateMethodDetails('deposit', 'bitcoin')">
                        <label for="deposit_bitcoin"><i class="fa-brands fa-bitcoin"></i> Bitcoin</label>
                    </div>

                    <div id="deposit-method-details" class="method-details">
                        <script>
                            // Chama a função ao carregar para exibir o PIX por padrão
                            document.addEventListener('DOMContentLoaded', () => {
                                updateMethodDetails('deposit', 'pix');
                            });
                        </script>
                    </div>
                    
                    <button type="submit" class="button primary" style="margin-top: 20px;">Ver Instruções de Depósito</button>
                </form>
            </div>

            <div id="withdraw-form" class="form-section">
                <h2>Qual tipo de saque você deseja fazer?</h2>
                <form action="deposit_withdraw.php" method="POST">
                    <input type="hidden" name="action" value="withdraw">
                    
                    <div class="form-group">
                        <label for="withdraw_amount">Valor a Sacar (R$ / BTC):</label>
                        <input type="number" id="withdraw_amount" name="amount" step="0.01" min="0.01" placeholder="R$ 0,00" required>
                    </div>

                    <div class="method-selection">
                        <input type="radio" id="withdraw_pix" name="method" value="pix" required onchange="updateMethodDetails('withdraw', 'pix')" checked>
                        <label for="withdraw_pix"><i class="fa-solid fa-qrcode"></i> PIX</label>

                        <input type="radio" id="withdraw_ted" name="method" value="ted" required onchange="updateMethodDetails('withdraw', 'ted')">
                        <label for="withdraw_ted"><i class="fa-solid fa-building-columns"></i> TED</label>

                        <input type="radio" id="withdraw_bitcoin" name="method" value="bitcoin" required onchange="updateMethodDetails('withdraw', 'bitcoin')">
                        <label for="withdraw_bitcoin"><i class="fa-brands fa-bitcoin"></i> Bitcoin</label>
                    </div>

                    <div id="withdraw-method-details" class="method-details">
                        <script>
                            // Chama a função ao carregar para exibir o PIX por padrão no saque
                            document.addEventListener('DOMContentLoaded', () => {
                                updateMethodDetails('withdraw', 'pix');
                            });
                        </script>
                    </div>
                    
                    <button type="submit" class="button primary" style="margin-top: 20px;">Confirmar Saque</button>
                </form>
            </div>

        </div>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados.</p>
        </div>
    </footer>

    <script>
        const bankAccountInfo = <?= json_encode($bankAccountInfo) ?>;
        const bankBitcoinAddress = '<?= $bankBitcoinAddress ?>';
        const userPixKey = <?= json_encode($user_pix_keys) ?>; // Chave PIX do usuário (principal)
        
        // Elemento do valor de saque para ajuste de step/placeholder
        const withdrawAmountInput = document.getElementById('withdraw_amount');

        function openTab(tabName, element) {
            const forms = document.querySelectorAll('.form-section');
            forms.forEach(form => form.classList.remove('active'));
            
            document.getElementById(tabName + '-form').classList.add('active');

            const buttons = document.querySelectorAll('.tab-buttons button');
            buttons.forEach(btn => btn.classList.remove('active'));
            element.classList.add('active');

            // Atualiza os detalhes do método para o padrão da aba (ex: PIX)
            const defaultMethod = 'pix';
            const radio = document.getElementById(tabName + '_' + defaultMethod);
            if (radio) {
                radio.checked = true;
                updateMethodDetails(tabName, defaultMethod);
            }
        }

        function updateMethodDetails(formType, method) {
            const methodDetailsDiv = document.getElementById(formType + '-method-details');
            methodDetailsDiv.innerHTML = '';
            
            // --- DEPÓSITO (Entrada) ---
            if (formType === 'deposit') {
                // Reseta o campo de valor do saque, caso o usuário tenha clicado na aba de saque antes
                withdrawAmountInput.step = '0.01';
                withdrawAmountInput.placeholder = 'R$ 0,00';
                
                if (method === 'pix') {
                    if (userPixKey && userPixKey.ch_chave_pix) {
                        methodDetailsDiv.innerHTML = `
                            <h3>Instruções de Depósito PIX</h3>
                            <p>Envie o valor desejado do seu banco para a chave PIX do Bank Lopes abaixo:</p>
                            <div class="bank-details">
                                <p><strong>Chave PIX (<?= htmlspecialchars(isset($userPixKey['tp_tipo_chave']) ? $userPixKey['tp_tipo_chave'] : 'N/A') ?>):</strong> 
                                    <span id="pix-key-value">${userPixKey.ch_chave_pix}</span>
                                    <button class="copy-button" type="button" onclick="copyToClipboard(document.getElementById('pix-key-value').textContent)"><i class="fa-solid fa-copy"></i></button>
                                </p>
                                <p><strong>Titular:</strong> <?= $userName ?></p>
                                <small class="text-gray-500 block">(A chave PIX principal do seu cadastro será usada para receber o depósito.)</small>
                            </div>
                        `;
                    } else {
                        methodDetailsDiv.innerHTML = `
                            <div class="alert error">
                                Você precisa cadastrar uma chave PIX principal no seu <a href="dashboard.php" style="color:var(--highlight-color);">Dashboard</a> para receber depósitos PIX.
                            </div>
                        `;
                    }
                } else if (method === 'ted') {
                    methodDetailsDiv.innerHTML = `
                        <h3>Instruções de Depósito TED</h3>
                        <p>Realize um TED da sua conta bancária externa para os dados do Bank Lopes:</p>
                        <div class="bank-details">
                            <p><strong>Banco:</strong> <span id="bank-name">${bankAccountInfo.nm_banco}</span> <button class="copy-button" type="button" onclick="copyToClipboard(document.getElementById('bank-name').textContent)"><i class="fa-solid fa-copy"></i></button></p>
                            <p><strong>Agência:</strong> <span id="bank-agency">${bankAccountInfo.nr_agencia}</span> <button class="copy-button" type="button" onclick="copyToClipboard(document.getElementById('bank-agency').textContent)"><i class="fa-solid fa-copy"></i></button></p>
                            <p><strong>Conta Corrente:</strong> <span id="bank-account">${bankAccountInfo.nr_conta}</span> <button class="copy-button" type="button" onclick="copyToClipboard(document.getElementById('bank-account').textContent)"><i class="fa-solid fa-copy"></i></button></p>
                            <p><strong>CNPJ:</strong> <span id="bank-cnpj">${bankAccountInfo.ds_cpf_cnpj}</span> <button class="copy-button" type="button" onclick="copyToClipboard(document.getElementById('bank-cnpj').textContent)"><i class="fa-solid fa-copy"></i></button></p>
                            <p><strong>Titular:</strong> ${bankAccountInfo.nm_titular}</p>
                        </div>
                    `;
                } else if (method === 'bitcoin') {
                    methodDetailsDiv.innerHTML = `
                        <h3>Instruções de Depósito Bitcoin</h3>
                        <p>Envie Bitcoin (BTC) para o endereço abaixo. O crédito será realizado após 3 confirmações na blockchain.</p>
                        <div class="bank-details">
                            <p><strong>Endereço Bitcoin:</strong> 
                                <span id="btc-address-value">${bankBitcoinAddress}</span>
                                <button class="copy-button" type="button" onclick="copyToClipboard(document.getElementById('btc-address-value').textContent)"><i class="fa-solid fa-copy"></i></button>
                            </p>
                            <small class="text-gray-500 block">(Este é um endereço simulado. Em um sistema real, seria um endereço único do banco para depósito.)</small>
                        </div>
                    `;
                }
            } 
            
            // --- SAQUE (Retirada) ---
            else if (formType === 'withdraw') {
                // Ajusta o campo de valor do saque
                if (method === 'bitcoin') {
                    withdrawAmountInput.step = '0.00000001';
                    withdrawAmountInput.placeholder = '0.00000000 BTC';
                } else {
                    withdrawAmountInput.step = '0.01';
                    withdrawAmountInput.placeholder = 'R$ 0,00';
                }

                if (method === 'pix') {
                    methodDetailsDiv.innerHTML = `
                        <h3>Dados PIX do Destinatário</h3>
                        <p>Informe a chave PIX e o valor que deseja sacar da sua conta do Bank Lopes.</p>
                        <div class="form-group">
                            <label for="pix_key" class="block text-sm font-medium text-gray-700 mb-1">Chave PIX de Destino:</label>
                            <input type="text" id="pix_key" name="pix_key" placeholder="CPF, E-mail, Telefone ou Chave Aleatória" required>
                        </div>
                        <div class="form-group">
                            <label for="key_type">Tipo de Chave:</label>
                            <select id="key_type" name="key_type" required>
                                <option value="CPF">CPF</option>
                                <option value="CNPJ">CNPJ</option>
                                <option value="E-mail">E-mail</option>
                                <option value="Telefone">Telefone</option>
                                <option value="Aleatória">Chave Aleatória</option>
                            </select>
                        </div>
                    `;
                } else if (method === 'ted') {
                    methodDetailsDiv.innerHTML = `
                        <h3>Dados Bancários para TED do Destinatário</h3>
                        <p>Informe os dados bancários para onde deseja enviar o TED (transferência para outro banco).</p>
                        <div class="form-group">
                            <label for="recipient_bank">Banco Destino:</label>
                            <input type="text" id="recipient_bank" name="recipient_bank" placeholder="Nome do Banco" required>
                        </div>
                        <div class="form-group">
                            <label for="recipient_agency">Agência Destino:</label>
                            <input type="text" id="recipient_agency" name="recipient_agency" placeholder="Agência" required>
                        </div>
                        <div class="form-group">
                            <label for="recipient_account">Conta Destino:</label>
                            <input type="text" id="recipient_account" name="recipient_account" placeholder="Número da Conta" required>
                        </div>
                        <div class="form-group">
                            <label for="recipient_cpf_cnpj">CPF/CNPJ Destino:</label>
                            <input type="text" id="recipient_cpf_cnpj" name="recipient_cpf_cnpj" placeholder="CPF ou CNPJ do Titular" required>
                        </div>
                    `;
                } else if (method === 'bitcoin') { // Corrigido e adicionado
                    methodDetailsDiv.innerHTML = `
                        <h3>Endereço Bitcoin de Destino</h3>
                        <p>Informe o endereço da carteira para onde deseja sacar seus Bitcoins.</p>
                        <div class="form-group">
                            <label for="bitcoin_address" class="block text-sm font-medium text-gray-700 mb-1">Endereço Bitcoin de Destino:</label>
                            <input type="text" id="bitcoin_address" name="bitcoin_address" placeholder="Informe o endereço Bitcoin para onde sacar" required>
                        </div>
                    `;
                }
            }
        }

        // Função para copiar texto para a área de transferência
        function copyToClipboard(text) {
            const tempInput = document.createElement('input');
            tempInput.value = text;
            document.body.appendChild(tempInput);
            tempInput.select();
            tempInput.setSelectionRange(0, 99999);
            // Usando alert() em vez de showNotification() para evitar erro de JS
            try {
                document.execCommand('copy');
                alert('Copiado para a área de transferência: ' + text);
            } catch (err) {
                console.error('Erro ao copiar: ', err);
                alert('Erro ao copiar. Tente manualmente: ' + text);
            }
            document.body.removeChild(tempInput);
        }
    </script>
</body>
</html>
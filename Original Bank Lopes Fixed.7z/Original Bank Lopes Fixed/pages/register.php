<?php
// www/pages/register.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

if (isset($_SESSION['user_id'])) {
    redirect('../pages/dashboard.php'); // Já logado, redireciona para o dashboard
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Correção: Usar isset() com operador ternário para compatibilidade com PHP < 7.0
    $nm_usuario = trim(isset($_POST['nm_usuario']) ? $_POST['nm_usuario'] : '');
    $ds_email = trim(isset($_POST['ds_email']) ? $_POST['ds_email'] : '');
    $ds_cpf = trim(isset($_POST['ds_cpf']) ? $_POST['ds_cpf'] : ''); // CPF deve ser preenchido
    $ds_senha = trim(isset($_POST['ds_senha']) ? $_POST['ds_senha'] : '');
    $confirm_senha = trim(isset($_POST['confirm_senha']) ? $_POST['confirm_senha'] : '');
    $dt_nascimento = trim(isset($_POST['dt_nascimento']) ? $_POST['dt_nascimento'] : '');
    $ds_telefone = trim(isset($_POST['ds_telefone']) ? $_POST['ds_telefone'] : '');
    $ds_endereco = trim(isset($_POST['ds_endereco']) ? $_POST['ds_endereco'] : '');
    $ds_cidade = trim(isset($_POST['ds_cidade']) ? $_POST['ds_cidade'] : '');
    $ds_estado = trim(isset($_POST['ds_estado']) ? $_POST['ds_estado'] : '');
    $ds_pais_origem = trim(isset($_POST['ds_pais_origem']) ? $_POST['ds_pais_origem'] : 'Brasil');


    // Validação básica
    if (empty($nm_usuario) || empty($ds_email) || empty($ds_cpf) || empty($ds_senha) || empty($confirm_senha) || empty($dt_nascimento) || empty($ds_cidade) || empty($ds_estado)) {
        set_message("Por favor, preencha todos os campos obrigatórios.", "error");
    } elseif (!filter_var($ds_email, FILTER_VALIDATE_EMAIL)) {
        set_message("Formato de e-mail inválido.", "error");
    } elseif ($ds_senha !== $confirm_senha) {
        set_message("As senhas não coincidem.", "error");
    } elseif (strlen($ds_senha) < 6) {
        set_message("A senha deve ter pelo menos 6 caracteres.", "error");
    } else {
        // Hash da senha
        $ds_senha_hash = password_hash($ds_senha, PASSWORD_DEFAULT);

        try {
            $pdo->beginTransaction();

            // 1. Verificar se o e-mail ou CPF já existem
            $stmt_check = $pdo->prepare("SELECT COUNT(*) FROM tb_usuario WHERE ds_email = ? OR ds_cpf = ?");
            $stmt_check->execute([$ds_email, $ds_cpf]);
            if ($stmt_check->fetchColumn() > 0) {
                set_message("E-mail ou CPF já cadastrados.", "error");
                $pdo->rollBack();
            } else {
                // 2. Inserir novo usuário
                $stmt_user = $pdo->prepare("INSERT INTO tb_usuario (nm_usuario, ds_email, ds_cpf, ds_senha_hash, dt_nascimento, ds_telefone, ds_endereco, ds_cidade, ds_estado, ds_pais_origem) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt_user->execute([$nm_usuario, $ds_email, $ds_cpf, $ds_senha_hash, $dt_nascimento, $ds_telefone, $ds_endereco, $ds_cidade, $ds_estado, $ds_pais_origem]);
                $user_id = $pdo->lastInsertId();

                // 3. Criar conta para o novo usuário com saldos iniciais zerados
                $nr_conta = 'ACC' . str_pad($user_id, 7, '0', STR_PAD_LEFT); // Exemplo de número de conta
                $stmt_account = $pdo->prepare("INSERT INTO tb_conta (id_usuario, nr_conta, vl_saldo_bitcoin, vl_saldo_real) VALUES (?, ?, 0, 0)");
                $stmt_account->execute([$user_id, $nr_conta]);

                // 4. Criar informações bancárias padrão para o novo usuário
                $simulated_bank_account_number = generate_uuid_v4(); // Gerar um número de conta único simulado
                $stmt_bank_info = $pdo->prepare("INSERT INTO tb_informacao_bancaria (id_usuario, tp_tipo_conta, nm_banco, nr_agencia, nr_conta, nm_titular, ds_cpf_cnpj) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt_bank_info->execute([$user_id, 'Corrente', 'Banco Lopes', '0001', $simulated_bank_account_number, $nm_usuario, $ds_cpf]);

                // 5. Criar um endereço Bitcoin padrão para o novo usuário
                $simulated_bitcoin_address = generate_uuid_v4(); // Gerar um endereço Bitcoin único simulado
                $qr_code_data = "https://placehold.co/150x150/000000/FFFFFF?text=BTC+Address+QR"; // QR Code simulado
                $stmt_btc_address = $pdo->prepare("INSERT INTO tb_endereco_bitcoin (id_usuario, ds_endereco, ds_qr_code, ds_rotulo, tp_tipo, dt_criacao) VALUES (?, ?, ?, ?, ?, NOW())");
                $stmt_btc_address->execute([$user_id, $simulated_bitcoin_address, $qr_code_data, 'Meu Endereço Principal', 'Recebimento']);


                $pdo->commit(); // Confirma todas as operações
                set_message("Conta criada com sucesso! Faça login para continuar.", "success");
                redirect('login.php');
            }
        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log("Erro no registro: " . $e->getMessage());
            set_message("Ocorreu um erro ao criar sua conta. Por favor, tente novamente. Detalhes: " . $e->getMessage(), "error");
        }
    }
    redirect('register.php'); // Redireciona de volta ao formulário de registro em caso de erro
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body {
            display: flex;
            flex-direction: column;
            min-height: 100vh;
            background-color: var(--background-color);
            color: var(--text-color);
            font-family: 'Inter', sans-serif;
        }
        main {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
        }
        .register-container {
            background-color: var(--secondary-color);
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
            text-align: center;
        }
        .register-container h2 {
            color: var(--primary-color);
            margin-bottom: 25px;
            font-size: 2em;
        }
        .register-container form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        .register-container input[type="text"],
        .register-container input[type="email"],
        .register-container input[type="password"],
        .register-container input[type="date"],
        .register-container input[type="tel"] {
            padding: 12px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 1em;
            background-color: var(--input-bg-color);
            color: var(--input-text-color);
        }
        .register-container input::placeholder {
            color: var(--placeholder-color);
        }
        .register-container .button.primary {
            background-color: var(--primary-color);
            color: white;
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            font-size: 1.1em;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .register-container .button.primary:hover {
            background-color: var(--primary-dark-color);
        }
        .register-container p {
            margin-top: 20px;
            color: var(--text-color);
        }
        .register-container p a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: bold;
        }
        .register-container p a:hover {
            text-decoration: underline;
        }
        .notification.error {
            background-color: #f44336;
            color: white;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            text-align: left;
        }
        .notification.success {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 15px;
            text-align: left;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>Bank Lopes</h1>
            <nav>
                <ul>
                    <li><a href="login.php">Login</a></li>
                    <li><a href="register.php" class="active">Registrar</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="register-container">
            <h2>Criar Nova Conta</h2>
            <?php display_messages(); // Exibe mensagens de erro/sucesso ?>
            <form action="register.php" method="POST">
                <input type="text" name="nm_usuario" placeholder="Nome Completo" autocomplete="name" value="<?= htmlspecialchars(isset($_POST['nm_usuario']) ? $_POST['nm_usuario'] : '') ?>" required>
                <input type="email" name="ds_email" placeholder="E-mail" autocomplete="email" value="<?= htmlspecialchars(isset($_POST['ds_email']) ? $_POST['ds_email'] : '') ?>" required>
                <input type="text" name="ds_cpf" placeholder="CPF (somente números)" autocomplete="off" value="<?= htmlspecialchars(isset($_POST['ds_cpf']) ? $_POST['ds_cpf'] : '') ?>" required maxlength="11" pattern="[0-9]{11}" title="Digite seu CPF com 11 dígitos, somente números.">
                <input type="password" name="ds_senha" placeholder="Senha" autocomplete="new-password" required>
                <input type="password" name="confirm_senha" placeholder="Confirmar Senha" autocomplete="new-password" required>
                <input type="date" name="dt_nascimento" placeholder="Data de Nascimento" autocomplete="bday" value="<?= htmlspecialchars(isset($_POST['dt_nascimento']) ? $_POST['dt_nascimento'] : '') ?>" required>
                <!-- Campos Opcionais -->
                <input type="tel" name="ds_telefone" placeholder="Telefone (Opcional)" autocomplete="tel" value="<?= htmlspecialchars(isset($_POST['ds_telefone']) ? $_POST['ds_telefone'] : '') ?>">
                <input type="text" name="ds_endereco" placeholder="Endereço Completo (Opcional)" autocomplete="street-address" value="<?= htmlspecialchars(isset($_POST['ds_endereco']) ? $_POST['ds_endereco'] : '') ?>">
                <input type="text" name="ds_cidade" placeholder="Cidade (Opcional)" autocomplete="address-level2" value="<?= htmlspecialchars(isset($_POST['ds_cidade']) ? $_POST['ds_cidade'] : '') ?>">
                <input type="text" name="ds_estado" placeholder="Estado (Opcional - Ex: SP)" autocomplete="address-level1" value="<?= htmlspecialchars(isset($_POST['ds_estado']) ? $_POST['ds_estado'] : '') ?>">
                <input type="text" name="ds_pais_origem" placeholder="País de Origem (Opcional - Ex: Brasil)" value="<?= htmlspecialchars(isset($_POST['ds_pais_origem']) ? $_POST['ds_pais_origem'] : 'Brasil') ?>">
                <button type="submit" class="button primary">Criar Conta</button>
                <p>Já tem uma conta? <a href="login.php">Faça Login</a></p>
            </form>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>

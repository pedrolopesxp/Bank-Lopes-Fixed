<?php
// www/pages/admin_manage_fees.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Verifica se o administrador está logado. Se não, redireciona para a página de login do admin.
if (!isset($_SESSION['admin_id'])) {
    set_message("Você precisa estar logado como administrador para acessar esta área.", "error");
    redirect('admin_login.php');
}

$admin_name = htmlspecialchars($_SESSION['admin_name'] ?? 'Administrador');
$admin_level = htmlspecialchars($_SESSION['admin_level'] ?? 'Nível Desconhecido');

$fees = [];
try {
    $stmt = $pdo->query("SELECT id_taxa, tp_tipo_operacao, vl_percentual, vl_valor_fixo, vl_valor_minimo, vl_valor_maximo, dt_inicio, dt_fim FROM tb_taxa ORDER BY tp_tipo_operacao ASC");
    $fees = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Erro ao buscar taxas para gerenciamento: " . $e->getMessage());
    set_message("Ocorreu um erro ao carregar a lista de taxas.", "error");
}

// Lógica para adicionar/editar taxas (um exemplo simplificado)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = $_POST['action'];

    if ($action === 'add_fee' || $action === 'edit_fee') {
        $id_taxa = isset($_POST['id_taxa']) ? (int)$_POST['id_taxa'] : 0;
        $tp_tipo_operacao = trim(isset($_POST['tp_tipo_operacao']) ? $_POST['tp_tipo_operacao'] : '');
        // Garante que valores numéricos sejam tratados corretamente para evitar erros de tipo
        $vl_percentual = floatval(str_replace(',', '.', trim(isset($_POST['vl_percentual']) ? $_POST['vl_percentual'] : '0')));
        $vl_valor_fixo = floatval(str_replace(',', '.', trim(isset($_POST['vl_valor_fixo']) ? $_POST['vl_valor_fixo'] : '0')));
        $vl_valor_minimo = floatval(str_replace(',', '.', trim(isset($_POST['vl_valor_minimo']) ? $_POST['vl_valor_minimo'] : '0')));
        $vl_valor_maximo = floatval(str_replace(',', '.', trim(isset($_POST['vl_valor_maximo']) ? $_POST['vl_valor_maximo'] : '0')));
        $dt_inicio = trim(isset($_POST['dt_inicio']) ? $_POST['dt_inicio'] : date('Y-m-d'));
        // Verifica se dt_fim é vazio para setar como NULL no BD
        $dt_fim = !empty(trim(isset($_POST['dt_fim']) ? $_POST['dt_fim'] : '')) ? trim(isset($_POST['dt_fim']) ? $_POST['dt_fim'] : '') : NULL;


        if (empty($tp_tipo_operacao) || !is_numeric($vl_percentual)) { // Adicionada verificação numérica
            set_message("Por favor, preencha o tipo de operação e o percentual da taxa (deve ser um número).", "error");
        } else {
            try {
                if ($action === 'add_fee') {
                    $stmt = $pdo->prepare("INSERT INTO tb_taxa (tp_tipo_operacao, vl_percentual, vl_valor_fixo, vl_valor_minimo, vl_valor_maximo, dt_inicio, dt_fim) VALUES (?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$tp_tipo_operacao, $vl_percentual, $vl_valor_fixo, $vl_valor_minimo, $vl_valor_maximo, $dt_inicio, $dt_fim]);
                    set_message("Taxa adicionada com sucesso!", "success");
                } elseif ($action === 'edit_fee' && $id_taxa > 0) {
                    $stmt = $pdo->prepare("UPDATE tb_taxa SET tp_tipo_operacao = ?, vl_percentual = ?, vl_valor_fixo = ?, vl_valor_minimo = ?, vl_valor_maximo = ?, dt_inicio = ?, dt_fim = ? WHERE id_taxa = ?");
                    $stmt->execute([$tp_tipo_operacao, $vl_percentual, $vl_valor_fixo, $vl_valor_minimo, $vl_valor_maximo, $dt_inicio, $dt_fim, $id_taxa]);
                    set_message("Taxa atualizada com sucesso!", "success");
                }
                redirect('admin_manage_fees.php');
            } catch (PDOException $e) {
                error_log("Erro ao salvar taxa: " . $e->getMessage());
                set_message("Ocorreu um erro ao salvar a taxa: " . $e->getMessage(), "error"); // Exibir mensagem de erro do BD para depuração
            }
        }
    } elseif ($action === 'delete_fee' && isset($_POST['id_taxa'])) {
        $id_taxa = (int)$_POST['id_taxa'];
        try {
            $stmt = $pdo->prepare("DELETE FROM tb_taxa WHERE id_taxa = ?");
            $stmt->execute([$id_taxa]);
            set_message("Taxa excluída com sucesso!", "success");
            redirect('admin_manage_fees.php');
        } catch (PDOException $e) {
            error_log("Erro ao excluir taxa: " . $e->getMessage());
            set_message("Ocorreu um erro ao excluir a taxa: " . $e->getMessage(), "error"); // Exibir mensagem de erro do BD para depuração
        }
    }
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Taxas - Admin - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        /* Estilos específicos para esta página */
        .admin-form-container, .admin-table-container {
            background-color: var(--secondary-color);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
            margin-top: 40px;
            max-width: 900px; /* Maior para formulário e tabela de taxas */
            margin-left: auto;
            margin-right: auto;
        }
        .admin-form-container h2, .admin-table-container h2 {
            text-align: left;
            margin-bottom: 30px;
            color: var(--primary-dark-color);
            font-size: 2em;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        .form-grid label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: var(--text-color);
        }
        .form-grid input[type="text"],
        .form-grid input[type="number"],
        .form-grid input[type="date"],
        .form-grid select {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 1em;
            box-sizing: border-box;
        }
        .form-actions {
            display: flex;
            justify-content: flex-start;
            gap: 15px;
            margin-top: 20px;
        }
        .form-actions .button {
            padding: 12px 20px;
            font-size: 1em;
            border-radius: 8px;
            text-decoration: none;
            font-weight: bold;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s ease;
        }
        .form-actions .button.primary {
            background-color: var(--primary-color);
            color: var(--secondary-color);
            box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
        }
        .form-actions .button.primary:hover {
            background-color: var(--primary-dark-color);
            transform: translateY(-2px);
        }
        .admin-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 30px;
        }
        .admin-table th, .admin-table td {
            border: 1px solid var(--border-color);
            padding: 12px;
            text-align: left;
            font-size: 0.9em;
        }
        .admin-table th {
            background-color: var(--light-gray);
            font-weight: bold;
            color: var(--text-color);
        }
        .admin-table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .admin-table tbody tr:hover {
            background-color: #eef;
        }
        .admin-table .action-buttons .button {
            padding: 6px 10px;
            font-size: 0.8em;
            margin-right: 5px;
        }
        .admin-table .action-buttons .button.edit {
            background-color: #ffc107;
            color: #333;
        }
        .admin-table .action-buttons .button.edit:hover {
            background-color: #e0a800;
        }
        .admin-table .action-buttons .button.delete {
            background-color: var(--danger-color);
            color: white;
        }
        .admin-table .action-buttons .button.delete:hover {
            background-color: #c82333;
        }
        @media (max-width: 768px) {
            .admin-form-container, .admin-table-container {
                padding: 15px;
            }
            .form-grid {
                grid-template-columns: 1fr;
            }
            .admin-table th, .admin-table td {
                padding: 8px;
                font-size: 0.75em;
            }
            .admin-table .action-buttons .button {
                padding: 4px 8px;
                font-size: 0.7em;
                margin-bottom: 5px;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="admin_dashboard.php">Dashboard Admin</a></li>
                    <li>Olá, Admin <?= $admin_name ?> (Nível: <?= $admin_level ?>)</li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container admin-form-container">
            <h2>Gerenciar Taxas</h2>
            <?php display_messages(); ?>

            <h3>Adicionar/Editar Taxa</h3>
            <form action="admin_manage_fees.php" method="POST">
                <input type="hidden" name="id_taxa" id="id_taxa" value="0">
                <div class="form-grid">
                    <div>
                        <label for="tp_tipo_operacao">Tipo de Operação:</label>
                        <input type="text" id="tp_tipo_operacao" name="tp_tipo_operacao" placeholder="Ex: PIX Entrada, Saque BRL" required>
                    </div>
                    <div>
                        <label for="vl_percentual">Percentual (%):</label>
                        <input type="number" step="0.01" id="vl_percentual" name="vl_percentual" placeholder="Ex: 0.50 (para 0.5%)" required>
                    </div>
                    <div>
                        <label for="vl_valor_fixo">Valor Fixo (R$):</label>
                        <input type="number" step="0.01" id="vl_valor_fixo" name="vl_valor_fixo" placeholder="Ex: 2.50">
                    </div>
                    <div>
                        <label for="vl_valor_minimo">Valor Mínimo (R$):</label>
                        <input type="number" step="0.01" id="vl_valor_minimo" name="vl_valor_minimo" placeholder="Ex: 0.01">
                    </div>
                    <div>
                        <label for="vl_valor_maximo">Valor Máximo (R$):</label>
                        <input type="number" step="0.01" id="vl_valor_maximo" name="vl_valor_maximo" placeholder="Ex: 100.00">
                    </div>
                    <div>
                        <label for="dt_inicio">Data Início:</label>
                        <input type="date" id="dt_inicio" name="dt_inicio" required value="<?= date('Y-m-d') ?>">
                    </div>
                    <div>
                        <label for="dt_fim">Data Fim (Opcional):</label>
                        <input type="date" id="dt_fim" name="dt_fim">
                    </div>
                </div>
                <div class="form-actions">
                    <button type="submit" name="action" value="add_fee" class="button primary">Adicionar Taxa</button>
                    <button type="submit" name="action" value="edit_fee" class="button primary" style="background-color: #007bff; display: none;" id="btn-edit-fee">Atualizar Taxa</button>
                    <button type="button" class="button secondary" style="color: var(--text-color); border: 1px solid var(--border-color); display: none;" id="btn-cancel-edit">Cancelar Edição</button>
                </div>
            </form>

            <h3 style="margin-top: 50px;">Taxas Atuais</h3>
            <?php if (!empty($fees)): ?>
                <table class="admin-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tipo de Operação</th>
                            <th>Percentual (%)</th>
                            <th>Fixo (R$)</th>
                            <th>Mínimo (R$)</th>
                            <th>Máximo (R$)</th>
                            <th>Data Início</th>
                            <th>Data Fim</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($fees as $fee): ?>
                            <tr>
                                <td><?= htmlspecialchars($fee['id_taxa']) ?></td>
                                <td><?= htmlspecialchars(number_format($fee['vl_percentual'], 2, ',', '.')) ?></td>
                                <td><?= htmlspecialchars(number_format($fee['vl_valor_fixo'], 2, ',', '.')) ?></td>
                                <td><?= htmlspecialchars(number_format($fee['vl_valor_minimo'], 2, ',', '.')) ?></td>
                                <td><?= htmlspecialchars(number_format($fee['vl_valor_maximo'], 2, ',', '.')) ?></td>
                                <td><?= htmlspecialchars($fee['dt_inicio']) ?></td>
                                <td><?= htmlspecialchars($fee['dt_fim'] ?? 'N/A') ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <button type="button" class="button edit" onclick="editFee(<?= htmlspecialchars(json_encode($fee)) ?>)">Editar</button>
                                        <form method="POST" style="display: inline;">
                                            <input type="hidden" name="action" value="delete_fee">
                                            <input type="hidden" name="id_taxa" value="<?= htmlspecialchars($fee['id_taxa']) ?>">
                                            <button type="submit" class="button delete" onclick="return confirm('Tem certeza que deseja excluir esta taxa?');">Excluir</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Nenhuma taxa configurada.</p>
            <?php endif; ?>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>

    <script>
        function editFee(fee) {
            document.getElementById('id_taxa').value = fee.id_taxa;
            document.getElementById('tp_tipo_operacao').value = fee.tp_tipo_operacao;
            document.getElementById('vl_percentual').value = fee.vl_percentual;
            document.getElementById('vl_valor_fixo').value = fee.vl_valor_fixo;
            document.getElementById('vl_valor_minimo').value = fee.vl_valor_minimo;
            document.getElementById('vl_valor_maximo').value = fee.vl_valor_maximo;
            document.getElementById('dt_inicio').value = fee.dt_inicio;
            document.getElementById('dt_fim').value = fee.dt_fim;

            document.querySelector('button[name="action"][value="add_fee"]').style.display = 'none';
            document.getElementById('btn-edit-fee').style.display = 'inline-block';
            document.getElementById('btn-cancel-edit').style.display = 'inline-block';
        }

        document.getElementById('btn-cancel-edit').addEventListener('click', function() {
            document.getElementById('id_taxa').value = '0';
            document.getElementById('tp_tipo_operacao').value = '';
            document.getElementById('vl_percentual').value = '';
            document.getElementById('vl_valor_fixo').value = '';
            document.getElementById('vl_valor_minimo').value = '';
            document.getElementById('vl_valor_maximo').value = '';
            document.getElementById('dt_inicio').value = '<?= date('Y-m-d') ?>';
            document.getElementById('dt_fim').value = '';

            document.querySelector('button[name="action"][value="add_fee"]').style.display = 'inline-block';
            document.getElementById('btn-edit-fee').style.display = 'none';
            document.getElementById('btn-cancel-edit').style.display = 'none';
        });
    </script>
</body>
</html>

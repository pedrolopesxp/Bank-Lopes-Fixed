<?php
// www/pages/admin_user_edit.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Verifica se o administrador está logado.
if (!isset($_SESSION['admin_id'])) {
    set_message("Você precisa estar logado como administrador para acessar esta área.", "error");
    redirect('admin_login.php');
}

$admin_name = htmlspecialchars($_SESSION['admin_name'] ?? 'Administrador');
$admin_level = htmlspecialchars($_SESSION['admin_level'] ?? 'Nível Desconhecido');

$user_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

// Verifica se um ID de usuário foi passado na URL
if (!$user_id) {
    set_message("ID de usuário inválido.", "error");
    redirect('admin_manage_users.php');
}

$user_data = null;
try {
    // Busca os dados atuais do usuário
    $stmt = $pdo->prepare("SELECT id_usuario, nm_usuario, ds_email, ds_cpf, dt_nascimento, ds_telefone, ds_endereco, ds_cidade, ds_estado, ds_pais_origem, ds_status FROM tb_usuario WHERE id_usuario = ?");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();

    if (!$user_data) {
        set_message("Usuário não encontrado.", "error");
        redirect('admin_manage_users.php');
    }
} catch (PDOException $e) {
    error_log("Erro ao buscar dados do usuário para edição: " . $e->getMessage());
    set_message("Ocorreu um erro ao carregar os dados do usuário.", "error");
    redirect('admin_manage_users.php');
}

// Lógica para processar o formulário de edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nm_usuario = trim(isset($_POST['nm_usuario']) ? $_POST['nm_usuario'] : '');
    $ds_email = trim(isset($_POST['ds_email']) ? $_POST['ds_email'] : '');
    $ds_cpf = trim(isset($_POST['ds_cpf']) ? $_POST['ds_cpf'] : ''); // CPF geralmente não é editável, mas vamos incluir se necessário
    $dt_nascimento = trim(isset($_POST['dt_nascimento']) ? $_POST['dt_nascimento'] : '');
    $ds_telefone = trim(isset($_POST['ds_telefone']) ? $_POST['ds_telefone'] : '');
    $ds_endereco = trim(isset($_POST['ds_endereco']) ? $_POST['ds_endereco'] : '');
    $ds_cidade = trim(isset($_POST['ds_cidade']) ? $_POST['ds_cidade'] : '');
    $ds_estado = trim(isset($_POST['ds_estado']) ? $_POST['ds_estado'] : '');
    $ds_pais_origem = trim(isset($_POST['ds_pais_origem']) ? $_POST['ds_pais_origem'] : '');
    $ds_status = trim(isset($_POST['ds_status']) ? $_POST['ds_status'] : 'Ativo'); // Estado padrão ou o selecionado

    // Validações básicas
    $errors = [];
    if (empty($nm_usuario)) $errors[] = "O nome do usuário é obrigatório.";
    if (empty($ds_email) || !is_valid_email($ds_email)) $errors[] = "O e-mail é inválido ou obrigatório.";
    // Se o CPF for editável, adicione a validação aqui. Geralmente não é.
    // if (empty($ds_cpf) || !is_valid_cpf($ds_cpf)) $errors[] = "O CPF é inválido ou obrigatório.";
    if (empty($dt_nascimento)) $errors[] = "A data de nascimento é obrigatória.";
    if (empty($ds_status)) $errors[] = "O status do usuário é obrigatório.";
    if (!in_array($ds_status, ['Ativo', 'Inativo', 'Bloqueado'])) $errors[] = "Status inválido.";

    // Verifica se o e-mail já está em uso por outro usuário (exceto o atual)
    if (empty($errors) && $ds_email !== $user_data['ds_email']) {
        $stmt_email_check = $pdo->prepare("SELECT COUNT(*) FROM tb_usuario WHERE ds_email = ? AND id_usuario != ?");
        $stmt_email_check->execute([$ds_email, $user_id]);
        if ($stmt_email_check->fetchColumn() > 0) {
            $errors[] = "Este e-mail já está em uso por outro usuário.";
        }
    }
    
    // Verifica se o CPF já está em uso por outro usuário (se for editável e obrigatório)
    // if (empty($errors) && $ds_cpf !== $user_data['ds_cpf']) {
    //     $stmt_cpf_check = $pdo->prepare("SELECT COUNT(*) FROM tb_usuario WHERE ds_cpf = ? AND id_usuario != ?");
    //     $stmt_cpf_check->execute([$ds_cpf, $user_id]);
    //     if ($stmt_cpf_check->fetchColumn() > 0) {
    //         $errors[] = "Este CPF já está em uso por outro usuário.";
    //     }
    // }

    if (!empty($errors)) {
        foreach ($errors as $error) {
            set_message($error, "error");
        }
    } else {
        try {
            $update_stmt = $pdo->prepare("UPDATE tb_usuario SET nm_usuario = ?, ds_email = ?, dt_nascimento = ?, ds_telefone = ?, ds_endereco = ?, ds_cidade = ?, ds_estado = ?, ds_pais_origem = ?, ds_status = ? WHERE id_usuario = ?");
            
            if ($update_stmt->execute([
                $nm_usuario,
                $ds_email,
                $dt_nascimento,
                $ds_telefone,
                $ds_endereco,
                $ds_cidade,
                $ds_estado,
                $ds_pais_origem,
                $ds_status,
                $user_id
            ])) {
                set_message("Dados do usuário atualizados com sucesso!", "success");
                // Atualiza a sessão se o nome do admin mudou (improvável, mas possível)
                if ($ds_email === $_SESSION['admin_email']) {
                    $_SESSION['admin_name'] = $nm_usuario;
                }
                redirect('admin_manage_users.php');
            } else {
                set_message("Não foi possível atualizar os dados do usuário.", "error");
            }
        } catch (PDOException $e) {
            error_log("Erro ao atualizar usuário: " . $e->getMessage());
            set_message("Ocorreu um erro ao salvar as alterações. Por favor, verifique os logs.", "error");
        }
    }
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuário - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .form-container form {
            max-width: 600px;
            margin: 20px auto;
            padding: 30px;
            background-color: var(--secondary-color);
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .form-container form .form-group {
            margin-bottom: 15px;
        }

        .form-container form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: var(--primary-dark-color);
        }

        .form-container form input[type="text"],
        .form-container form input[type="email"],
        .form-container form input[type="date"],
        .form-container form input[type="tel"],
        .form-container form select {
            width: calc(100% - 20px); /* Ajusta para padding */
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 5px;
            font-size: 1em;
        }
        
        .form-container form input[type="password"] { /* Se precisar de senha, mas não é o caso aqui */
            width: calc(100% - 20px);
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 5px;
            font-size: 1em;
        }

        .form-container form .form-row {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
        }
        .form-container form .form-row > div {
            flex: 1;
        }

        .form-container form .button-group {
            margin-top: 25px;
            text-align: center;
        }

        .form-container form .button-group .button {
            margin: 0 10px;
        }
        
        .form-container form .description {
            font-size: 0.85em;
            color: #666;
            margin-top: 5px;
        }
        
        /* Estilos para o status do usuário no formulário */
        .status-ativo-form { color: var(--primary-color); font-weight: bold; }
        .status-inativo-form { color: #6c757d; }
        .status-bloqueado-form { color: var(--danger-color); font-weight: bold; }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Admin Bank Lopes</div>
            <nav>
                <ul>
                    <li>Olá, <?= $admin_name ?>! (<?= $admin_level ?>)</li>
                    <li><a href="admin_dashboard.php">Dashboard</a></li>
                    <li><a href="admin_manage_users.php" class="active">Gerenciar Usuários</a></li>
                    <li><a href="admin_manage_fees.php">Gerenciar Taxas</a></li>
                    <li><a href="admin_view_transactions.php">Transações</a></li>
                    <li><a href="admin_logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="container">
            <h2>Editar Usuário</h2>
            <?php display_messages(); ?>

            <div class="form-container">
                <form action="admin_user_edit.php?id=<?= $user_id ?>" method="POST">
                    <div class="form-group">
                        <label for="nm_usuario">Nome Completo:</label>
                        <input type="text" id="nm_usuario" name="nm_usuario" value="<?= htmlspecialchars($user_data['nm_usuario']) ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="ds_email">E-mail:</label>
                        <input type="email" id="ds_email" name="ds_email" value="<?= htmlspecialchars($user_data['ds_email']) ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="ds_cpf">CPF:</label>
                        <input type="text" id="ds_cpf" name="ds_cpf" value="<?= htmlspecialchars($user_data['ds_cpf']) ?>" readonly disabled>
                        <p class="description">O CPF não pode ser alterado por motivos de segurança e registro.</p>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="dt_nascimento">Data de Nascimento:</label>
                            <input type="date" id="dt_nascimento" name="dt_nascimento" value="<?= htmlspecialchars($user_data['dt_nascimento']) ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="ds_telefone">Telefone:</label>
                            <input type="tel" id="ds_telefone" name="ds_telefone" value="<?= htmlspecialchars($user_data['ds_telefone']) ?>">
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="ds_endereco">Endereço:</label>
                        <input type="text" id="ds_endereco" name="ds_endereco" value="<?= htmlspecialchars($user_data['ds_endereco']) ?>">
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label for="ds_cidade">Cidade:</label>
                            <input type="text" id="ds_cidade" name="ds_cidade" value="<?= htmlspecialchars($user_data['ds_cidade']) ?>">
                        </div>
                        <div class="form-group">
                            <label for="ds_estado">Estado:</label>
                            <input type="text" id="ds_estado" name="ds_estado" value="<?= htmlspecialchars($user_data['ds_estado']) ?>" maxlength="2">
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="ds_pais_origem">País de Origem:</label>
                        <input type="text" id="ds_pais_origem" name="ds_pais_origem" value="<?= htmlspecialchars($user_data['ds_pais_origem']) ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="ds_status">Status do Usuário:</label>
                        <select id="ds_status" name="ds_status" required>
                            <option value="Ativo" class="status-ativo-form" <?= $user_data['ds_status'] === 'Ativo' ? 'selected' : '' ?>>Ativo</option>
                            <option value="Inativo" class="status-inativo-form" <?= $user_data['ds_status'] === 'Inativo' ? 'selected' : '' ?>>Inativo</option>
                            <option value="Bloqueado" class="status-bloqueado-form" <?= $user_data['ds_status'] === 'Bloqueado' ? 'selected' : '' ?>>Bloqueado</option>
                        </select>
                    </div>

                    <div class="button-group">
                        <button type="submit" class="button primary">Salvar Alterações</button>
                        <a href="admin_manage_users.php" class="button secondary">Cancelar</a>
                    </div>
                </form>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>
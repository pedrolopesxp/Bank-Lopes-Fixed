<?php
// www/pages/admin_logout.php

session_start();
require_once __DIR__ . '/../inc/functions.php'; // Garante que as funções estejam disponíveis

// Destrói todas as variáveis de sessão
$_SESSION = array();

// Se a sessão for baseada em cookies, destrói o cookie de sessão também
// Isso garante que a sessão seja completamente encerrada no navegador.
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Finalmente, destrói a sessão
session_destroy();

// Define uma mensagem de sucesso e redireciona para a página de login do admin
set_message("Você foi desconectado com sucesso como administrador.", "info");
redirect('admin_login.php');
?>
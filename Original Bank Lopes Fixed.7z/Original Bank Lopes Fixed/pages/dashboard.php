<?php
// www/pages/dashboard.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php'; // Inclui functions.php onde generate_uuid_v4() está

// Verifica se o usuário está logado. Se não, redireciona para a página de login.
if (!isset($_SESSION['user_id'])) {
    set_message("Você precisa estar logado para acessar o dashboard.", "error");
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$userName = htmlspecialchars($_SESSION['user_name'] ?? 'Usuário');

// --- Variáveis de dados iniciais ---
$user_info = [];
$current_real_balance = 0;
$current_bitcoin_balance = 0;
$user_pix_keys = [];
$user_bitcoin_addresses = []; // Nova variável para armazenar endereços Bitcoin
$can_generate_random_pix_key = true;
$max_random_pix_keys = 5; // Limite de chaves PIX aleatórias por usuário
$user_bank_info = []; // Nova variável para armazenar informações bancárias

// --- Lógica para processar ações POST ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'create_pix_key') { // Alterado para 'create_pix_key'
        $pix_key_type = filter_input(INPUT_POST, 'pix_key_type', FILTER_SANITIZE_STRING);
        $pix_key_value = trim(filter_input(INPUT_POST, 'pix_key_value', FILTER_SANITIZE_STRING)); // Trim whitespace
        $is_principal = isset($_POST['is_principal']) ? 1 : 0; // Nova linha: captura se a chave é principal

        $generated_key = '';
        $rotulo = '';
        $validation_error = false;
        $message = '';

        // Obter a contagem atual de chaves aleatórias ANTES de tentar gerar/inserir
        $stmt_random_key_count = $pdo->prepare("SELECT COUNT(*) FROM tb_informacao_pix WHERE id_usuario = ? AND tp_tipo_chave = 'Aleatória'");
        $stmt_random_key_count->execute([$user_id]);
        $random_pix_key_count_for_check = $stmt_random_key_count->fetchColumn();


        if (empty($pix_key_type)) {
            $validation_error = true;
            $message = "Por favor, selecione um tipo de chave PIX.";
        } else {
            switch ($pix_key_type) {
                case 'Aleatória':
                    if ($random_pix_key_count_for_check >= $max_random_pix_keys) {
                        $validation_error = true;
                        $message = "Você atingiu o limite de " . $max_random_pix_keys . " chaves PIX aleatórias.";
                    } else {
                        $generated_key = generate_uuid_v4();
                        $rotulo = "Chave Aleatória " . date('Y-m-d H:i:s');
                    }
                    break;
                case 'CPF':
                    $pix_key_value = preg_replace('/[^0-9]/', '', $pix_key_value); // Remove non-numeric
                    if (!preg_match('/^\d{11}$/', $pix_key_value)) { // Basic CPF format check (11 digits)
                        $validation_error = true;
                        $message = "CPF inválido. Deve conter 11 dígitos numéricos.";
                    } else {
                        $generated_key = $pix_key_value;
                        $rotulo = "CPF";
                    }
                    break;
                case 'CNPJ':
                    $pix_key_value = preg_replace('/[^0-9]/', '', $pix_key_value); // Remove non-numeric
                    if (!preg_match('/^\d{14}$/', $pix_key_value)) { // Basic CNPJ format check (14 digits)
                        $validation_error = true;
                        $message = "CNPJ inválido. Deve conter 14 dígitos numéricos.";
                    } else {
                        $generated_key = $pix_key_value;
                        $rotulo = "CNPJ";
                    }
                    break;
                case 'E-mail': // Corrigido de 'Email' para 'E-mail' conforme o ENUM do DB
                    if (!filter_var($pix_key_value, FILTER_VALIDATE_EMAIL)) {
                        $validation_error = true;
                        $message = "Formato de e-mail inválido.";
                    } else {
                        $generated_key = $pix_key_value;
                        $rotulo = "E-mail";
                    }
                    break;
                case 'Telefone':
                    $pix_key_value = preg_replace('/[^0-9]/', '', $pix_key_value); // Remove non-numeric
                    if (!preg_match('/^\d{10,11}$/', $pix_key_value)) { // 10 or 11 digits (with DDD)
                        $validation_error = true;
                        $message = "Telefone inválido. Deve conter DDD + número (10 ou 11 dígitos numéricos).";
                    } else {
                        $generated_key = $pix_key_value;
                        $rotulo = "Telefone";
                    }
                    break;
                default:
                    $validation_error = true;
                    $message = "Tipo de chave PIX desconhecido.";
            }
        }

        // Antes de inserir, verificar se a chave já existe para este usuário (exceto para aleatórias)
        if (!$validation_error && $pix_key_type !== 'Aleatória') {
            $stmt_check_key_exists = $pdo->prepare("SELECT COUNT(*) FROM tb_informacao_pix WHERE id_usuario = ? AND ch_chave_pix = ?");
            $stmt_check_key_exists->execute([$user_id, $generated_key]);
            if ($stmt_check_key_exists->fetchColumn() > 0) {
                $validation_error = true;
                $message = "Esta chave PIX já está cadastrada para você.";
            }
        }

        if (!$validation_error) {
            try {
                $pdo->beginTransaction();

                // Se esta chave for definida como principal, todas as outras do usuário devem ser desmarcadas
                if ($is_principal) {
                    // CORREÇÃO: Usar 'bo_principal' conforme o esquema do banco de dados
                    $stmt_reset_principal = $pdo->prepare("UPDATE tb_informacao_pix SET bo_principal = 0 WHERE id_usuario = ?");
                    $stmt_reset_principal->execute([$user_id]);
                }

                // CORREÇÃO: Usar 'bo_principal' conforme o esquema do banco de dados
                $stmt_insert_pix = $pdo->prepare("INSERT INTO tb_informacao_pix (id_usuario, tp_tipo_chave, ch_chave_pix, bo_principal, ds_rotulo, dt_criacao) VALUES (?, ?, ?, ?, ?, NOW())");
                $stmt_insert_pix->execute([$user_id, $pix_key_type, $generated_key, $is_principal, $rotulo]); // Adiciona ds_rotulo

                $pdo->commit();
                set_message("Chave PIX " . htmlspecialchars($pix_key_type) . " criada com sucesso!", "success");
            } catch (PDOException $e) {
                $pdo->rollBack();
                error_log("Erro ao criar chave PIX: " . $e->getMessage());
                set_message("Erro ao criar chave PIX. Tente novamente. Detalhes: " . $e->getMessage(), "error"); // Adicionado detalhes para depuração
            }
        } else {
            set_message($message, "error");
        }
        redirect('dashboard.php'); // Redireciona para evitar reenvio do formulário
    } elseif ($_POST['action'] === 'delete_pix_key') {
        $key_id = filter_input(INPUT_POST, 'key_id', FILTER_VALIDATE_INT);
        if ($key_id) {
            try {
                // CORREÇÃO: Usar 'id_informacao' conforme o esquema do banco de dados
                $stmt_delete_pix = $pdo->prepare("DELETE FROM tb_informacao_pix WHERE id_informacao = ? AND id_usuario = ?");
                $stmt_delete_pix->execute([$key_id, $user_id]);
                if ($stmt_delete_pix->rowCount() > 0) {
                    set_message("Chave PIX removida com sucesso.", "success");
                } else {
                    set_message("Não foi possível remover a chave PIX ou ela não pertence a você.", "error");
                }
            } catch (PDOException $e) {
                error_log("Erro ao remover chave PIX: " . $e->getMessage());
                set_message("Erro ao remover chave PIX. Tente novamente. Detalhes: " . $e->getMessage(), "error"); // Adicionado detalhes para depuração
            }
        } else {
            set_message("ID da chave PIX inválido.", "error");
        }
        redirect('dashboard.php');
    } elseif ($_POST['action'] === 'set_pix_key_as_principal') { // Nova ação para definir como principal
        $key_id_to_set_principal = filter_input(INPUT_POST, 'key_id', FILTER_VALIDATE_INT);

        if ($key_id_to_set_principal) {
            try {
                $pdo->beginTransaction(); // Inicia uma transação

                // 1. Verificar se a chave pertence ao usuário
                // CORREÇÃO: Usar 'id_informacao' conforme o esquema do banco de dados
                $stmt_check_owner = $pdo->prepare("SELECT id_informacao FROM tb_informacao_pix WHERE id_informacao = ? AND id_usuario = ?");
                $stmt_check_owner->execute([$key_id_to_set_principal, $user_id]);
                
                if ($stmt_check_owner->fetch(PDO::FETCH_ASSOC)) {
                    // 2. Desativar a chave principal atual do usuário (se houver)
                    // CORREÇÃO: Usar 'bo_principal' conforme o esquema do banco de dados
                    $stmt_unset_current_principal = $pdo->prepare("UPDATE tb_informacao_pix SET bo_principal = 0 WHERE id_usuario = ? AND bo_principal = 1");
                    $stmt_unset_current_principal->execute([$user_id]);

                    // 3. Definir a nova chave como principal
                    // CORREÇÃO: Usar 'bo_principal' conforme o esquema do banco de dados
                    $stmt_set_new_principal = $pdo->prepare("UPDATE tb_informacao_pix SET bo_principal = 1 WHERE id_informacao = ? AND id_usuario = ?");
                    $stmt_set_new_principal->execute([$key_id_to_set_principal, $user_id]);

                    $pdo->commit(); // Confirma a transação
                    set_message("Chave PIX definida como principal com sucesso!", "success");
                } else {
                    $pdo->rollBack(); // Reverte a transação
                    set_message("Erro: A chave PIX selecionada não foi encontrada ou não pertence a você.", "error");
                }
            } catch (PDOException $e) {
                $pdo->rollBack(); // Reverte a transação em caso de erro
                error_log("Erro ao definir chave PIX como principal: " . $e->getMessage());
                set_message("Ocorreu um erro ao definir a chave PIX como principal. Por favor, tente novamente. Detalhes: " . $e->getMessage(), "error");
            }
        } else {
            set_message("ID da chave PIX inválido para definir como principal.", "error");
        }
        redirect('dashboard.php');
    }
    // A ação 'generate_bitcoin_address' e seu processamento foram removidos daqui
}


// --- Lógica para buscar dados ---
try {
    // Buscar informações do usuário
    $stmt_user = $pdo->prepare("SELECT nm_usuario, ds_email, ds_cpf, dt_nascimento, ds_telefone, ds_endereco, ds_cidade, ds_estado, ds_pais_origem, dt_cadastro FROM tb_usuario WHERE id_usuario = ?");
    $stmt_user->execute([$user_id]);
    $user_info = $stmt_user->fetch(PDO::FETCH_ASSOC);
    if ($user_info) {
        $userName = htmlspecialchars($user_info['nm_usuario']);
    }

    // Buscar saldos da conta do usuário
    $stmt_balance = $pdo->prepare("SELECT vl_saldo_bitcoin, vl_saldo_real FROM tb_conta WHERE id_usuario = ?");
    $stmt_balance->execute([$user_id]);
    $account_data = $stmt_balance->fetch(PDO::FETCH_ASSOC);
    if ($account_data) {
        $current_bitcoin_balance = $account_data['vl_saldo_bitcoin'];
        $current_real_balance = $account_data['vl_saldo_real'];
    }

    // Buscar chaves PIX do usuário
    // CORREÇÃO: Usar 'id_informacao' e 'bo_principal' conforme o esquema do banco de dados
    $stmt_pix = $pdo->prepare("SELECT id_informacao, tp_tipo_chave, ch_chave_pix, bo_principal, ds_rotulo FROM tb_informacao_pix WHERE id_usuario = ? ORDER BY bo_principal DESC, dt_criacao DESC");
    $stmt_pix->execute([$user_id]);
    $user_pix_keys = $stmt_pix->fetchAll(PDO::FETCH_ASSOC);

    // Verificar se o usuário pode gerar chaves aleatórias
    $stmt_random_key_count = $pdo->prepare("SELECT COUNT(*) FROM tb_informacao_pix WHERE id_usuario = ? AND tp_tipo_chave = 'Aleatória'");
    $stmt_random_key_count->execute([$user_id]);
    $random_pix_key_count = $stmt_random_key_count->fetchColumn();
    $can_generate_random_pix_key = ($random_pix_key_count < $max_random_pix_keys);


    // Buscar endereços Bitcoin do usuário
    // CORREÇÃO: Usar 'ds_endereco' conforme o esquema do banco de dados
    $stmt_bitcoin_addresses = $pdo->prepare("SELECT id_endereco, ds_endereco, ds_qr_code, ds_rotulo FROM tb_endereco_bitcoin WHERE id_usuario = ? ORDER BY dt_criacao DESC");
    $stmt_bitcoin_addresses->execute([$user_id]);
    $user_bitcoin_addresses = $stmt_bitcoin_addresses->fetchAll(PDO::FETCH_ASSOC);

    // Buscar informações bancárias do usuário (apenas a primeira encontrada, se houver)
    // CORREÇÃO: Adicionando 'tp_tipo_conta' para corresponder ao esquema do banco de dados
    $stmt_bank_info = $pdo->prepare("SELECT nm_banco, nr_agencia, nr_conta, tp_tipo_conta FROM tb_informacao_bancaria WHERE id_usuario = ? LIMIT 1");
    $stmt_bank_info->execute([$user_id]);
    $user_bank_info = $stmt_bank_info->fetch(PDO::FETCH_ASSOC);


} catch (PDOException $e) {
    error_log("Erro ao buscar dados do dashboard: " . $e->getMessage());
    set_message("Erro ao carregar seus dados. Por favor, tente novamente. Detalhes: " . $e->getMessage(), "error"); // Adicionado detalhes para depuração
}

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" xintegrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        /* Estilos específicos para o Dashboard */
        .dashboard-container {
            display: flex;
            flex-direction: column;
            gap: 20px;
            padding: 20px;
        }

        .balance-summary, .section-card {
            background-color: var(--secondary-color);
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }

        .balance-summary h2, .section-card h2 {
            color: var(--primary-color);
            margin-bottom: 15px;
            font-size: 1.6em;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        .balance-summary p, .section-card p {
            font-size: 1.1em;
            color: var(--text-color);
            margin-bottom: 10px;
        }
        .balance-summary .amount, .section-card .amount {
            font-weight: bold;
            color: var(--highlight-color);
        }

        .pix-key-item, .bitcoin-address-item {
            background-color: var(--input-bg-color);
            border: 1px solid var(--border-color);
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 10px;
            display: flex;
            flex-wrap: wrap; /* Permite que os itens quebrem linha */
            align-items: center;
            gap: 10px; /* Espaço entre os itens */
        }
        .pix-key-item p, .bitcoin-address-item p {
            margin: 0;
            flex-grow: 1; /* Permite que o parágrafo ocupe o espaço disponível */
            color: var(--text-color);
        }
        .pix-key-item .key-value, .bitcoin-address-item .address-value {
            font-weight: bold;
            color: var(--highlight-color);
            word-break: break-all; /* Garante que chaves longas quebrem a linha */
        }
        .pix-key-actions, .bitcoin-address-actions {
            display: flex;
            gap: 8px;
            margin-left: auto; /* Empurra os botões para a direita */
        }
        .pix-key-actions button, .bitcoin-address-actions button {
            padding: 8px 12px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.9em;
            transition: background-color 0.3s ease;
        }
        .pix-key-actions .delete-button, .bitcoin-address-actions .delete-button {
            background-color: #dc3545;
            color: white;
        }
        .pix-key-actions .delete-button:hover, .bitcoin-address-actions .delete-button:hover {
            background-color: #c82333;
        }
        .pix-key-actions .copy-button, .bitcoin-address-actions .copy-button {
            background-color: var(--button-secondary-bg);
            color: var(--button-secondary-text);
        }
        .pix-key-actions .copy-button:hover, .bitcoin-address-actions .copy-button:hover {
            background-color: var(--button-secondary-hover-bg);
        }
        .pix-key-actions .qrcode-button {
            background-color: var(--button-tertiary-bg);
            color: var(--button-tertiary-text);
        }
        .pix-key-actions .qrcode-button:hover {
            background-color: var(--button-tertiary-hover-bg);
        }

        .qr-code-modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 10; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgba(0,0,0,0.6); /* Black w/ opacity */
            align-items: center;
            justify-content: center;
        }
        .qr-code-modal-content {
            background-color: var(--secondary-color);
            margin: auto;
            padding: 30px;
            border-radius: 15px;
            width: 90%;
            max-width: 400px;
            text-align: center;
            position: relative;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }
        .qr-code-modal-content img {
            width: 80%;
            height: auto;
            margin: 15px 0;
            border: 1px solid var(--border-color);
            border-radius: 8px;
        }
        .qr-code-modal-content .close-button {
            position: absolute;
            top: 15px;
            right: 20px;
            color: var(--text-color);
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.2s;
        }
        .qr-code-modal-content .close-button:hover,
        .qr-code-modal-content .close-button:focus {
            color: var(--primary-color);
            text-decoration: none;
            cursor: pointer;
        }
        .qr-code-modal-content p {
            font-size: 1em;
            color: var(--text-color);
            margin-bottom: 10px;
        }

        .form-group.radio-group {
            display: flex;
            flex-direction: column; /* Organiza os radios verticalmente */
            gap: 10px;
            margin-bottom: 15px;
        }

        .form-group.radio-group div {
            display: flex;
            align-items: center;
        }

        .form-group.radio-group input[type="radio"] {
            margin-right: 8px;
        }

        .form-group.checkbox-group {
            display: flex;
            align-items: center;
            margin-top: 10px;
        }
        .form-group.checkbox-group input[type="checkbox"] {
            margin-right: 8px;
        }

        /* Estilo para a nova seção de navegação */
        .navigation-links-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }

        .navigation-links-grid a {
            background-color: var(--input-bg-color);
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            color: var(--primary-color);
            text-decoration: none;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 10px;
            font-size: 1.1em;
        }

        .navigation-links-grid a:hover {
            background-color: var(--hover-color);
            transform: translateY(-3px);
        }

        .navigation-links-grid a i {
            font-size: 2em;
            color: var(--highlight-color);
        }

    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>Bank Lopes</h1>
            <nav>
                <ul>
                    <li><a href="dashboard.php" class="active">Dashboard</a></li>
                    <li><a href="deposit_withdraw.php">Depósito/Saque</a></li>
                    <li><a href="transfer.php">Transferir</a></li>
                    <li><a href="transaction_history.php">Histórico</a></li>
                    <li>Olá, <?= $userName ?>!</li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="dashboard-container">
            <?php display_messages(); // Exibe mensagens de sucesso/erro ?>

            <div class="balance-summary">
                <h2><i class="fa-solid fa-wallet"></i> Seu Saldo Atual</h2>
                <p>Saldo em Reais: <span class="amount real">R$ <?= htmlspecialchars(number_format($current_real_balance, 2, ',', '.')) ?></span></p>
                <p>Saldo em Bitcoin: <span class="amount bitcoin"><?= htmlspecialchars(number_format($current_bitcoin_balance, 8, ',', '.')) ?> BTC</span></p>
            </div>

            <section class="section-card">
                <h2><i class="fa-solid fa-link"></i> Navegação Rápida</h2>
                <div class="navigation-links-grid">
                    <a href="make_pix.php"><i class="fa-solid fa-qrcode"></i> Fazer PIX</a>
                    <a href="pix_scheduling.php"><i class="fa-solid fa-clock"></i> Agendamentos PIX</a>
                    <a href="pix_refund.php"><i class="fa-solid fa-rotate-left"></i> Solicitar Estorno PIX</a>
                    <a href="poupanca.php"><i class="fa-solid fa-piggy-bank"></i> Poupança</a> <a href="ted.php"><i class="fa-solid fa-building-columns"></i> Fazer TED</a> <a href="my_cards.php"><i class="fa-solid fa-credit-card"></i> Meus Cartões</a>
                    <a href="add_card.php"><i class="fa-solid fa-credit-card"></i> Adicionar Cartão Físico</a>
                    <a href="create_virtual_card.php"><i class="fa-solid fa-mobile-screen"></i> Criar Cartão Virtual</a>
                    <a href="send_bitcoin.php"><i class="fa-brands fa-bitcoin"></i> Enviar Bitcoin</a>
                    <a href="deposit_withdraw.php"><i class="fa-solid fa-money-bill-transfer"></i> Depósito e Saque</a>
                    <a href="transfer.php"><i class="fa-solid fa-exchange-alt"></i> Transferência</a>
                    <a href="transaction_history.php"><i class="fa-solid fa-receipt"></i> Histórico de Transações</a>
                </div>
            </section>

            <section class="section-card">
                <h2><i class="fa-solid fa-key"></i> Minhas Chaves PIX</h2>
                <?php if (!empty($user_pix_keys)): ?>
                    <ul>
                        <?php foreach ($user_pix_keys as $key): ?>
                            <li class="pix-key-item">
                                <p><strong><?= htmlspecialchars($key['ds_rotulo']) ?>:</strong> <span class="key-value"><?= htmlspecialchars($key['ch_chave_pix']) ?></span></p>
                                <?php if ($key['bo_principal']): ?>
                                    <span class="badge" style="background-color: var(--highlight-color); color: white; padding: 5px 10px; border-radius: 5px; font-size: 0.8em;">Principal</span>
                                <?php endif; ?>
                                <div class="pix-key-actions">
                                    <button class="copy-button" onclick="copyToClipboard('<?= htmlspecialchars($key['ch_chave_pix']) ?>')">Copiar</button>
                                    <button class="qrcode-button" onclick="showQrCode('PIX:<?= htmlspecialchars($key['ch_chave_pix']) ?>', 'Chave PIX: <?= htmlspecialchars($key['ds_rotulo']) ?>')">QR Code</button>
                                    <?php if (!$key['bo_principal']): ?>
                                        <form action="dashboard.php" method="POST" style="display:inline-block;">
                                            <input type="hidden" name="action" value="set_pix_key_as_principal">
                                            <input type="hidden" name="key_id" value="<?= htmlspecialchars($key['id_informacao']) ?>">
                                            <button type="submit" class="copy-button" title="Definir como Chave Principal">Tornar Principal</button>
                                        </form>
                                    <?php endif; ?>
                                    <form action="dashboard.php" method="POST" onsubmit="return confirm('Tem certeza que deseja remover esta chave PIX?');" style="display:inline-block;">
                                        <input type="hidden" name="action" value="delete_pix_key">
                                        <input type="hidden" name="key_id" value="<?= htmlspecialchars($key['id_informacao']) ?>">
                                        <button type="submit" class="delete-button">Remover</button>
                                    </form>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p>Nenhuma chave PIX cadastrada. Adicione uma para começar a usar!</p>
                <?php endif; ?>

                <h3>Cadastrar Nova Chave PIX</h3>
                <form action="dashboard.php" method="POST">
                    <input type="hidden" name="action" value="create_pix_key">
                    <div class="form-group">
                        <label for="pix_key_type">Tipo de Chave PIX:</label>
                        <select id="pix_key_type" name="pix_key_type" onchange="handlePixKeyTypeChange()" required>
                            <option value="">Selecione</option>
                            <option value="CPF">CPF</option>
                            <option value="CNPJ">CNPJ</option>
                            <option value="E-mail">E-mail</option>
                            <option value="Telefone">Telefone</option>
                            <?php if ($can_generate_random_pix_key): ?>
                                <option value="Aleatória">Chave Aleatória</option>
                            <?php endif; ?>
                        </select>
                    </div>

                    <div id="pixKeyValueGroup" class="form-group" style="display: none;">
                        <label for="pix_key_value">Valor da Chave:</label>
                        <input type="text" id="pix_key_value" name="pix_key_value" placeholder="Digite o valor da chave" >
                    </div>

                    <div class="form-group checkbox-group">
                        <input type="checkbox" id="is_principal" name="is_principal" value="1">
                        <label for="is_principal">Definir como chave principal</label>
                    </div>

                    <button type="submit" class="button primary">Cadastrar Chave PIX</button>
                </form>
            </section>

            <section class="section-card">
                <h2><i class="fa-brands fa-bitcoin"></i> Meus Endereços Bitcoin</h2>
                <?php if (!empty($user_bitcoin_addresses)): ?>
                    <ul>
                        <?php foreach ($user_bitcoin_addresses as $address): ?>
                            <li class="bitcoin-address-item">
                                <p><strong>Rótulo:</strong> <?= htmlspecialchars($address['ds_rotulo']) ?></p>
                                <p><strong>Endereço:</strong> <span class="address-value"><?= htmlspecialchars($address['ds_endereco']) ?></span></p>
                                <div class="bitcoin-address-actions">
                                    <button class="copy-button" onclick="copyToClipboard('<?= htmlspecialchars($address['ds_endereco']) ?>')">Copiar</button>
                                    <button class="qrcode-button" onclick="showQrCode('bitcoin:<?= htmlspecialchars($address['ds_endereco']) ?>', 'Endereço Bitcoin: <?= htmlspecialchars($address['ds_rotulo']) ?>')">QR Code</button>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p>Nenhum endereço Bitcoin cadastrado.</p>
                <?php endif; ?>
                </section>

            <div class="dashboard-section user-profile-section section-card">
                <h3>
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-user"><path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                    Meu Perfil
                </h3>
                <?php if (!empty($user_info)): ?>
                    <div class="user-profile-info">
                        <p><strong>Nome:</strong> <?= htmlspecialchars($user_info['nm_usuario'] ?? 'N/A') ?></p>
                        <p><strong>Email:</strong> <?= htmlspecialchars($user_info['ds_email'] ?? 'N/A') ?></p>
                        <p><strong>CPF:</strong> <?= htmlspecialchars($user_info['ds_cpf'] ?? 'N/A') ?></p>
                        <?php if (!empty($user_info['ds_telefone'])): ?>
                            <p><strong>Telefone:</strong> <?= htmlspecialchars($user_info['ds_telefone']) ?></p>
                        <?php endif; ?>
                        <?php if (!empty($user_info['ds_endereco'])): ?>
                            <p><strong>Endereço:</strong> <?= htmlspecialchars($user_info['ds_endereco']) ?></p>
                        <?php endif; ?>
                        <?php if (!empty($user_info['ds_cidade'])): ?>
                            <p><strong>Cidade:</strong> <?= htmlspecialchars($user_info['ds_cidade']) ?></p>
                        <?php endif; ?>
                        <?php if (!empty($user_info['ds_estado'])): ?>
                            <p><strong>Estado:</strong> <?= htmlspecialchars($user_info['ds_estado']) ?></p>
                        <?php endif; ?>
                        <?php if (!empty($user_info['ds_pais_origem'])): ?>
                            <p><strong>País de Origem:</strong> <?= htmlspecialchars($user_info['ds_pais_origem']) ?></p>
                        <?php endif; ?>
                        <p><strong>Membro desde:</strong> <?= htmlspecialchars((new DateTime($user_info['dt_cadastro']))->format('d/m/Y H:i:s')) ?></p>
                    </div>
                <?php else: ?>
                    <p>Não foi possível carregar as informações do seu perfil.</p>
                <?php endif; ?>

                <?php if (!empty($user_bank_info)): ?>
                    <h4 style="margin-top: 20px; color: var(--primary-color);">Informações Bancárias</h4>
                    <div class="user-bank-info">
                        <p><strong>Banco/Instituição:</strong> <?= htmlspecialchars($user_bank_info['nm_banco'] ?? 'N/A') ?></p>
                        <p><strong>Tipo de Conta:</strong> <?= htmlspecialchars($user_bank_info['tp_tipo_conta'] ?? 'N/A') ?></p>
                        <p><strong>Agência:</strong> <?= htmlspecialchars($user_bank_info['nr_agencia'] ?? 'N/A') ?></p>
                        <p><strong>Conta:</strong> <?= htmlspecialchars($user_bank_info['nr_conta'] ?? 'N/A') ?></p>
                    </div>
                <?php else: ?>
                    <p style="margin-top: 20px;">Nenhuma informação bancária cadastrada.</p>
                <?php endif; ?>
            </div>
        </section>
    </main>

    <div id="qrCodeModal" class="qr-code-modal">
        <div class="qr-code-modal-content">
            <span class="close-button" onclick="hideQrCode()">&times;</span>
            <h3 id="qrCodeTitle"></h3>
            <img id="qrCodeImage" src="" alt="QR Code">
            <p id="qrCodeValue"></p>
        </div>
    </div>


    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/qrious/4.0.2/qrious.min.js"></script>
    <script>
        // Função para exibir notificações (já deve existir em functions.php ou no seu script principal)
        function showNotification(message, type) {
            // Implementação simples de notificação no frontend
            const notificationContainer = document.querySelector('.notification-container'); // Adicione este container no seu HTML
            if (!notificationContainer) {
                console.warn('Notification container not found. Create a div with class "notification-container".');
                return;
            }

            const notification = document.createElement('div');
            notification.classList.add('notification', type); // Classes 'notification', 'success', 'error'
            notification.textContent = message;
            notificationContainer.appendChild(notification);

            setTimeout(() => {
                notification.remove();
            }, 5000); // Remove a notificação após 5 segundos
        }

        function copyToClipboard(text) {
            navigator.clipboard.writeText(text).then(() => {
                alert('Copiado para a área de transferência: ' + text);
            }).catch(err => {
                console.error('Erro ao copiar: ', err);
                alert('Erro ao copiar. Tente manualmente: ' + text);
            });
        }


        // Script para o modal de QR Code
        const qrCodeModal = document.getElementById('qrCodeModal');
        const qrCodeImage = document.getElementById('qrCodeImage');
        const qrCodeValue = document.getElementById('qrCodeValue');
        const qrCodeTitle = document.getElementById('qrCodeTitle');

        function showQrCode(value, title) {
            qrCodeTitle.textContent = title;
            qrCodeValue.textContent = value;
            new QRious({
                element: qrCodeImage,
                value: value,
                size: 250,
                padding: 20
            });
            qrCodeModal.style.display = 'flex';
        }

        function hideQrCode() {
            qrCodeModal.style.display = 'none';
            qrCodeImage.src = ''; // Limpa a imagem
        }

        // Fechar modal ao clicar fora
        window.onclick = function(event) {
            if (event.target === qrCodeModal) {
                hideQrCode();
            }
        };


        // Lógica para mostrar/esconder campo de valor da chave PIX
        function handlePixKeyTypeChange() {
            const selectedType = document.getElementById('pix_key_type').value;
            const pixKeyValueGroup = document.getElementById('pixKeyValueGroup');
            const pixKeyValueInput = document.getElementById('pix_key_value');

            // Reset input attributes
            pixKeyValueInput.removeAttribute('required');
            pixKeyValueInput.removeAttribute('maxlength');
            pixKeyValueInput.type = 'text'; // Reset type
            pixKeyValueInput.value = ''; // Limpa o valor

            if (selectedType === 'Aleatória' || selectedType === '') {
                pixKeyValueGroup.style.display = 'none';
            } else {
                pixKeyValueGroup.style.display = 'block';
                pixKeyValueInput.setAttribute('required', 'required');
                
                if (selectedType === 'CPF') {
                    pixKeyValueInput.placeholder = 'Digite o CPF (somente números)';
                    pixKeyValueInput.setAttribute('maxlength', '11');
                } else if (selectedType === 'CNPJ') {
                    pixKeyValueInput.placeholder = 'Digite o CNPJ (somente números)';
                    pixKeyValueInput.setAttribute('maxlength', '14');
                } else if (selectedType === 'E-mail') { // Corrigido para 'E-mail'
                    pixKeyValueInput.placeholder = 'Digite o e-mail';
                    pixKeyValueInput.type = 'email'; 
                } else if (selectedType === 'Telefone') {
                    pixKeyValueInput.placeholder = 'Digite o telefone (somente números com DDD)';
                    pixKeyValueInput.setAttribute('maxlength', '11'); // Assumindo DDD + 8 ou 9 dígitos
                    pixKeyValueInput.type = 'tel'; // Tipo 'tel' para teclados numéricos em mobile
                }
            }
        }

        // Chama a função ao carregar a página para definir o estado inicial
        document.addEventListener('DOMContentLoaded', handlePixKeyTypeChange);
    </script>
</body>
</html>
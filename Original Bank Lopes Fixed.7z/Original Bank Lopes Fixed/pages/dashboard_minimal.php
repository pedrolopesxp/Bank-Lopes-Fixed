<?php
// Iniciar a sessão (se ainda não estiver iniciada)
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// *** MUITO IMPORTANTE: Verifique se estes caminhos estão corretos ***
// Se o seu 'dashboard_minimal.php' estiver em 'htdocs/seuprojeto/public/'
// E 'database.php' estiver em 'htdocs/seuprojeto/config/'
// E 'utils.php' estiver em 'htdocs/seuprojeto/includes/'
// Então, os caminhos abaixo estão corretos.
// CASO CONTRÁRIO, ajuste-os!
require_once __DIR__ . '/../config/database.php'; // Ajuste este caminho se necessário
require_once __DIR__ . '/../includes/utils.php';    // Ajuste este caminho se necessário

// Redirecionar se o usuário não estiver logado
if (!isset($_SESSION['user_id'])) {
    // Certifique-se de que este caminho para o login.php está correto
    // Por exemplo, se login.php estiver em htdocs/seuprojeto/public/login.php
    header("Location: ../public/login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$user_name = $_SESSION['user_name'] ?? 'Usuário';

// Tentar uma consulta simples para verificar a conexão com o banco de dados
try {
    $stmt = $pdo->query("SELECT 1"); // Uma consulta simples para testar a conexão
    $test_db_connection = true;
} catch (PDOException $e) {
    $test_db_connection = false;
    error_log("Erro na conexão/consulta de teste do BD: " . $e->getMessage());
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Minimal - Pay</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen flex flex-col items-center justify-center">
    <div class="bg-white p-8 rounded-xl shadow-md text-center">
        <h1 class="text-3xl font-bold text-indigo-700 mb-4">Bem-vindo, <?php echo htmlspecialchars($user_name); ?>!</h1>
        <p class="text-lg text-gray-700">Esta é a sua página de dashboard mínima.</p>
        <?php if ($test_db_connection): ?>
            <p class="text-green-600 mt-4"><i class="fas fa-check-circle"></i> Conexão com o banco de dados OK!</p>
        <?php else: ?>
            <p class="text-red-600 mt-4"><i class="fas fa-exclamation-circle"></i> Erro na conexão com o banco de dados. Verifique o `database.php` e logs do servidor!</p>
        <?php endif; ?>
        <a href="../public/logout.php" class="mt-6 inline-block btn-primary hover:bg-indigo-800">Sair</a>
    </div>

    <!-- Adicione o Font Awesome para o ícone de check/exclamação -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <style>
        .btn-primary {
            background-color: #4c51bf; /* indigo-700 */
            color: white;
            padding: 0.75rem 1.5rem;
            border-radius: 0.5rem;
            transition: background-color 0.3s ease;
        }
    </style>
</body>
</html>

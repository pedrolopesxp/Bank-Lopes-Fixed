<?php
// www/pages/login.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

if (isset($_SESSION['user_id'])) {
    redirect('../pages/dashboard.php'); // Já logado, redireciona para o dashboard
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Correção: Usar isset() com operador ternário para compatibilidade com PHP < 7.0
    $email = trim(isset($_POST['email']) ? $_POST['email'] : '');
    $password = trim(isset($_POST['password']) ? $_POST['password'] : '');

    if (empty($email) || empty($password)) {
        set_message("Por favor, preencha todos os campos.", "error");
    } elseif (!is_valid_email($email)) {
        set_message("Formato de e-mail inválido.", "error");
    } else {
        try {
            $stmt = $pdo->prepare("SELECT id_usuario, nm_usuario, ds_senha_hash, ds_status FROM tb_usuario WHERE ds_email = ?");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && verify_password($password, $user['ds_senha_hash'])) {
                // Adição da verificação de status 'Bloqueado'
                if ($user['ds_status'] === 'Bloqueado') {
                    set_message("Seu acesso foi bloqueado pelo administrador. Por favor, entre em contato com o suporte.", "error");
                    // O redirecionamento abaixo garante que a mensagem seja exibida na página de login
                    redirect('login.php');
                } elseif ($user['ds_status'] === 'Ativo') {
                    // Login bem-sucedido
                    $_SESSION['user_id'] = $user['id_usuario'];
                    $_SESSION['user_name'] = $user['nm_usuario'];
                    set_message("Login realizado com sucesso!", "success");
                    redirect('dashboard.php');
                } else {
                    // Outros status, como 'Inativo' (se aplicável), podem ser tratados aqui
                    set_message("Sua conta não está ativa. Por favor, verifique seu e-mail ou entre em contato com o suporte.", "error");
                }
            } else {
                // Usuário não encontrado ou senha incorreta
                set_message("E-mail ou senha incorretos.", "error");
            }
        } catch (PDOException $e) {
            error_log("Erro no login: " . $e->getMessage());
            set_message("Ocorreu um erro no servidor. Tente novamente mais tarde.", "error");
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="../index.php">Início</a></li>
                    <li><a href="../pages/register.php" class="button secondary">Abrir Conta</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container">
            <h2>Login</h2>
            <?php display_messages(); ?>
            <form action="login.php" method="POST">
                <input type="email" name="email" placeholder="Seu E-mail" required autocomplete="email" value="<?= htmlspecialchars(isset($_POST['email']) ? $_POST['email'] : '') ?>">
                <input type="password" name="password" placeholder="Sua Senha" required autocomplete="current-password">
                <button type="submit" class="button primary">Entrar</button>
                <p>
                    <a href="recover_password.php">Esqueceu sua senha?</a><br>
                    Não tem uma conta? <a href="register.php">Crie uma agora!</a>
                </p>
            </form>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>
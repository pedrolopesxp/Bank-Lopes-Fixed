<?php
// www/pages/pix_refund.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Verifica se o usuário está logado
if (!isset($_SESSION['user_id'])) {
    set_message("Você precisa estar logado para solicitar estorno de PIX.", "error");
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$userName = htmlspecialchars($_SESSION['user_name'] ?? 'Usuário');

$recent_pix_transactions = [];
try {
    // Buscar transações PIX recebidas pelo usuário logado que podem ser estornadas
    // Assumimos que apenas PIX recebidos (onde o usuário é o destinatário) podem ser estornados por ele.
    // E que o status deve ser 'Concluída' para ser estornável.
    // Excluímos 'Estorno PIX' para evitar loop.
    $stmt_pix = $pdo->prepare("
        SELECT
            id_transacao,
            vl_quantidade_real,
            dt_transacao,
            ds_descricao,
            tp_tipo,
            tp_metodo_pagamento,
            ds_status
        FROM
            tb_transacao
        WHERE
            id_destinatario = ?
            AND tp_tipo IN ('PIX Recebido', 'Transferência') -- Pode estornar PIX ou transferências recebidas
            AND ds_status = 'Concluída'
            AND id_transacao NOT IN (SELECT id_transacao_original FROM tb_transacao WHERE id_transacao_original IS NOT NULL) -- Não mostra transações que já foram estornadas
        ORDER BY
            dt_transacao DESC
        LIMIT 10 -- Limita para facilitar a visualização
    ");
    $stmt_pix->execute([$user_id]);
    $recent_pix_transactions = $stmt_pix->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Erro ao buscar transações PIX para estorno: " . $e->getMessage());
    set_message("Erro ao carregar transações para estorno. Por favor, tente novamente.", "error");
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'request_refund') {
    $transaction_id_to_refund = intval(isset($_POST['transaction_id']) ? $_POST['transaction_id'] : 0);
    $refund_reason = trim(isset($_POST['refund_reason']) ? $_POST['refund_reason'] : '');

    if ($transaction_id_to_refund <= 0) {
        set_message("ID da transação inválido.", "error");
    } elseif (empty($refund_reason)) {
        set_message("Por favor, forneça um motivo para o estorno.", "error");
    } else {
        try {
            $pdo->beginTransaction();

            // 1. Verificar se a transação é válida para estorno e pertence ao usuário logado
            $stmt_check_tx = $pdo->prepare("
                SELECT
                    id_transacao,
                    vl_quantidade_real,
                    vl_quantidade_bitcoin,
                    id_remetente, -- Quem enviou o PIX original
                    tp_tipo
                FROM
                    tb_transacao
                WHERE
                    id_transacao = ?
                    AND id_destinatario = ? -- Usuário logado deve ser o destinatário da transação original
                    AND ds_status = 'Concluída'
                    AND tp_tipo IN ('PIX Recebido', 'Transferência')
                    AND id_transacao NOT IN (SELECT id_transacao_original FROM tb_transacao WHERE id_transacao_original IS NOT NULL)
                FOR UPDATE -- Bloqueia a linha para evitar concorrência
            ");
            $stmt_check_tx->execute([$transaction_id_to_refund, $user_id]);
            $original_transaction = $stmt_check_tx->fetch(PDO::FETCH_ASSOC);

            if (!$original_transaction) {
                set_message("Transação não encontrada, já estornada ou inválida para estorno.", "error");
                $pdo->rollBack();
            } else {
                $refund_amount_real = $original_transaction['vl_quantidade_real'];
                $refund_amount_bitcoin = $original_transaction['vl_quantidade_bitcoin'];
                $original_sender_id = $original_transaction['id_remetente'];

                // 2. Diminuir o saldo do usuário logado (que está estornando)
                // Se o estorno for em BRL
                if ($refund_amount_real > 0) {
                    $stmt_update_sender_balance = $pdo->prepare("UPDATE tb_conta SET vl_saldo_real = vl_saldo_real - ? WHERE id_usuario = ?");
                    // Recarrega os saldos para verificação de saldo atualizada no mesmo request
                    $stmt_balance_check = $pdo->prepare("SELECT vl_saldo_real FROM tb_conta WHERE id_usuario = ?");
                    $stmt_balance_check->execute([$user_id]);
                    $current_real_balance_check = $stmt_balance_check->fetchColumn();

                    if ($refund_amount_real > $current_real_balance_check) {
                         set_message("Saldo em Reais insuficiente para realizar o estorno.", "error");
                         $pdo->rollBack();
                         // Recarrega os saldos para exibição correta (do início do script)
                         $stmt_balance = $pdo->prepare("SELECT vl_saldo_bitcoin, vl_saldo_real FROM tb_conta WHERE id_usuario = ?");
                         $stmt_balance->execute([$user_id]);
                         $account_data = $stmt_balance->fetch(PDO::FETCH_ASSOC);
                         if ($account_data) {
                             $current_bitcoin_balance = $account_data['vl_saldo_bitcoin'];
                             $current_real_balance = $account_data['vl_saldo_real'];
                         }
                         return; // Sai do script para exibir a mensagem de erro
                    }
                    $stmt_update_sender_balance->execute([$refund_amount_real, $user_id]);
                }
                // Se o estorno for em BTC
                if ($refund_amount_bitcoin > 0) {
                    $stmt_update_sender_balance = $pdo->prepare("UPDATE tb_conta SET vl_saldo_bitcoin = vl_saldo_bitcoin - ? WHERE id_usuario = ?");
                    // Recarrega os saldos para verificação de saldo atualizada no mesmo request
                    $stmt_balance_check = $pdo->prepare("SELECT vl_saldo_bitcoin FROM tb_conta WHERE id_usuario = ?");
                    $stmt_balance_check->execute([$user_id]);
                    $current_bitcoin_balance_check = $stmt_balance_check->fetchColumn();

                    if ($refund_amount_bitcoin > $current_bitcoin_balance_check) {
                         set_message("Saldo em Bitcoin insuficiente para realizar o estorno.", "error");
                         $pdo->rollBack();
                         // Recarrega os saldos para exibição correta (do início do script)
                         $stmt_balance = $pdo->prepare("SELECT vl_saldo_bitcoin, vl_saldo_real FROM tb_conta WHERE id_usuario = ?");
                         $stmt_balance->execute([$user_id]);
                         $account_data = $stmt_balance->fetch(PDO::FETCH_ASSOC);
                         if ($account_data) {
                             $current_bitcoin_balance = $account_data['vl_saldo_bitcoin'];
                             $current_real_balance = $account_data['vl_saldo_real'];
                         }
                         return; // Sai do script para exibir a mensagem de erro
                    }
                    $stmt_update_sender_balance->execute([$refund_amount_bitcoin, $user_id]);
                }


                // 3. Aumentar o saldo do remetente original (que receberá o estorno)
                // Determina se a transação original era em BRL ou BTC e ajusta o saldo do remetente original
                if ($refund_amount_real > 0) {
                    $stmt_update_receiver_balance = $pdo->prepare("UPDATE tb_conta SET vl_saldo_real = vl_saldo_real + ? WHERE id_usuario = ?");
                    $stmt_update_receiver_balance->execute([$refund_amount_real, $original_sender_id]);
                }
                if ($refund_amount_bitcoin > 0) {
                    $stmt_update_receiver_balance = $pdo->prepare("UPDATE tb_conta SET vl_saldo_bitcoin = vl_saldo_bitcoin + ? WHERE id_usuario = ?");
                    $stmt_update_receiver_balance->execute([$refund_amount_bitcoin, $original_sender_id]);
                }


                // 4. Registrar a transação de estorno
                $stmt_insert_refund_tx = $pdo->prepare("
                    INSERT INTO tb_transacao (
                        tp_tipo, tp_metodo_pagamento, id_remetente, id_destinatario,
                        vl_quantidade_real, vl_quantidade_bitcoin, vl_taxa, ds_status, dt_transacao,
                        ds_descricao, id_transacao_original
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?)
                ");
                $stmt_insert_refund_tx->execute([
                    'Estorno PIX', // Novo tipo de transação
                    'PIX', // Método do estorno
                    $user_id, // Usuário que solicitou o estorno (remetente do estorno)
                    $original_sender_id, // Remetente original da PIX (destinatário do estorno)
                    $refund_amount_real,
                    $refund_amount_bitcoin,
                    0, // Taxa de estorno (ajuste se houver)
                    'Concluída', // Estorno é considerado concluído se os saldos forem ajustados
                    "Estorno da transação #" . $transaction_id_to_refund . ". Motivo: " . htmlspecialchars($refund_reason),
                    $transaction_id_to_refund // Referência à transação original
                ]);

                // 5. Atualizar o status da transação original para indicar que foi estornada
                $stmt_update_original_tx = $pdo->prepare("UPDATE tb_transacao SET ds_status = 'Estornada' WHERE id_transacao = ?");
                $stmt_update_original_tx->execute([$transaction_id_to_refund]);


                $pdo->commit();
                set_message("Estorno da transação #" . $transaction_id_to_refund . " solicitado e processado com sucesso!", "success");
                redirect('pix_refund.php'); // Recarrega a página para refletir as mudanças
            }
        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log("Erro no processamento do estorno: " . $e->getMessage());
            set_message("Ocorreu um erro ao processar o estorno: " . $e->getMessage(), "error");
        }
    }
    // Re-busca transações após POST
    try {
        $stmt_pix = $pdo->prepare("
            SELECT
                id_transacao,
                vl_quantidade_real,
                dt_transacao,
                ds_descricao,
                tp_tipo,
                tp_metodo_pagamento,
                ds_status
            FROM
                tb_transacao
            WHERE
                id_destinatario = ?
                AND tp_tipo IN ('PIX Recebido', 'Transferência')
                AND ds_status = 'Concluída'
                AND id_transacao NOT IN (SELECT id_transacao_original FROM tb_transacao WHERE id_transacao_original IS NOT NULL)
            ORDER BY
                dt_transacao DESC
            LIMIT 10
        ");
        $stmt_pix->execute([$user_id]);
        $recent_pix_transactions = $stmt_pix->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        error_log("Erro ao re-buscar transações PIX para estorno após POST: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estorno PIX - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .refund-transaction-list {
            list-style: none;
            padding: 0;
            margin-top: 20px;
        }
        .refund-transaction-item {
            background-color: var(--light-gray);
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        .refund-transaction-item p {
            margin: 0;
            font-size: 0.95em;
        }
        .refund-transaction-item strong {
            color: var(--primary-dark-color);
        }
        .refund-transaction-item .refund-button {
            background-color: #dc3545; /* Vermelho */
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.2s ease;
            margin-top: 10px;
        }
        .refund-transaction-item .refund-button:hover {
            background-color: #c82333;
        }
        .refund-transaction-item .refund-button:disabled {
            background-color: #cccccc;
            cursor: not-allowed;
        }

        .refund-form-grid {
            display: grid;
            grid-template-columns: 1fr;
            gap: 15px;
            margin-top: 20px;
        }
        .refund-form-grid label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: var(--text-color);
        }
        .refund-form-grid input[type="text"],
        .refund-form-grid textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            font-size: 1em;
            box-sizing: border-box;
        }
        .refund-form-grid .full-width {
            grid-column: 1 / -1;
        }
        @media (min-width: 768px) {
            .refund-transaction-item {
                flex-direction: row;
                justify-content: space-between;
                align-items: center;
                flex-wrap: wrap;
            }
            .refund-transaction-item > p {
                flex: 1;
                min-width: 150px; /* Garante que os itens não fiquem muito pequenos */
            }
            .refund-transaction-item .refund-button-container {
                flex-shrink: 0;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li>Olá, <?= $userName ?></li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container" style="max-width: 90%; text-align: left;">
            <h2>Solicitar Estorno de PIX</h2>
            <?php display_messages(); ?>

            <h3>Transações PIX Recebidas Recentes (Estornáveis)</h3>
            <?php if (empty($recent_pix_transactions)): ?>
                <p>Nenhuma transação PIX recebida recente para estorno.</p>
            <?php else: ?>
                <ul class="refund-transaction-list">
                    <?php foreach ($recent_pix_transactions as $transaction): ?>
                        <li class="refund-transaction-item">
                            <p><strong>ID Transação:</strong> #<?= htmlspecialchars($transaction['id_transacao']) ?></p>
                            <p><strong>Tipo:</strong> <?= htmlspecialchars($transaction['tp_tipo']) ?></p>
                            <p><strong>Valor:</strong> R$ <?= htmlspecialchars(number_format($transaction['vl_quantidade_real'], 2, ',', '.')) ?></p>
                            <p><strong>Data:</strong> <?= htmlspecialchars(date('d/m/Y H:i', strtotime($transaction['dt_transacao']))) ?></p>
                            <?php if (!empty($transaction['ds_descricao'])): ?>
                                <p>Descrição: <small><?= htmlspecialchars($transaction['ds_descricao']) ?></small></p>
                            <?php endif; ?>
                            <div class="refund-button-container">
                                <form action="pix_refund.php" method="POST" onsubmit="return confirm('Tem certeza que deseja solicitar o estorno desta transação?');">
                                    <input type="hidden" name="action" value="request_refund">
                                    <input type="hidden" name="transaction_id" value="<?= htmlspecialchars($transaction['id_transacao']) ?>">
                                    <label for="refund_reason_<?= htmlspecialchars($transaction['id_transacao']) ?>" style="display: none;">Motivo do Estorno:</label>
                                    <textarea id="refund_reason_<?= htmlspecialchars($transaction['id_transacao']) ?>" name="refund_reason" rows="2" placeholder="Motivo do estorno (obrigatório)" required style="width: 100%; margin-bottom: 5px;"></textarea>
                                    <button type="submit" class="refund-button">Solicitar Estorno</button>
                                </form>
                            </div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>

            <p style="margin-top: 30px;"><a href="dashboard.php">Voltar para o Dashboard</a></p>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>

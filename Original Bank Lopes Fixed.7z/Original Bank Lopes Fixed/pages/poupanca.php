<?php
// www/pages/poupanca.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

if (!isset($_SESSION['user_id'])) {
    set_message("Você precisa estar logado para acessar a poupança.", "error");
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$userName = htmlspecialchars($_SESSION['user_name'] ?? 'Usuário');

// --- Variáveis de saldo ---
$current_real_balance = 0;
$poupanca_balance = 0;
$annual_yield = 0.05; // 5% ao ano (Exemplo)

// --- Lógica para processar depósito/resgate ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $action = filter_input(INPUT_POST, 'action', FILTER_SANITIZE_STRING);
    $amount = filter_input(INPUT_POST, 'amount', FILTER_VALIDATE_FLOAT);

    if (!$amount || $amount <= 0) {
        set_message("O valor deve ser positivo e numérico.", "error");
        redirect('poupanca.php');
    }

    try {
        $pdo->beginTransaction();

        // 1. Recarregar saldos para validação dentro da transação (FOR UPDATE bloqueia a linha)
        // OBSERVAÇÃO: Esta consulta exige que a coluna 'vl_saldo_poupanca' exista na tabela tb_conta.
        $stmt_balance_lock = $pdo->prepare("SELECT vl_saldo_real, vl_saldo_poupanca FROM tb_conta WHERE id_usuario = ? FOR UPDATE");
        $stmt_balance_lock->execute([$user_id]);
        $account_data = $stmt_balance_lock->fetch(PDO::FETCH_ASSOC);

        if (!$account_data) {
            $pdo->rollBack();
            set_message("Conta não encontrada. Por favor, entre em contato com o suporte.", "error");
            redirect('poupanca.php');
        }

        $current_real_balance = $account_data['vl_saldo_real'];
        $poupanca_balance = $account_data['vl_saldo_poupanca'];

        $success_message = "";
        $error_message = "";

        if ($action === 'deposit') { // Depositar: Corrente (vl_saldo_real) -> Poupança (vl_saldo_poupanca)
            if ($current_real_balance < $amount) {
                $error_message = "Saldo insuficiente na conta corrente (R$ " . number_format($current_real_balance, 2, ',', '.') . ").";
            } else {
                $new_real_balance = $current_real_balance - $amount;
                $new_poupanca_balance = $poupanca_balance + $amount;

                $stmt_update = $pdo->prepare("UPDATE tb_conta SET vl_saldo_real = ?, vl_saldo_poupanca = ? WHERE id_usuario = ?");
                $stmt_update->execute([$new_real_balance, $new_poupanca_balance, $user_id]);
                $success_message = "Depósito de R$ " . number_format($amount, 2, ',', '.') . " realizado com sucesso na Poupança!";
            }
        } elseif ($action === 'withdraw') { // Resgate: Poupança (vl_saldo_poupanca) -> Corrente (vl_saldo_real)
            if ($poupanca_balance < $amount) {
                $error_message = "Saldo insuficiente na poupança (R$ " . number_format($poupanca_balance, 2, ',', '.') . ").";
            } else {
                $new_real_balance = $current_real_balance + $amount;
                $new_poupanca_balance = $poupanca_balance - $amount;

                $stmt_update = $pdo->prepare("UPDATE tb_conta SET vl_saldo_real = ?, vl_saldo_poupanca = ? WHERE id_usuario = ?");
                $stmt_update->execute([$new_real_balance, $new_poupanca_balance, $user_id]);
                $success_message = "Resgate de R$ " . number_format($amount, 2, ',', '.') . " realizado com sucesso para a Conta Corrente!";
            }
        } else {
            $error_message = "Ação inválida.";
        }

        if (!empty($error_message)) {
            $pdo->rollBack();
            set_message($error_message, "error");
        } else {
            $pdo->commit();
            set_message($success_message, "success");
        }
        
        redirect('poupanca.php');

    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Erro ao movimentar poupança: " . $e->getMessage());
        if (strpos($e->getMessage(), 'vl_saldo_poupanca') !== false) {
             set_message("Erro de configuração: A coluna 'vl_saldo_poupanca' não existe na tabela 'tb_conta'. Por favor, execute o SQL de atualização no Passo 1.", "error");
        } else {
             set_message("Erro inesperado ao movimentar poupança. Detalhes: " . $e->getMessage(), "error");
        }
        redirect('poupanca.php');
    }
}


// --- Lógica para recarregar saldos para exibição ---
try {
    // Tenta buscar os dois saldos. Se a coluna poupanca não existir, a query falhará
    $stmt_balance = $pdo->prepare("SELECT vl_saldo_real, vl_saldo_poupanca FROM tb_conta WHERE id_usuario = ?");
    $stmt_balance->execute([$user_id]);
    $account_data = $stmt_balance->fetch(PDO::FETCH_ASSOC);

    if ($account_data) {
        $current_real_balance = $account_data['vl_saldo_real']; 
        $poupanca_balance = $account_data['vl_saldo_poupanca'];
    }

} catch (PDOException $e) {
    // Captura o erro se a coluna 'vl_saldo_poupanca' ainda não foi criada
    if (strpos($e->getMessage(), 'vl_saldo_poupanca') !== false) {
        set_message("ATENÇÃO: A coluna 'vl_saldo_poupanca' não foi encontrada. Execute o SQL no Passo 1 para ativar a poupança.", "warning");
    } else {
        error_log("Erro ao buscar saldos: " . $e->getMessage());
    }
}

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minha Poupança - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        .poupanca-container {
            max-width: 800px;
            margin: 40px auto;
            padding: 30px;
            background-color: var(--secondary-color);
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }
        .balance-box {
            background-color: var(--input-bg-color);
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            margin-bottom: 25px;
            border: 1px solid var(--border-color);
        }
        .balance-box h2 {
            color: var(--primary-color);
            font-size: 1.4em;
        }
        .balance-box p {
            font-size: 2.5em;
            font-weight: bold;
            color: var(--highlight-color);
            margin: 10px 0 0;
        }
        .details-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
        }
        .detail-card {
            background-color: var(--input-bg-color);
            padding: 15px;
            border-radius: 8px;
            border: 1px solid var(--border-color);
        }
        .detail-card strong {
            display: block;
            color: var(--primary-color);
            margin-bottom: 5px;
        }
        /* Estilos do formulário de movimentação */
        .movement-section {
            background-color: var(--input-bg-color);
            padding: 25px;
            border-radius: 10px;
            margin-top: 30px;
            border: 1px solid var(--border-color);
        }
        .movement-section h2 {
            margin-top: 0;
            margin-bottom: 15px;
        }
        .movement-section form {
            display: flex;
            gap: 15px;
            align-items: center;
        }
        .movement-section .form-group {
            flex-grow: 1;
            margin-bottom: 0;
        }
        .movement-section input[type="number"] {
            width: 100%;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>Bank Lopes</h1>
            <nav>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="deposit_withdraw.php">Depósito/Saque</a></li>
                    <li><a href="transfer.php">Transferir</a></li>
                    <li><a href="transaction_history.php">Histórico</a></li>
                    <li>Olá, <?= $userName ?>!</li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <div class="poupanca-container">
            <?php display_messages(); ?>
            <h1><i class="fa-solid fa-piggy-bank"></i> Minha Poupança</h1>
            <hr>

            <div class="details-grid">
                <div class="balance-box">
                    <h2>Saldo na Poupança</h2>
                    <p>R$ <?= htmlspecialchars(number_format($poupanca_balance, 2, ',', '.')) ?></p>
                </div>
                <div class="balance-box">
                    <h2>Saldo Conta Corrente</h2>
                    <p>R$ <?= htmlspecialchars(number_format($current_real_balance, 2, ',', '.')) ?></p>
                </div>
            </div>

            <div class="details-grid" style="margin-top: 20px;">
                <div class="detail-card">
                    <strong>Rendimento Anual Estimado</strong>
                    <span><?= htmlspecialchars(number_format($annual_yield * 100, 2, ',', '.')) ?>%</span>
                </div>
                <div class="detail-card">
                    <strong>Próximo Rendimento</strong>
                    <span>01 de <?= date('m') == 12 ? 'Janeiro' : date('F', strtotime('+1 month')) ?></span>
                </div>
            </div>

            <div class="movement-section">
                <h2>Depositar para Poupança (Corrente &rarr; Poupança)</h2>
                <form action="poupanca.php" method="POST">
                    <input type="hidden" name="action" value="deposit">
                    <div class="form-group">
                        <label for="deposit_amount">Valor a Depositar (R$):</label>
                        <input type="number" id="deposit_amount" name="amount" step="0.01" min="0.01" placeholder="R$ 0,00" required>
                    </div>
                    <button type="submit" class="button primary">Depositar</button>
                </form>
            </div>

            <div class="movement-section">
                <h2>Resgatar da Poupança (Poupança &rarr; Corrente)</h2>
                <form action="poupanca.php" method="POST">
                    <input type="hidden" name="action" value="withdraw">
                    <div class="form-group">
                        <label for="withdraw_amount">Valor a Resgatar (R$):</label>
                        <input type="number" id="withdraw_amount" name="amount" step="0.01" min="0.01" placeholder="R$ 0,00" required>
                    </div>
                    <button type="submit" class="button primary">Resgatar</button>
                </form>
            </div>

        </div>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados.</p>
        </div>
    </footer>
</body>
</html>
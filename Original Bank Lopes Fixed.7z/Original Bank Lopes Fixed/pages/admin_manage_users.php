<?php
// www/pages/admin_manage_users.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Verifica se o administrador está logado. Se não, redireciona para a página de login do admin.
if (!isset($_SESSION['admin_id'])) {
    set_message("Você precisa estar logado como administrador para acessar esta área.", "error");
    redirect('admin_login.php');
}

$admin_name = htmlspecialchars($_SESSION['admin_name'] ?? 'Administrador');
$admin_level = htmlspecialchars($_SESSION['admin_level'] ?? 'Nível Desconhecido');

$search_query = isset($_GET['search']) ? trim($_GET['search']) : '';
$status_filter = isset($_GET['status']) ? trim($_GET['status']) : '';

// --- Lógica para excluir, bloquear e desbloquear usuário ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $user_id = filter_input(INPUT_POST, 'id_usuario', FILTER_VALIDATE_INT);

    if (!$user_id) {
        set_message("ID de usuário inválido.", "error");
        redirect('admin_manage_users.php');
    }

    try {
        $pdo->beginTransaction();

        if ($_POST['action'] === 'delete_user') {
            // Exclui a conta do usuário primeiro
            $stmt_delete_account = $pdo->prepare("DELETE FROM tb_conta WHERE id_usuario = ?");
            $stmt_delete_account->execute([$user_id]);
            // Exclui o usuário
            $stmt_delete_user = $pdo->prepare("DELETE FROM tb_usuario WHERE id_usuario = ?");
            if ($stmt_delete_user->execute([$user_id])) {
                $pdo->commit();
                set_message("Usuário excluído com sucesso!", "success");
            } else {
                $pdo->rollBack();
                set_message("Não foi possível excluir o usuário. Ocorreu um erro no banco de dados.", "error");
            }
        } elseif ($_POST['action'] === 'block_user') {
            $stmt = $pdo->prepare("UPDATE tb_usuario SET ds_status = 'Bloqueado' WHERE id_usuario = ?");
            if ($stmt->execute([$user_id])) {
                $pdo->commit();
                set_message("Usuário bloqueado com sucesso!", "success");
            } else {
                $pdo->rollBack();
                set_message("Não foi possível bloquear o usuário.", "error");
            }
        } elseif ($_POST['action'] === 'unblock_user') {
            $stmt = $pdo->prepare("UPDATE tb_usuario SET ds_status = 'Ativo' WHERE id_usuario = ?");
            if ($stmt->execute([$user_id])) {
                $pdo->commit();
                set_message("Usuário desbloqueado com sucesso!", "success");
            } else {
                $pdo->rollBack();
                set_message("Não foi possível desbloquear o usuário.", "error");
            }
        } else {
            set_message("Ação inválida.", "error");
            $pdo->rollBack(); // Garante que a transação seja desfeita se a ação for inválida
        }
    } catch (PDOException $e) {
        $pdo->rollBack();
        error_log("Erro ao gerenciar usuário: " . $e->getMessage());
        set_message("Ocorreu um erro ao processar a solicitação. Verifique os logs.", "error");
    }
    // Redireciona para evitar re-submissão do formulário.
    redirect('admin_manage_users.php');
}

// --- Construção da consulta SQL com filtros e busca ---
$sql = "SELECT id_usuario, nm_usuario, ds_email, ds_cpf, ds_status, dt_cadastro FROM tb_usuario WHERE 1=1";
$params = [];

if (!empty($search_query)) {
    $sql .= " AND (nm_usuario LIKE ? OR ds_email LIKE ? OR ds_cpf LIKE ?)";
    $search_param = '%' . $search_query . '%';
    $params[] = $search_param;
    $params[] = $search_param;
    $params[] = $search_param;
}

if (!empty($status_filter)) {
    $sql .= " AND ds_status = ?";
    $params[] = $status_filter;
}

$sql .= " ORDER BY dt_cadastro DESC";

$users = [];
try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $users = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Erro ao buscar usuários para gerenciamento: " . $e->getMessage());
    set_message("Ocorreu um erro ao carregar a lista de usuários.", "error");
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Usuários - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .user-table-container {
            overflow-x: auto;
        }

        .user-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .user-table th, .user-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }

        .user-table th {
            background-color: var(--light-gray);
            font-weight: bold;
            color: var(--primary-dark-color);
        }

        .user-table tbody tr:hover {
            background-color: #f1f1f1;
        }
        
        .action-buttons a.button, .action-buttons button {
            padding: 5px 10px;
            font-size: 0.9em;
            margin-right: 5px;
            text-decoration: none;
            display: inline-block;
            vertical-align: middle;
            text-align: center;
        }

        .action-buttons form {
            display: inline;
            margin-left: 5px; /* Espaço para botões de ação */
        }

        .action-buttons button.danger, .action-buttons button.warning {
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        
        .action-buttons button.danger { /* Excluir */
            background-color: var(--danger-color);
            color: white;
        }
        .action-buttons button.danger:hover {
            background-color: #d32f2f;
        }

        .action-buttons button.warning { /* Bloquear/Desbloquear */
            background-color: #ffc107; /* Amarelo */
            color: #333;
        }
        .action-buttons button.warning:hover {
            background-color: #e0a800;
        }

        .filters-container {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
            align-items: center;
        }

        .filters-container input, .filters-container select, .filters-container .button {
            padding: 8px 12px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        
        /* Estilos para o status do usuário na tabela */
        .status-ativo { color: var(--primary-color); font-weight: bold; }
        .status-inativo { color: #6c757d; }
        .status-bloqueado { color: var(--danger-color); font-weight: bold; }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Admin Bank Lopes</div>
            <nav>
                <ul>
                    <li>Olá, <?= $admin_name ?>! (<?= $admin_level ?>)</li>
                    <li><a href="admin_dashboard.php">Dashboard</a></li>
                    <li><a href="admin_manage_users.php" class="active">Gerenciar Usuários</a></li>
                    <li><a href="admin_manage_fees.php">Gerenciar Taxas</a></li>
                    <li><a href="admin_view_transactions.php">Transações</a></li>
                    <li><a href="admin_logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="container">
            <h2>Gerenciar Usuários</h2>
            <?php display_messages(); ?>

            <div class="filters-container">
                <form action="admin_manage_users.php" method="GET" style="display: flex; gap: 10px; align-items: center;">
                    <input type="text" name="search" placeholder="Buscar por nome, e-mail ou CPF..." value="<?= htmlspecialchars($search_query) ?>">
                    <select name="status">
                        <option value="">Todos os Status</option>
                        <option value="Ativo" <?= $status_filter === 'Ativo' ? 'selected' : '' ?>>Ativo</option>
                        <option value="Inativo" <?= $status_filter === 'Inativo' ? 'selected' : '' ?>>Inativo</option>
                        <option value="Bloqueado" <?= $status_filter === 'Bloqueado' ? 'selected' : '' ?>>Bloqueado</option>
                    </select>
                    <button type="submit" class="button primary">Filtrar</button>
                    <a href="admin_manage_users.php" class="button secondary">Limpar Filtros</a>
                </form>
            </div>
            
            <div style="margin-bottom: 20px;">
                <a href="admin_add_user.php" class="button primary">
                    <i class="fas fa-plus"></i> Adicionar Novo Usuário
                </a>
            </div>

            <?php if (!empty($users)): ?>
                <div class="user-table-container">
                    <table class="user-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nome</th>
                                <th>E-mail</th>
                                <th>CPF</th>
                                <th>Status</th>
                                <th>Cadastro</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><?= htmlspecialchars($user['id_usuario']) ?></td>
                                    <td><?= htmlspecialchars($user['nm_usuario']) ?></td>
                                    <td><?= htmlspecialchars($user['ds_email']) ?></td>
                                    <td><?= htmlspecialchars($user['ds_cpf']) ?></td>
                                    <td>
                                        <span class="status-<?= strtolower($user['ds_status']) ?>">
                                            <?= htmlspecialchars($user['ds_status']) ?>
                                        </span>
                                    </td>
                                    <td><?= htmlspecialchars(date('d/m/Y H:i', strtotime($user['dt_cadastro']))) ?></td>
                                    <td>
                                        <div class="action-buttons">
                                            <a href="admin_user_details.php?id=<?= htmlspecialchars($user['id_usuario']) ?>" class="button secondary">Ver Detalhes</a>
                                            <a href="admin_user_edit.php?id=<?= htmlspecialchars($user['id_usuario']) ?>" class="button">Editar</a>
                                            
                                            <?php if ($user['ds_status'] === 'Ativo'): ?>
                                                <form action="admin_manage_users.php" method="POST" onsubmit="return confirm('Tem certeza que deseja BLOQUEAR este usuário?');">
                                                    <input type="hidden" name="action" value="block_user">
                                                    <input type="hidden" name="id_usuario" value="<?= htmlspecialchars($user['id_usuario']) ?>">
                                                    <button type="submit" class="button warning">Bloquear</button>
                                                </form>
                                            <?php elseif ($user['ds_status'] === 'Bloqueado'): ?>
                                                <form action="admin_manage_users.php" method="POST" onsubmit="return confirm('Tem certeza que deseja DESBLOQUEAR este usuário?');">
                                                    <input type="hidden" name="action" value="unblock_user">
                                                    <input type="hidden" name="id_usuario" value="<?= htmlspecialchars($user['id_usuario']) ?>">
                                                    <button type="submit" class="button warning">Desbloquear</button>
                                                </form>
                                            <?php endif; ?>
                                            
                                            <form action="admin_manage_users.php" method="POST" onsubmit="return confirm('Tem certeza que deseja excluir este usuário? Esta ação é irreversível e excluirá a conta dele!');">
                                                <input type="hidden" name="action" value="delete_user">
                                                <input type="hidden" name="id_usuario" value="<?= htmlspecialchars($user['id_usuario']) ?>">
                                                <button type="submit" class="button danger">Excluir</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php else: ?>
                <p>Nenhum usuário encontrado com os critérios de busca.</p>
            <?php endif; ?>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>
<?php
// www/pages/admin_dashboard.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Verifica se o administrador está logado. Se não, redireciona para a página de login do admin.
if (!isset($_SESSION['admin_id'])) {
    set_message("Você precisa estar logado como administrador para acessar esta área.", "error");
    redirect('admin_login.php');
}

$admin_id = $_SESSION['admin_id'];
$admin_name = htmlspecialchars($_SESSION['admin_name'] ?? 'Administrador');
$admin_level = htmlspecialchars($_SESSION['admin_level'] ?? 'Nível Desconhecido');

// --- Dados para o Dashboard ---
// As consultas ao banco de dados são realizadas aqui para popular as informações.

// Total de Usuários
try {
    $stmt_total_users = $pdo->query("SELECT COUNT(*) FROM tb_usuario");
    $total_users = $stmt_total_users->fetchColumn();
} catch (PDOException $e) {
    error_log("Erro ao buscar total de usuários: " . $e->getMessage());
    $total_users = "Erro";
}

// Saldo Total de Bitcoin (soma de todas as contas)
try {
    $stmt_total_btc = $pdo->query("SELECT SUM(vl_saldo_bitcoin) FROM tb_conta");
    $total_btc_balance = $stmt_total_btc->fetchColumn();
    $total_btc_balance = number_format($total_btc_balance, 8, ',', '.');
} catch (PDOException $e) {
    error_log("Erro ao buscar saldo total de Bitcoin: " . $e->getMessage());
    $total_btc_balance = "Erro";
}

// Saldo Total em Reais (soma de todas as contas)
try {
    $stmt_total_real = $pdo->query("SELECT SUM(vl_saldo_real) FROM tb_conta");
    $total_real_balance = $stmt_total_real->fetchColumn();
    $total_real_balance = number_format($total_real_balance, 2, ',', '.');
} catch (PDOException $e) {
    error_log("Erro ao buscar saldo total em Reais: " . $e->getMessage());
    $total_real_balance = "Erro";
}

// Últimos usuários cadastrados
$latest_new_users = [];
try {
    $stmt_latest_users = $pdo->query("SELECT nm_usuario, ds_email, dt_cadastro FROM tb_usuario ORDER BY dt_cadastro DESC LIMIT 5");
    $latest_new_users = $stmt_latest_users->fetchAll();
} catch (PDOException $e) {
    error_log("Erro ao buscar últimos usuários: " . $e->getMessage());
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Administrativo - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Admin Bank Lopes</div>
            <nav>
                <ul>
                    <li>Olá, <?= $admin_name ?>! (<?= $admin_level ?>)</li>
                    <li><a href="admin_manage_users.php">Gerenciar Usuários</a></li>
                    <li><a href="admin_view_transactions.php">Transações</a></li>
                    <li><a href="admin_logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="container">
            <h2>Dashboard Administrativo</h2>
            <?php display_messages(); ?>

            <div style="margin-bottom: 20px;">
                <p><strong>Total de Usuários:</strong> <?= htmlspecialchars($total_users) ?></p>
                <p><strong>Saldo Total em Reais:</strong> R$ <?= htmlspecialchars($total_real_balance) ?></p>
                <p><strong>Saldo Total em Bitcoin:</strong> <?= htmlspecialchars($total_btc_balance) ?> BTC</p>
            </div>

            <h3 style="margin-top: 30px; border-bottom: 2px solid #4CAF50; padding-bottom: 10px;">Últimos Usuários Cadastrados</h3>
            <?php if (!empty($latest_new_users)): ?>
                <table style="width: 100%; border-collapse: collapse; margin-top: 15px;">
                    <thead>
                        <tr style="background-color: #f4f4f4;">
                            <th style="text-align: left; padding: 12px 15px; border-bottom: 1px solid #ddd;">Nome</th>
                            <th style="text-align: left; padding: 12px 15px; border-bottom: 1px solid #ddd;">E-mail</th>
                            <th style="text-align: left; padding: 12px 15px; border-bottom: 1px solid #ddd;">Data de Cadastro</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($latest_new_users as $user): ?>
                            <tr>
                                <td style="padding: 12px 15px; border-bottom: 1px solid #ddd;"><?= htmlspecialchars($user['nm_usuario']) ?></td>
                                <td style="padding: 12px 15px; border-bottom: 1px solid #ddd;"><?= htmlspecialchars($user['ds_email']) ?></td>
                                <td style="padding: 12px 15px; border-bottom: 1px solid #ddd;"><?= htmlspecialchars(date('d/m/Y H:i', strtotime($user['dt_cadastro']))) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Nenhum usuário novo encontrado.</p>
            <?php endif; ?>

            <div style="margin-top: 30px;">
                <a href="admin_manage_users.php" class="button primary">Gerenciar Usuários</a>
                <a href="admin_view_transactions.php" class="button">Ver Transações</a>
                <a href="admin_system_settings.php" class="button">Configurações</a>
                <a href="admin_manage_fees.php" class="button">Gerenciar Taxas</a>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>
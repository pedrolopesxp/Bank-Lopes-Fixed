<?php
// www/pages/logout.php

session_start();
require_once __DIR__ . '/../inc/functions.php';

// Destrói todas as variáveis de sessão
$_SESSION = array();

// Se a sessão for baseada em cookies, destrói o cookie de sessão também
// Nota: Isso irá invalidar a sessão atual e exigir que o usuário faça login novamente
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Finalmente, destrói a sessão
session_destroy();

set_message("Você foi desconectado com sucesso.", "info");
redirect('../index.php');
?>

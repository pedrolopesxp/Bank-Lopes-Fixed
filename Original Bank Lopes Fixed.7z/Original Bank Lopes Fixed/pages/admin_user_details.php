<?php
// www/pages/admin_user_details.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Verifica se o administrador está logado.
if (!isset($_SESSION['admin_id'])) {
    set_message("Você precisa estar logado como administrador para acessar esta área.", "error");
    redirect('admin_login.php');
}

$admin_name = htmlspecialchars($_SESSION['admin_name'] ?? 'Administrador');
$admin_level = htmlspecialchars($_SESSION['admin_level'] ?? 'Nível Desconhecido');

$user_id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

// Verifica se um ID de usuário foi passado na URL
if (!$user_id) {
    set_message("ID de usuário inválido.", "error");
    redirect('admin_manage_users.php');
}

$user_data = null;
try {
    // Busca os dados do usuário
    $stmt = $pdo->prepare("
        SELECT 
            id_usuario, nm_usuario, ds_email, ds_cpf, dt_nascimento, ds_telefone, 
            ds_endereco, ds_cidade, ds_estado, ds_pais_origem, ds_status, 
            dt_cadastro, dt_ultimo_acesso
        FROM tb_usuario WHERE id_usuario = ?
    ");
    $stmt->execute([$user_id]);
    $user_data = $stmt->fetch();

    if (!$user_data) {
        set_message("Usuário não encontrado.", "error");
        redirect('admin_manage_users.php');
    }
} catch (PDOException $e) {
    error_log("Erro ao buscar dados do usuário para detalhes: " . $e->getMessage());
    set_message("Ocorreu um erro ao carregar os dados do usuário.", "error");
    redirect('admin_manage_users.php');
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalhes do Usuário - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .details-container {
            max-width: 700px;
            margin: 20px auto;
            padding: 30px;
            background-color: var(--secondary-color);
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .details-container h3 {
            color: var(--primary-dark-color);
            margin-bottom: 15px;
            border-bottom: 2px solid var(--border-color);
            padding-bottom: 10px;
        }

        .details-container .detail-item {
            margin-bottom: 12px;
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px dashed var(--border-color);
        }
        
        .details-container .detail-item:last-child {
            border-bottom: none;
        }

        .details-container .detail-item strong {
            color: var(--text-color);
            flex-basis: 50%; /* Alinha os valores à direita */
            text-align: right;
        }
        
        .details-container .detail-item span {
            flex-basis: 50%; /* Alinha os rótulos à esquerda */
            text-align: left;
            color: #555;
        }
        
        .details-container .button-group {
            margin-top: 25px;
            text-align: center;
        }

        .details-container .button-group .button {
            margin: 0 10px;
        }

        /* Estilos para o status do usuário */
        .status-ativo-detail { color: var(--primary-color); font-weight: bold; }
        .status-inativo-detail { color: #6c757d; }
        .status-bloqueado-detail { color: var(--danger-color); font-weight: bold; }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Admin Bank Lopes</div>
            <nav>
                <ul>
                    <li>Olá, <?= $admin_name ?>! (<?= $admin_level ?>)</li>
                    <li><a href="admin_dashboard.php">Dashboard</a></li>
                    <li><a href="admin_manage_users.php" class="active">Gerenciar Usuários</a></li>
                    <li><a href="admin_manage_fees.php">Gerenciar Taxas</a></li>
                    <li><a href="admin_view_transactions.php">Transações</a></li>
                    <li><a href="admin_logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="container">
            <h2>Detalhes do Usuário</h2>
            <?php display_messages(); ?>

            <div class="details-container">
                <h3>Informações Gerais</h3>
                <div class="detail-item">
                    <span>ID do Usuário:</span>
                    <strong><?= htmlspecialchars($user_data['id_usuario']) ?></strong>
                </div>
                <div class="detail-item">
                    <span>Nome Completo:</span>
                    <strong><?= htmlspecialchars($user_data['nm_usuario']) ?></strong>
                </div>
                <div class="detail-item">
                    <span>E-mail:</span>
                    <strong><?= htmlspecialchars($user_data['ds_email']) ?></strong>
                </div>
                <div class="detail-item">
                    <span>CPF:</span>
                    <strong><?= htmlspecialchars($user_data['ds_cpf']) ?></strong>
                </div>
                <div class="detail-item">
                    <span>Data de Nascimento:</span>
                    <strong><?= htmlspecialchars(date('d/m/Y', strtotime($user_data['dt_nascimento']))) ?></strong>
                </div>
                <div class="detail-item">
                    <span>Telefone:</span>
                    <strong><?= htmlspecialchars($user_data['ds_telefone'] ?? 'Não informado') ?></strong>
                </div>
                <div class="detail-item">
                    <span>Endereço:</span>
                    <strong><?= htmlspecialchars($user_data['ds_endereco'] ?? 'Não informado') ?></strong>
                </div>
                <div class="detail-item">
                    <span>Cidade:</span>
                    <strong><?= htmlspecialchars($user_data['ds_cidade'] ?? 'Não informada') ?></strong>
                </div>
                <div class="detail-item">
                    <span>Estado:</span>
                    <strong><?= htmlspecialchars($user_data['ds_estado'] ?? 'Não informado') ?></strong>
                </div>
                <div class="detail-item">
                    <span>País de Origem:</span>
                    <strong><?= htmlspecialchars($user_data['ds_pais_origem'] ?? 'Não informado') ?></strong>
                </div>
                 <div class="detail-item">
                    <span>Status:</span>
                    <strong>
                        <span class="status-<?= strtolower($user_data['ds_status']) ?>-detail">
                            <?= htmlspecialchars($user_data['ds_status']) ?>
                        </span>
                    </strong>
                </div>
                <div class="detail-item">
                    <span>Data de Cadastro:</span>
                    <strong><?= htmlspecialchars(date('d/m/Y H:i', strtotime($user_data['dt_cadastro']))) ?></strong>
                </div>
                <div class="detail-item">
                    <span>Último Acesso:</span>
                    <strong><?= htmlspecialchars($user_data['dt_ultimo_acesso'] ? date('d/m/Y H:i', strtotime($user_data['dt_ultimo_acesso'])) : 'Nunca acessou') ?></strong>
                </div>
                
                <div class="button-group">
                    <a href="admin_user_edit.php?id=<?= $user_id ?>" class="button">Editar Usuário</a>
                    <a href="admin_manage_users.php" class="button secondary">Voltar para a Lista</a>
                </div>
            </div>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>
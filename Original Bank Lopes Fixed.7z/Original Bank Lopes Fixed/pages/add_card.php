<?php
// www/pages/add_card.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

// Exibição de erros para depuração (MUITO IMPORTANTE: REMOVER EM PRODUÇÃO!)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Verifica se o usuário está logado.
if (!isset($_SESSION['user_id'])) {
    set_message("Você precisa estar logado para adicionar um cartão.", "error");
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$userName = htmlspecialchars($_SESSION['user_name'] ?? 'Usuário');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $card_type = trim(isset($_POST['card_type']) ? $_POST['card_type'] : '');
    $card_number = trim(isset($_POST['card_number']) ? $_POST['card_number'] : '');
    $card_holder_name = trim(isset($_POST['card_holder_name']) ? $_POST['card_holder_name'] : '');
    $expiry_month = trim(isset($_POST['expiry_month']) ? $_POST['expiry_month'] : '');
    $expiry_year = trim(isset($_POST['expiry_year']) ? $_POST['expiry_year'] : '');
    $cvv = trim(isset($_POST['cvv']) ? $_POST['cvv'] : '');
    $card_brand = trim(isset($_POST['card_brand']) ? $_POST['card_brand'] : '');

    // Validação básica dos inputs
    if (empty($card_type) || empty($card_number) || empty($card_holder_name) || empty($expiry_month) || empty($expiry_year) || empty($cvv) || empty($card_brand)) {
        set_message("Por favor, preencha todos os campos obrigatórios.", "error");
    } elseif (!is_numeric($card_number) || strlen($card_number) < 13 || strlen($card_number) > 19) {
        set_message("Número do cartão inválido. Deve conter apenas números, entre 13 e 19 dígitos.", "error");
    } elseif (!is_numeric($expiry_month) || !is_numeric($expiry_year) || $expiry_month < 1 || $expiry_month > 12 || $expiry_year < date('Y') || $expiry_year > date('Y') + 20) {
        set_message("Mês/Ano de validade inválidos. Verifique o formato e se a data não está no passado ou muito no futuro.", "error");
    } elseif (!is_numeric($cvv) || strlen($cvv) < 3 || strlen($cvv) > 4) {
        set_message("CVV inválido. Deve conter 3 ou 4 dígitos numéricos.", "error");
    } else {
        $tokenized_card_number = '**** **** **** ' . substr($card_number, -4);
        $expiry_date_db = $expiry_year . '-' . str_pad($expiry_month, 2, '0', STR_PAD_LEFT) . '-01';

        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare("
                INSERT INTO tb_informacao_cartao (
                    id_usuario,
                    tp_tipo,
                    nr_cartao_tokenizado,
                    nm_titular,
                    dt_validade,
                    ds_bandeira,
                    dt_cadastro
                ) VALUES (?, ?, ?, ?, ?, ?, NOW())
            ");

            $stmt->execute([
                $user_id,
                $card_type,
                $tokenized_card_number,
                $card_holder_name,
                $expiry_date_db,
                $card_brand
            ]);

            set_message("Cartão adicionado com sucesso!", "success");
            $pdo->commit();
            redirect('my_cards.php');
        } catch (PDOException $e) {
            $pdo->rollBack();
            error_log("Erro ao adicionar cartão (PDO): " . $e->getMessage());
            set_message("Ocorreu um erro ao adicionar o cartão. Por favor, tente novamente mais tarde. Detalhes: " . $e->getMessage(), "error");
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adicionar Cartão - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .form-container { max-width: 550px; }
        .form-grid { display: grid; grid-template-columns: 1fr; gap: 20px; }
        .form-grid .col-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .form-group label { display: block; margin-bottom: 8px; color: var(--text-color); font-weight: bold; }
        input[type="text"], input[type="number"], select { width: 100%; padding: 10px; border: 1px solid var(--border-color); border-radius: 8px; box-sizing: border-box; font-size: 1em; }
        .button-group { display: flex; gap: 15px; margin-top: 30px; justify-content: flex-start; }
        .button-group .button { padding: 12px 25px; font-size: 1em; border-radius: 10px; }
        .button-group .button.secondary { background-color: #eee; color: var(--primary-dark-color); border: 1px solid var(--border-color); }
        .button-group .button.secondary:hover { background-color: #ddd; }
        .alert { padding: 12px 20px; margin-bottom: 20px; border-radius: 10px; text-align: left; font-weight: 500; font-size: 0.9em; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .alert.error { background-color: #ffe6e6; color: #cc0000; border: 1px solid #ffcccc; }
        .alert.success { background-color: #e6ffe6; color: #008000; border: 1px solid #ccffcc; }
        .alert.info { background-color: #e6f7ff; color: #0066cc; border: 1px solid #cceeff; }
        @media (max-width: 600px) {
            .form-grid .col-2 { grid-template-columns: 1fr; }
            .button-group { flex-direction: column; }
            .button-group .button { width: 100%; }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <div class="logo">Bank Lopes</div>
            <nav>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li>Olá, <?= $userName ?></li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <section class="form-container">
            <h2>Adicionar Novo Cartão</h2>
            <?php display_messages(); ?>

            <form action="add_card.php" method="POST">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="card_type">Tipo de Cartão:</label>
                        <select id="card_type" name="card_type" required>
                            <option value="">Selecione o Tipo</option>
                            <option value="Crédito">Crédito</option>
                            <option value="Débito">Débito</option>
                            <option value="Virtual">Virtual</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="card_number">Número do Cartão:</label>
                        <input type="text" id="card_number" name="card_number" placeholder="Ex: 1234 5678 9012 3456" required maxlength="19" pattern="[0-9]{13,19}" title="Apenas números, entre 13 e 19 dígitos.">
                    </div>

                    <div class="form-group">
                        <label for="card_holder_name">Nome do Titular (como no cartão):</label>
                        <input type="text" id="card_holder_name" name="card_holder_name" placeholder="Nome Completo" required>
                    </div>

                    <div class="form-group col-2">
                        <div>
                            <label for="expiry_month">Mês de Validade:</label>
                            <input type="number" id="expiry_month" name="expiry_month" placeholder="MM (Ex: 01)" min="1" max="12" required>
                        </div>
                        <div>
                            <label for="expiry_year">Ano de Validade:</label>
                            <input type="number" id="expiry_year" name="expiry_year" placeholder="AAAA (Ex: 2028)" min="<?= date('Y') ?>" max="<?= date('Y') + 10 ?>" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="cvv">CVV:</label>
                        <input type="text" id="cvv" name="cvv" placeholder="3 ou 4 dígitos" required maxlength="4" pattern="[0-9]{3,4}" title="3 ou 4 dígitos numéricos.">
                    </div>

                    <div class="form-group">
                        <label for="card_brand">Bandeira do Cartão:</label>
                        <input type="text" id="card_brand" name="card_brand" placeholder="Ex: Visa, Mastercard, Elo" required>
                    </div>
                </div>

                <div class="button-group">
                    <button type="submit" class="button primary">Adicionar Cartão</button>
                    <a href="my_cards.php" class="button secondary">Cancelar</a>
                </div>
            </form>
        </section>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados. | <a href="admin_login.php">Área Administrativa</a></p>
        </div>
    </footer>
</body>
</html>

<?php
// www/pages/ted.php

session_start();
require_once __DIR__ . '/../inc/db_connection.php';
require_once __DIR__ . '/../inc/functions.php';

if (!isset($_SESSION['user_id'])) {
    redirect('login.php');
}

$user_id = $_SESSION['user_id'];
$userName = htmlspecialchars($_SESSION['user_name'] ?? 'Usuário');

// Lógica para buscar o saldo e as informações bancárias cadastradas
$current_real_balance = 0;
$user_bank_info = [];

try {
    $stmt_balance = $pdo->prepare("SELECT vl_saldo_real FROM tb_conta WHERE id_usuario = ?");
    $stmt_balance->execute([$user_id]);
    $account_data = $stmt_balance->fetch(PDO::FETCH_ASSOC);
    if ($account_data) {
        $current_real_balance = $account_data['vl_saldo_real'];
    }

    $stmt_bank_info = $pdo->prepare("SELECT nm_banco, nr_agencia, nr_conta, tp_tipo_conta FROM tb_informacao_bancaria WHERE id_usuario = ? LIMIT 1");
    $stmt_bank_info->execute([$user_id]);
    $user_bank_info = $stmt_bank_info->fetch(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    error_log("Erro ao carregar dados para TED: " . $e->getMessage());
    set_message("Erro ao carregar dados. Tente novamente.", "error");
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fazer TED - Bank Lopes</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    <style>
        .ted-container {
            max-width: 600px;
            margin: 40px auto;
            padding: 30px;
            background-color: var(--secondary-color);
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }
        .form-group label {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>Bank Lopes</h1>
            <nav>
                <ul>
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="deposit_withdraw.php">Depósito/Saque</a></li>
                    <li><a href="transfer.php">Transferir</a></li>
                    <li><a href="transaction_history.php">Histórico</a></li>
                    <li>Olá, <?= $userName ?>!</li>
                    <li><a href="logout.php" class="button secondary">Sair</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <main>
        <div class="ted-container">
            <?php display_messages(); ?>
            <h1><i class="fa-solid fa-building-columns"></i> Transferência TED</h1>
            <hr>

            <p style="font-size: 1.2em; margin-bottom: 20px;">Saldo em Reais: <strong>R$ <?= htmlspecialchars(number_format($current_real_balance, 2, ',', '.')) ?></strong></p>

            <?php if (empty($user_bank_info)): ?>
                <div class="alert error">
                    Você precisa cadastrar suas informações bancárias (Banco, Agência, Conta) no seu perfil para realizar TED.
                </div>
            <?php else: ?>
                <div class="alert success" style="margin-bottom: 20px;">
                    Suas informações bancárias de origem estão cadastradas e prontas para uso.
                </div>
            <?php endif; ?>

            <form action="ted_process.php" method="POST">
                <div class="form-group">
                    <label for="recipient_bank">Banco Destino:</label>
                    <input type="text" id="recipient_bank" name="recipient_bank" placeholder="Nome do Banco" required>
                </div>

                <div class="form-group">
                    <label for="recipient_agency">Agência Destino:</label>
                    <input type="text" id="recipient_agency" name="recipient_agency" placeholder="Agência" required>
                </div>

                <div class="form-group">
                    <label for="recipient_account">Conta Destino:</label>
                    <input type="text" id="recipient_account" name="recipient_account" placeholder="Número da Conta" required>
                </div>

                <div class="form-group">
                    <label for="recipient_cpf_cnpj">CPF/CNPJ Destino:</label>
                    <input type="text" id="recipient_cpf_cnpj" name="recipient_cpf_cnpj" placeholder="CPF ou CNPJ" required>
                </div>
                
                <div class="form-group">
                    <label for="amount">Valor (R$):</label>
                    <input type="number" id="amount" name="amount" step="0.01" min="0.01" placeholder="R$ 0,00" required>
                </div>

                <div class="form-group">
                    <label for="description">Descrição:</label>
                    <input type="text" id="description" name="description" maxlength="100" placeholder="Ex: Pagamento de conta" required>
                </div>

                <button type="submit" class="button primary">Confirmar Transferência TED</button>
            </form>
        </div>
    </main>

    <footer>
        <div class="container">
            <p>&copy; 2025 Bank Lopes. Todos os direitos reservados.</p>
        </div>
    </footer>
</body>
</html>
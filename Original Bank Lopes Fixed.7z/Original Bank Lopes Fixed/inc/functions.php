<?php
// www/inc/functions.php

// Inicia a sessão se ainda não estiver iniciada
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

/**
 * Define uma mensagem de alerta na sessão.
 * @param string $message A mensagem a ser exibida.
 * @param string $type O tipo de mensagem (ex: 'success', 'error', 'info').
 */
function set_message(string $message, string $type = 'info'): void
{
    $_SESSION['message'] = [
        'text' => $message,
        'type' => $type
    ];
}

/**
 * Retorna a mensagem de alerta da sessão e a limpa.
 * @param string|null $type Se especificado, retorna apenas a mensagem desse tipo.
 * @return array|null Um array contendo 'text' e 'type' da mensagem, ou null se não houver.
 */
function get_message(?string $type = null): ?array
{
    if (isset($_SESSION['message'])) {
        $message = $_SESSION['message'];
        unset($_SESSION['message']); // Limpa a mensagem após ser lida

        if ($type === null || $message['type'] === $type) {
            return $message;
        }
    }
    return null;
}

/**
 * Exibe a mensagem de alerta se houver uma na sessão.
 */
function display_messages(): void
{
    if ($message = get_message()) {
        echo '<div class="alert ' . htmlspecialchars($message['type']) . '">' . htmlspecialchars($message['text']) . '</div>';
    }
}

/**
 * Redireciona para uma URL específica.
 * @param string $path O caminho para onde redirecionar (ex: 'dashboard.php', 'login.php').
 */
function redirect(string $path): void
{
    // Garante que o caminho base está correto para redirecionamentos
    header("Location: " . get_base_url() . "/pages/" . $path);
    exit();
}

/**
 * Obtém a URL base do site. Útil para redirecionamentos absolutos.
 * @return string A URL base.
 */
function get_base_url(): string
{
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http";
    $host = $_SERVER['HTTP_HOST'];
    $script_name = $_SERVER['SCRIPT_NAME'];
    $script_dir = dirname($script_name);

    // Ajusta para o caso em que o script está na raiz do servidor web, ou em um subdiretório
    if ($script_dir === '/' || $script_dir === '\\') {
        return "$protocol://$host";
    }
    // Se estiver em um subdiretório (ex: /banklopes/www/pages/...)
    // Assumimos que o base_url deve ser até 'www' ou a pasta do projeto se for o caso
    // Ex: http://localhost/banklopes
    // Você pode precisar ajustar isso dependendo da sua configuração do AppServ
    // O padrão aqui é que a raiz do projeto é a pasta pai da pasta 'inc'
    $base_path = str_replace('/inc', '', $script_dir);
    // Remove 'pages' se a chamada vier de uma subpasta 'pages'
    $base_path = str_replace('/pages', '', $base_path);
    return "$protocol://$host" . $base_path;
}

/**
 * Gera um token seguro de comprimento especificado.
 * @param int $length O comprimento desejado para o token.
 * @return string O token gerado.
 */
function generate_token(int $length = 32): string
{
    return bin2hex(random_bytes($length / 2));
}

/**
 * Valida o formato de um e-mail.
 * @param string $email O e-mail a ser validado.
 * @return bool True se o e-mail for válido, false caso contrário.
 */
function is_valid_email(string $email): bool
{
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Hashes uma senha para armazenamento seguro.
 * @param string $password A senha a ser hasheada.
 * @return string O hash da senha.
 */
function hash_password(string $password): string
{
    return password_hash($password, PASSWORD_DEFAULT);
}

/**
 * Verifica uma senha hasheada.
 * @param string $password A senha em texto puro fornecida pelo usuário.
 * @param string $hashed_password O hash da senha armazenado no banco de dados.
 * @return bool True se a senha corresponder ao hash, false caso contrário.
 */
function verify_password(string $password, string $hashed_password): bool
{
    return password_verify($password, $hashed_password);
}


/**
 * Valida um número de CPF.
 * @param string $cpf O CPF a ser validado (espera-se apenas números).
 * @return bool True se o CPF for válido, false caso contrário.
 */
function is_valid_cpf(string $cpf): bool
{
    // Remove caracteres não numéricos
    $cpf = preg_replace('/[^0-9]/is', '', $cpf);

    // Verifica se o número de dígitos é 11
    if (strlen($cpf) != 11) {
        return false;
    }

    // Verifica se todos os dígitos são iguais (ex: 11111111111)
    if (preg_match('/(\d)\1{10}/', $cpf)) {
        return false;
    }

    // Calcula e verifica o primeiro dígito verificador
    for ($t = 9; $t < 11; $t++) {
        for ($d = 0, $c = 0; $c < $t; $c++) {
            $d += $cpf[$c] * (($t + 1) - $c);
        }
        $d = ((10 * $d) % 11) % 10;
        if ($cpf[$c] != $d) {
            return false;
        }
    }
    return true;
}

/**
 * Gera um UUID (Universally Unique Identifier) versão 4.
 * Usado para gerar chaves PIX aleatórias ou IDs únicos.
 * @return string Um UUID v4 formatado.
 */
function generate_uuid_v4(): string
{
    return sprintf('%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
        // 32 bits for "time_low"
        mt_rand(0, 0xffff), mt_rand(0, 0xffff),

        // 16 bits for "time_mid"
        mt_rand(0, 0xffff),

        // 16 bits for "time_hi_and_version",
        // four most significant bits holds version number 4
        mt_rand(0, 0x0fff) | 0x4000,

        // 16 bits for "clk_seq_hi_res" and "clk_seq_low",
        // two most significant bits holds zero and one for variant DCE1.1
        mt_rand(0, 0x3fff) | 0x8000,

        // 48 bits for "node"
        mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
    );
}

?>
